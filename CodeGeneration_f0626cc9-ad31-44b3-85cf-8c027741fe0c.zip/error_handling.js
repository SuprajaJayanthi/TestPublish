// Error Handling Module

function handleError(error) {
    // Log the error details
    console.error('Error occurred:', error);
    // Inform user with a general error message (to prevent sensitive data exposure)
    alert('An unexpected error occurred. Please try again later.');
    // Optional: send error details to the backend for further analysis
    // fetch('/api/logError', {
    //     method: 'POST',
    //     headers: {
    //         'Content-Type': 'application/json'
    //     },
    //     body: JSON.stringify({ error: error.message, stack: error.stack })
    // });
}

module.exports = handleError;
