# Summary Conversion Module

import logging
import os
from typing import List

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class SummaryConversion:
    def __init__(self, input_path: str, output_path: str):
        self.input_path = input_path
        self.output_path = output_path
        self.validate_paths()

    def validate_paths(self):
        if not os.path.exists(self.input_path):
            raise FileNotFoundError(f"Input path {self.input_path} does not exist.")
        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path)

    def convert_stories_to_summary(self, detailed_stories: List[str]) -> List[str]:
        summaries = []
        for story in detailed_stories:
            try:
                summary = self.process_story(story)
                summaries.append(summary)
            except Exception as e:
                logging.error(f"Error processing story: {e}")
        return summaries

    def process_story(self, story: str) -> str:
        # Placeholder for the actual conversion logic
        # Assume it returns a standardized summary
        summary = " ".join(story.split()[:20])  # Example: take first 20 words
        return summary

    def load_stories_from_file(self, filename: str) -> List[str]:
        try:
            with open(os.path.join(self.input_path, filename), 'r') as file:
                return file.readlines()
        except Exception as e:
            logging.error(f"Failed to load stories from file {filename}: {e}")
            return []

    def save_summaries_to_file(self, summaries: List[str], filename: str):
        try:
            with open(os.path.join(self.output_path, filename), 'w') as file:
                for summary in summaries:
                    file.write(summary + '\n')
        except Exception as e:
            logging.error(f"Failed to save summaries to file {filename}: {e}")

# Example usage
# converter = SummaryConversion(input_path='input', output_path='output')
# stories = converter.load_stories_from_file('user_stories.txt')
# summaries = converter.convert_stories_to_summary(stories)
# converter.save_summaries_to_file(summaries, 'summaries.txt')
