import { When } from '@badeball/cypress-cucumber-preprocessor';
import { clickButton, replaceText, selectDropdownValue } from '../common/interactions';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout } from '../common/common';

When(/^I fill "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|Unfall|Gegenstandsschutz|Jagdhaft)" Angebotseite with Variante "(Basis|Smart|Komfort|Premium)"(?: and Selbstbeteiligung "([^"]*)")?(?: and Zusatzoptionen "([^"]*)")?(?: and default chosen Zusatzoptionen "([^"]*)")?(?: and Invaliditätssumme "([^"]*)")?$/,
  (strecke, variante, selbstbeteiligung, optionen, ausgewaehleteZusatzoptionen, invsumme) => {
    selectAngebotVariante(variante, strecke);
    if(ausgewaehleteZusatzoptionen) {
      checkDefaultZusatzoptionen(ausgewaehleteZusatzoptionen, strecke);
    }
    selectZusatzoptionen(optionen, strecke);
    if (selbstbeteiligung) {
      strecke = strecke === 'THH-Hund' || strecke === 'THH-Pferd' ? 'THH' : strecke;
      selectDropdownValue(strecke + ' Angebot Selbstbeteiligung Dropdown', selbstbeteiligung);
    } else if (invsumme) {
      replaceText('Unfall Angebot Invsumme', invsumme + '{tab}');
    }
    clickButton('Angebot übernehmen');
  }
);

When(/^I fill "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|Unfall|Gegenstandsschutz|Jagdhaft)" Angebotseite for Ersatzgeschäft(?: with Selbstbeteiligung "([^"]*)")?$/,
  (strecke, selbstbeteiligung) => {
    if (selbstbeteiligung) {
      selectDropdownValue(strecke + ' Angebot Selbstbeteiligung Dropdown', selbstbeteiligung);
    }
    clickButton('Angebot übernehmen');
  }
);

function selectAngebotVariante(variante, strecke) {
  let variantenButton = 'Angebot Produkttabelle Button ' + variante;
  if (['Gegenstandsschutz', 'Jagdhaft'].includes(strecke)) {
    variantenButton += ' ' + strecke;
  }
  cy.wait(1000).get(getSelector(variantenButton), { timeout: globalTimeout }).should('not.be.disabled').click({
    force: true,
  });
}

function checkDefaultZusatzoptionen(optionen, strecke) {
  const zusatzArray = optionen.split(', ');
  for (let zusatz of zusatzArray) {
    const zusatzBox = strecke + ' Angebot Zusatzoptionen ' + zusatz;
    cy.get(getSelector(zusatzBox), { timeout: globalTimeout })
      .contains(
        getSelector('Button'),
        getTextOrRegex(replaceCustomTextCommands('Ausgewählt')),
        { timeout: globalTimeout }
      )
  }
}

function selectZusatzoptionen(optionen, strecke) {
  if (!optionen) {
    return;
  }
  const zusatzArray = optionen.split(', ');
  for (let zusatz of zusatzArray) {
    if (strecke === 'VHV') {
      cy.wait(5000);
    }
    if (zusatz === 'Heilbehandlungsschutz 2000') {
      zusatz = zusatz.split(' ')[0];
      const zusatzBox = strecke + ' Angebot Zusatzoptionen ' + zusatz;
      cy.get(getSelector(zusatzBox), { timeout: globalTimeout })
        .contains(
          getSelector('Button'),
          getTextOrRegex(replaceCustomTextCommands('Auswählen')),
          { timeout: globalTimeout }
        )
        .click();
      cy.get(
        '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios-1"]',
        { timeout: globalTimeout }
      ).click();
    } else {
      const zusatzBox = strecke + ' Angebot Zusatzoptionen ' + zusatz;
      cy.get(getSelector(zusatzBox), { timeout: globalTimeout })
        .contains(
          getSelector('Button'),
          getTextOrRegex(replaceCustomTextCommands('Auswählen')),
          { timeout: globalTimeout }
        )
        .click();
    }
  }
}
