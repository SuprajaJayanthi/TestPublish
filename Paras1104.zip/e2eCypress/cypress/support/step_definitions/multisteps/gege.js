import {Then, When} from '@badeball/cypress-cucumber-preprocessor';
import {clickButton, clickElement, replaceText, selectDropdownValue} from '../common/interactions';
import {getDate, getSelector, getTextOrRegex, replaceCustomTextCommands} from '../common/helpers';
import {globalTimeout} from "../common/common";

When(/^I fill GEGE Basisangaben for Gegenstand "([1-9]|10)" with Katgeorie "(Fahrrad|Foto \/ Video \/ Optik|Laptop \/ Computer \/ Gaming|Luftsport|Musikinstrumente|Uhren|Schmuck|Wintersport|Wassersport|Camping \/ Outdoor|Tauchen|Handtaschen und Mode|Reitsport|Jagd- und Sportwaffen|Golf|Kunst \/ Antiquitäten|Angeln)" and Kaufpreis "([^"]*)" and Kaufdatum "([^"]*)"(?: "([^"]*)" Tage)?(?: "([^"]*)" Jahre)? and (stay|continue)$/,
  (
    nummer,
    kategorie,
    kaufpreis,
    date,
    additionalDays,
    additionalYears,
    zumAngebot
  ) => {
    if (parseInt(nummer) > 1) {
      clickElement('Gegenstandsschutz Eingabe Gegenstand hinzufuegen');
    }
    selectDropdownValue(`Gegenstandsschutz Eingabe Gegenstand ${nummer} Kategorie Dropdown`, kategorie);
    replaceText(`Gegenstandsschutz Eingabe Gegenstand ${nummer} Kaufpreis`, kaufpreis);
    replaceText(`Gegenstandsschutz Eingabe Gegenstand ${nummer} Kaufdatum`, getDate(date, additionalDays, additionalYears));
    if (zumAngebot === 'continue') {
      clickButton('Zum Angebot');
    }
  }
);

Then(/^I should see Kategorie "(Fahrrad|Foto \/ Video \/ Optik|Laptop \/ Computer \/ Gaming|Luftsport|Musikinstrumente|Uhren|Schmuck|Wintersport|Wassersport|Camping \/ Outdoor|Tauchen|Handtaschen und Mode|Reitsport|Jagd- und Sportwaffen|Golf|Kunst \/ Antiquitäten|Angeln)", Kaufpreis "([^"]*)", Kaufdatum "([^"]*)" inside Eingabe Gegenstand "([1-9]|10)"$/,
  (
    kategorie,
    kaufpreis,
    kaufdatum,
    nummer
  ) => {
    cy.contains(
      getSelector('Gegenstandsschutz Kategorie of Gegenstand')(nummer - 1),
      getTextOrRegex(replaceCustomTextCommands(kategorie)),
      { timeout: globalTimeout }
    ).first().should('exist');
    cy.get(
      getSelector('Gegenstandsschutz Kaufpreis of Gegenstand')(nummer - 1),
      { timeout: globalTimeout }
    ).first().invoke('val').should("equal", kaufpreis);
    cy.get(
      getSelector('Gegenstandsschutz Kaufdatum of Gegenstand')(nummer - 1),
      { timeout: globalTimeout }
    ).first().invoke('val').should("equal", kaufdatum);
  }
);

Then(/^I should see Modell "([^"]*)", Informationen "([^"]*)" inside Checkout Gegenstand "([1-9]|10)" of Gegenstandsschutz "([1-9]|10)"$/,
  (
    modell,
    informationen,
    nummer,
    gegenstandsschutz
  ) => {
    cy.get(
      getSelector(`Checkout Gegenstandsschutz ${ gegenstandsschutz - 1 } Modell`)(nummer - 1),
      { timeout: globalTimeout }
    ).first().invoke('val').should("equal", modell);
    cy.get(
      getSelector(`Checkout Gegenstandsschutz ${ gegenstandsschutz - 1 } Informationen`)(nummer - 1),
      { timeout: globalTimeout }
    ).first().invoke('val').should("equal", informationen);
  }
);
