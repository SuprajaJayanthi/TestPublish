import { When } from '@badeball/cypress-cucumber-preprocessor';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout } from '../common/common';
import { replaceTextInsideElement } from '../common/typing';
import {clickButton, clickElement, selectDropdownValue} from '../common/interactions';

// Example: And I fill basisangaben with Anzahl "mehrere Pferde" Größe "Kleiner,Groesser" Vorschaeden "Nein"
When(/^I fill THH-Pferd Basisangaben with Anzahl "(ein Pferd|mehrere Pferde)" Größe "([^"]*)"(?: Vorschaeden "([^"]*)")?$/,
  (anzahl, sizeString, vorschaeden) => {
    selectDropdownValue('THH-Pferd Eingabe AnzahlTiere Dropdown', anzahl);
    if (anzahl === 'ein Pferd') {
      clickElement(`THH-Pferd Eingabe EinPferd Radio ${sizeString}`);
    } else {
      const angabenSize = sizeString.split(',');
      for (let i = 0; i < angabenSize.length; i++) {
        const text = angabenSize[i] === 'Kleiner' ? 'unter 148 cm' : '148 cm oder größer';
        clickElement(`THH-Pferd Eingabe MehrerePferdeStockmass Radio - ${i}`, text);
      }
    }
    if (vorschaeden === 'Nein') {
      clickElement('THH-Pferd Eingabe Vorschaeden Radio Nein')
    } else if (vorschaeden) {
      clickElement('THH-Pferd Eingabe Vorschaeden Radio Ja')
      replaceTextInsideElement('Input', 'THH-Pferd Eingabe Vorschaeden Stepper', vorschaeden);
    }
    clickButton('Zum Angebot');
  }
);
