import { When } from '@badeball/cypress-cucumber-preprocessor';
import {clickButton, selectDropdownValue} from '../common/interactions';

When(/^I fill UNF Basisangaben with Berufsgruppe "(kaufmännisch\/verwaltend|handwerklich\/körperlich|Profisportler, Artist, Stuntman, Tierbändiger oder Dompteur)"$/,
  (berufsgruppe) => {
    selectDropdownValue('Unfall Eingabe Berufsgruppe Dropdown', berufsgruppe);
    clickButton('Zum Angebot');
  }
);
