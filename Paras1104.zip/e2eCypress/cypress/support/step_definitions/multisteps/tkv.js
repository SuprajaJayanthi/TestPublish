import { When } from '@badeball/cypress-cucumber-preprocessor';
import {
  getDate,
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout } from '../common/common';
import {
  replaceText,
  selectDropdownValue,
} from '../common/interactions';

let lastTkvTier;

When(/^I fill TKV Basisangaben with Tierart "(Hund|Katze|Pferd)" Geschlecht "(männlich|weiblich)" Rasse "([^"]*)" Geburtsdatum "([^"]*)"(?: "([^"]*)" Tage)?(?: "([^"]*)" Jahre)? Kastriert "(Ja|Nein)"(?: Haltung "(Freigänger|ausschließlich in der Wohnung)")? Vorschaeden "(Ja|Nein)"(?: Heilbehandlung "(Ja)")?(?: Operationen "([^"]*)")?(?: Krankeit "(Ja|Nein)")?$/,
  (
    tierart,
    geschlecht,
    rasse,
    date,
    additionalDays,
    additionalYears,
    kastriert,
    haltung,
    vorschaeden,
    heilbehanldung,
    operationen,
    krankheit
  ) => {
    selectDropdownValue('TKV Basisangaben Tierart Dropdown', tierart);
    selectDropdownValue('TKV Basisangaben Tiergeschlecht Dropdown', geschlecht);
    const rassendropdown = {
      ['Hund']: 'TKV Basisangaben Hunderassen Dropdown',
      ['Katze']: 'TKV Basisangaben Katzenrassen Dropdown',
      ['Pferd']: 'TKV Basisangaben Pferderassen Dropdown',
    }[tierart];
    selectDropdownValue(rassendropdown, rasse);
    const inputDate = getDate(date, additionalDays, additionalYears);
    replaceText('TKV Geburtsdatum', inputDate);
    cy.get(getSelector('TKV Kastriert Radio Group'), { timeout: globalTimeout })
      .contains(
        getSelector('Radio'),
        getTextOrRegex(replaceCustomTextCommands(kastriert)),
        { timeout: globalTimeout }
      )
      .click();
    if (haltung) {
      cy.get(getSelector('TKV Katzenhaltung Radio Group'), {
        timeout: globalTimeout,
      })
        .contains(
          getSelector('Radio'),
          getTextOrRegex(replaceCustomTextCommands(haltung)),
          { timeout: globalTimeout }
        )
        .click();
    }
    cy.get(getSelector('TKV Behandlungen Radio Group'), {
      timeout: globalTimeout,
    })
      .contains(
        getSelector('Radio'),
        getTextOrRegex(replaceCustomTextCommands(vorschaeden)),
        { timeout: globalTimeout }
      )
      .click();
    if (vorschaeden !== 'Nein') {
      if (operationen) {
        cy.get(getSelector('TKV Basisangaben Operationen Checkbox'), {
          timeout: globalTimeout,
        }).click();
        replaceText('TKV Operationen Number Stepper Input', operationen);
      }
      if (heilbehanldung) {
        cy.get(getSelector('TKV Tierarzt Checkbox Group'), {
          timeout: globalTimeout,
        })
          .contains(
            getSelector('Checkbox'),
            getTextOrRegex(replaceCustomTextCommands('Heilbehandlung')),
            { timeout: globalTimeout }
          )
          .click();
      }
      if (krankheit) {
        cy.get(getSelector('TKV Erkrankungen Radio Group'), {
          timeout: globalTimeout,
        })
          .contains(
            getSelector('Radio'),
            getTextOrRegex(replaceCustomTextCommands(krankheit)),
            { timeout: globalTimeout }
          )
          .click();
      }
    }
    cy.get(getSelector('Button'), { timeout: globalTimeout })
      .contains(getTextOrRegex(replaceCustomTextCommands('Zum Angebot')), {
        timeout: globalTimeout,
      })
      .click();
    lastTkvTier = `${rasse}, ${inputDate}`;
  }
);

export function getLastTkvTier() {
  return lastTkvTier;
}
