import {When} from '@badeball/cypress-cucumber-preprocessor';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import {globalTimeout} from '../common/common';
import {
  clickButton, clickElement,
  replaceConditionalText,
  replaceText, selectConditionalDropdownValue,
  selectDropdownValue,
} from '../common/interactions';

let lastVwgAdress;

When(/^I fill VWG Basisangaben with(?: PLZ "([^"]*)")?(?: Ort "([^"]*)")?(?: Straße "([^"]*)")?(?: Hausnummer "([^"]*)")?(?: Wohnflaeche "([^"]*)")? Baujahr "([^"]*)"(?: Gebauedemerkmale "([^"]*)")?(?: Vorschaeden "([^"]*)")?(?: weitere Wohnfläche "([^"]*)")?(?: ausländische Adresse "(Ja|Nein)")?$/,
  (plz, ort, strasse, hausnummer, flaeche, baujahr, gebauedermerkmale, vorschaeden, weitereWohnflaeche, auslaendischeAdresse) => {
    replaceConditionalText(plz, 'VWG Eingabe PLZ Input', plz);
    selectConditionalDropdownValue(ort, 'VWG Eingabe Ort Dropdown', ort);
    selectConditionalDropdownValue(strasse, 'VWG Eingabe Strasse Dropdown', strasse);
    replaceConditionalText(hausnummer, 'VWG Eingabe Hausnr Input', hausnummer);
    replaceConditionalText(flaeche, 'VWG Eingabe Wohnflaeche Input', flaeche);
    replaceText('VWG Eingabe Baujahr Input', baujahr);

    if (gebauedermerkmale && gebauedermerkmale.length > 0) {
      const gebauedermerkmaleArray = gebauedermerkmale.split(',');
      let i = 0;
      while (i < gebauedermerkmaleArray.length) {
        switch (gebauedermerkmaleArray[i].split(' ')[0]) {
          case 'Keller':
            clickElement('VWG Eingabe Gebaeudemerkmale', 'Keller')
            let kellerWohnButton = '';
            if (gebauedermerkmaleArray[i].split(' ')[1] === 'Bewohnt') {
              kellerWohnButton = 'Ja';
            } else {
              kellerWohnButton = 'Nein';
            }
            clickElement('VWG Eingabe Wohnflaeche im Keller vorhanden Radio', kellerWohnButton);
            break;
          default:
            clickElement('VWG Eingabe Gebaeudemerkmale', gebauedermerkmaleArray[i]);
            break;
        }
        i += 1;
      }
    }
    if (weitereWohnflaeche) {
      clickElement('VWG Eingabe Nebengebaeude Radio', 'Ja');
      replaceText('VWG Eingabe Nebengebaeude Flaeche Input', weitereWohnflaeche);
    } else {
      clickElement('VWG Eingabe Nebengebaeude Radio', 'Nein');
    }
    if (vorschaeden === 'Nein') {
      clickElement('VWG Eingabe Vorschaeden Radio Nein')
    } else if (vorschaeden) {
      clickElement('VWG Eingabe Vorschaeden Radio Ja')
      let i = 0;
      const vorschaedenArray = vorschaeden.split(' ');
      while (i < vorschaedenArray.length) {
        replaceText(`VWG Eingabe Vorschaeden Numberstepper ${vorschaedenArray[i]} Input`, vorschaedenArray[i + 1]);
        i += 2;
      }
    }

    if (auslaendischeAdresse === 'Ja') {
      clickElement('Vwg Auslaendische Adresse Checkbox');
    }

    clickButton('Zum Angebot');
    lastVwgAdress = `${strasse} ${hausnummer}, ${plz}`;
  }
);

When(/^I fill VWG Basisangaben$/, () => {
  clickElement('VWG Eingabe Vorschaeden Radio Nein');
  clickButton('Zum Angebot');
});

export function getLastVwgAdress() {
  return lastVwgAdress;
}
