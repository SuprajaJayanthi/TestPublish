import { Then, When } from '@badeball/cypress-cucumber-preprocessor';
import { addDays, format } from 'date-fns';
import {
  attributeToCypressShould,
  getDate,
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout, increasedTimeout } from '../common/common';
import { clickButton, clickElement, replaceText, selectDropdownValue, } from '../common/interactions';
import { shouldNotBeVisible } from "../common/visibility";

When(/^I go to Checkout$/, () => {
  cy.get('#weiterZumAntragButton').click();
});

When(/^I fill Checkout Kontaktdaten with E-Mail "([^"]*)"(?: Mobilnummer "([^"]*)")? Telefonnummer "([^"]*)"$/,
  (email, mobil, telefon) => {
    replaceText('Checkout Versicherungsnehmer Email Input', email);
    replaceText('Checkout Versicherungsnehmer Telefon Input', telefon);
    if (!mobil) {
      replaceText('Checkout Versicherungsnehmer Mobile Input', '{tab}');
      cy.get(getSelector('Checkout Mobil Radio Angabe'), {
        timeout: globalTimeout,
      })
        .contains(
          getTextOrRegex(replaceCustomTextCommands('Keine Angabe gewünscht')),
          {timeout: globalTimeout}
        )
        .click();
    } else {
      replaceText('Checkout Versicherungsnehmer Mobile Input', mobil);
    }
  }
);

When(/^I select Vorversicherer for "([^"]*)" with Gesellschaft "([^"]*)" and Nummer "([^"]*)"(?: and Ablauf "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?)?(?: and Gefahren "([^"]*)")?$/,
  (
    strecke,
    gesellschaft,
    nummer,
    ablauf,
    additionalDays,
    additionalYears,
    gefahrenString
  ) => {
    const streckeWithMpfIndex = strecke.split('-');
    strecke = streckeWithMpfIndex[0];
    const mpfIndex = streckeWithMpfIndex[1] ? streckeWithMpfIndex[1] : '0';
    cy.get(
      `[data-cy="checkout-vorversicherung-${strecke.toLowerCase()}${
        streckeWithMpfIndex[1] ? streckeWithMpfIndex[1] : ''
      }-radio"]`,
      {timeout: globalTimeout}
    )
      .contains(getTextOrRegex(replaceCustomTextCommands('Ja')), {
        timeout: globalTimeout,
      })
      .click({force: true})
      .then(() => {
        cy.wait(2000);
        if (gefahrenString) {
          const gefahren = gefahrenString.split(', ');
          gefahren.forEach((gefahr) => {
            let gefahrIndex;
            switch (gefahr) {
              case 'Feuer':
                gefahrIndex = '0';
                break;
              case 'Sturm/Hagel':
                gefahrIndex = '1';
                break;
              case 'Leitungswasser':
                gefahrIndex = '2';
                break;
              case 'Weitere Naturgefahren':
                gefahrIndex = '3';
                break;
              default:
                break;
            }
            const gefahrSelector = `[data-cy="checkout-vorversicherungAngaben-${strecke.toLowerCase()}${
              mpfIndex !== '0' ? mpfIndex : ''
            }-gefahrenCheckbox-${gefahrIndex}"]`;

            cy.get(gefahrSelector, {timeout: globalTimeout}).then(($el) => {
              cy.wrap($el)
                .contains(getTextOrRegex(replaceCustomTextCommands(gefahr)), {
                  timeout: globalTimeout,
                })
                .click();
            });
          });
        }
        selectDropdownValue(
          'Checkout BA Vorversicherung DropDown Sparte ' + strecke,
          gesellschaft
        )
        cy.get(
          `${getSelector(
            'Checkout BA Vorversicherung VersicherungsNr ' + strecke
          )}`
        ).typeWithTabSupport(replaceCustomTextCommands(nummer));

        if (ablauf) {
          const input = getDate(ablauf, additionalDays, additionalYears);
          cy.get(
            `[data-cy="ablaufdatumVorversicherung_${strecke.toLowerCase()}_${mpfIndex}"]`,
            {timeout: globalTimeout}
          )
            .type('{selectall}')
            .type(input);
        }
      });
  }
);
When(/^I select no Vorversicherer for "([^"]*)"$/, (strecken) => {
  const streckenArray = strecken.split(', ');
  for (const strecke of streckenArray) {
    cy.get(getSelector('Checkout Vorversicherung ' + strecke + ' Radio'), {
      timeout: globalTimeout,
    })
      .contains(getTextOrRegex(replaceCustomTextCommands('Nein')), {
        timeout: globalTimeout,
      })
      .click({force: true});
  }
});

When(/^I set Hauptfaelligkeit to(?: "([^"]*)")?(?: Tagesdatum(?: plus "([^"]*)" Tage)?)?$/,
  (date, additionalDays) => {
    if (date) {
      replaceText('Checkout Hauptfaelligkeit Input', date);
    } else {
      const add = additionalDays ? parseInt(additionalDays, 10) : 0;
      const calcDate = format(addDays(new Date(), add), 'dd.MM');
      replaceText('Checkout Hauptfaelligkeit Input', calcDate);
    }
  }
);

When(/^I set Hauptfaelligkeit of strecke "([^"]*)" to "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?$/,
  (strecke, date, additionalDays, additionalYears) => {
    const element =
      '[data-cy="beginn-und-ablauf-beginn-' + strecke.toLowerCase() + '"]';
    const input = getDate(date, additionalDays, additionalYears);

    cy.get(element, {timeout: globalTimeout})
      .type('{selectall}')
      .typeWithTabSupport(replaceCustomTextCommands(input));
  }
);

When(/^Beginn of strecke "([^"]*)" should be "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?(?: and be (disabled|enabled|checked|unchecked|selected|deselected))?$/,
  (strecke, date, additionalDays, additionalYears, attribute) => {
    const streckeWithMpfIndex = strecke.split('-');
    strecke = streckeWithMpfIndex[0];
    const streckeIndex = streckeWithMpfIndex[1] ? streckeWithMpfIndex[1] : '';

    const element = `[data-cy="beginn-und-ablauf-beginn-${strecke.toLowerCase()}${streckeIndex}"]`;
    const input = getDate(date, additionalDays, additionalYears);

    cy.get(element, {timeout: globalTimeout}).then(($el) => {
      cy.wrap($el)
        .invoke('val')
        .then((text) => {
          expect(text).to.equal(input);
        });
      if (attribute) {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      }
    });
  }
);

When(/^Ablaufdatum of strecke "([^"]*)" should be "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?(?: with "([^"]*)" mask)?$/,
  (strecke, date, additionalDays, additionalYears, mask) => {
    const selector = `[data-cy=beginn-und-ablauf-ablauf-${strecke.toLowerCase()}]`;
    const input = getDate(date, additionalDays, additionalYears);
    const expectedYear = input.split('.')[2];
    const expectedDate = mask ? `${mask}.${expectedYear}` : input;
    cy.get(selector).contains(expectedDate);
  }
);

When(/^I select Wartezeitverzicht to "(Ja|Nein)"$/, (wartezeit) => {
  cy.contains(
    getSelector('Checkout Wartezeitverzicht Radio'),
    getTextOrRegex(replaceCustomTextCommands(wartezeit)),
    {timeout: globalTimeout}
  ).click();
});

When(/^I set Wartezeitverzicht to "(Ja|Nein)"(?: and set Grund to "([^"]*)" and Versicherungsscheinnummer to "([^"]*)")?$/,
  (radioValue, grund, nummer) => {
    cy.get(getSelector('Checkout Wartezeitverzicht Radio'), {
      timeout: globalTimeout,
    })
      .contains(getTextOrRegex(replaceCustomTextCommands(radioValue)), {
        timeout: globalTimeout,
      })
      .click();

    if (radioValue === 'Ja') {
      cy.get(getSelector('Checkout Wartezeitverzicht Dropdown'), {
        timeout: globalTimeout,
      }).click();
      cy.get(getSelector('Dropdown Item'), {timeout: globalTimeout})
        .contains(getTextOrRegex(replaceCustomTextCommands(grund)), {
          timeout: globalTimeout,
        })
        .click();

      replaceText('Checkout Wartezeitverzicht Referenzvertrag', nummer);
    }
  }
);

When(/^I set Zielmarkt to "(Ja|Nein)"$/, (zielmarkt) => {
  cy.get(getSelector('Checkout Beratung Zielmarkt Radio'), {
    timeout: globalTimeout,
  })
    .contains(getTextOrRegex(replaceCustomTextCommands(zielmarkt)), {
      timeout: globalTimeout,
    })
    .click();
});

When(/^I fill Zielmarkt Begründung for "([^"]*)" with "([^"]*)"$/,
  (spartenString, angabenString) => {
    cy.get(getSelector('Checkout Beratung Zielmarkt Radio'), {
      timeout: globalTimeout,
    })
      .contains(getTextOrRegex(replaceCustomTextCommands('Nein')), {
        timeout: globalTimeout,
      })
      .click();

    const sparten = spartenString.split(', ');
    const angaben = angabenString.split(', ');

    if (sparten.length === angaben.length) {
      sparten.forEach((angabe, i) => {
        const streckeWithMpfIndex = angabe.split('-');
        let strecke = streckeWithMpfIndex[0];
        const mpfIndex = streckeWithMpfIndex[1] ? streckeWithMpfIndex[1] : '';
        strecke = strecke.replace('_', '-');

        cy.get(
          `#nx-checkbox-zielmarktCheckbox-${strecke.toLowerCase()}-angebot${mpfIndex}-label`,
          {timeout: globalTimeout}
        ).click();
        cy.get(
          `[data-cy="checkout-beratung-zielmarkt-begruendung-${strecke.toLowerCase()}-angebot${mpfIndex}"]`,
          {timeout: globalTimeout}
        )
          .click()
          .type('{selectall}')
          .typeWithTabSupport(replaceCustomTextCommands(angaben[i]));
      });
    } else {
      throw new Error('Every products "Begründung"-Field should be filled');
    }
  }
);

When(/^I fill Fremdfinanzierungen for "([^"]*)" with "([^"]*)" and Adresse with "([^"]*)"$/,
  (strecke, angabeString, adresseString) => {
    const streckeWithMpfIndex = strecke.split('-');
    let streckeName = streckeWithMpfIndex[0].toLowerCase();
    let streckeIndex = streckeWithMpfIndex[1] ? streckeWithMpfIndex[1] : '0';
    const angaben = angabeString.split(', ');
    const adresse = adresseString.split(', ');

    cy.get('[data-cy="checkout-sicherungsglaeubiger"]')
      .then(($el) => {
        if ($el.length <= 1) {
          streckeName = '';
          streckeIndex = '';
        }
      })
      .then(() => {
        //Nur mit einem cy.get() funktioniert das Klicken nicht
        cy.get(`[data-cy="sicherungsglaeubigerJa_${streckeName}${streckeIndex}"] > input`, {
          timeout: globalTimeout,
        }).click({force: true});
        cy.get(`[data-cy="sicherungsglaeubigerJa_${streckeName}${streckeIndex}"] > input`, {
          timeout: globalTimeout,
        }).click({force: true});

        cy.get(
          `[data-cy="checkout-sg-name-input0${streckeName}${streckeIndex}"]`,
          {timeout: globalTimeout}
        )
          .type('{selectall}')
          .typeWithTabSupport(replaceCustomTextCommands(angaben[0]));
        cy.get(
          `[data-cy="checkout-sg-aktenzeichen-input0${streckeName}${streckeIndex}"]`,
          {timeout: globalTimeout}
        )
          .type('{selectall}')
          .typeWithTabSupport(replaceCustomTextCommands(angaben[1]));

        cy.contains(
          `[data-cy="sicherungsglaeubiger-adressart-radio0${streckeName}${streckeIndex}"] nx-radio`,
          adresse[0],
          {timeout: globalTimeout}
        ).click();

        const selectors = [
          `[data-cy="checkout-sg-plz-input0${streckeName}${streckeIndex}"]`,
          `[data-cy="checkout-sg-ort-vorschlag0${streckeName}${streckeIndex}"]`,
          `[data-cy="checkout-sg-strasse-dropdown0${streckeName}${streckeIndex}"]`,
          `[data-cy="checkout-sg-hsnr-input0${streckeName}${streckeIndex}"]`,
        ];
        setCheckoutAdresse(
          adresse[1],
          adresse[2],
          adresse[3],
          adresse[4],
          selectors
        );
      });
  }
);

When(/^I fill Beratung with(?: Name "([^"]*)")?(?: Besonderheiten "([^"]*)")?(?: Datum to "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?)?$/,
  (name, besonderheiten, datum, addDays, addYears) => {
    if (name != null) {
      replaceText('Checkout Beratung Name', name);
    }
    if (datum != null) {
      replaceText('Checkout Beratung Datum', getDate(datum, addDays, addYears));
    }
    if (besonderheiten != null) {
      cy.get(getSelector('Checkout Beratung Besonderheiten Checkbox'), {
        timeout: globalTimeout,
      }).within(() => {
        cy.get(getSelector('Checkbox'), {timeout: globalTimeout})
          .contains(
            getTextOrRegex(
              replaceCustomTextCommands('Besonderheiten wurden besprochen')
            ),
            {timeout: globalTimeout}
          )
          .click({force: true});
      });
      replaceText('Checkout Beratung Besonderheiten Input', besonderheiten);
    }
  }
);

When(/^I fill Vermietete Wohnung #([^"]*) with "([^"]*)"$/,
  (indexString, angabenString) => {
    cy.wait(5000);
    const index = parseInt(indexString, 10) - 1;
    const angaben = angabenString.split(', ');
    if (angaben.length === 5) {
      cy.get(
        getSelector('Checkout Vermietete Wohnung Kachel PLZ Input')(index),
        {timeout: globalTimeout}
      )
        .type('{selectall}')
        .typeWithTabSupport(replaceCustomTextCommands(angaben[0]))
        .then(() => {
          cy.wait(5000);
          cy.get('body').then(($body) => {
            if (
              $body.find(
                getSelector('Checkout Vermietete Wohnung Kachel Ort Dropdown')(
                  index
                ),
                {timeout: globalTimeout}
              ).length
            ) {
              cy.get(
                getSelector('Checkout Vermietete Wohnung Kachel Ort Dropdown')(
                  index
                ),
                {timeout: globalTimeout}
              ).click();
              cy.get(getSelector('Dropdown Item'), {timeout: globalTimeout})
                .contains(
                  getTextOrRegex(replaceCustomTextCommands(angaben[1])),
                  {timeout: globalTimeout}
                )
                .click();
            }
          });
        });

      cy.get(
        getSelector('Checkout Vermietete Wohnung Kachel Strasse Dropdown')(
          index
        ),
        {timeout: globalTimeout}
      ).click();
      cy.get(getSelector('Dropdown Item'), {timeout: globalTimeout})
        .contains(getTextOrRegex(replaceCustomTextCommands(angaben[2])), {
          timeout: globalTimeout,
        })
        .click();
      replaceText(
        'Checkout Vermietete Wohnung Kachel Hausnummer Input',
        angaben[3],
        index
      );
      replaceText(
        'Checkout Vermietete Wohnung Kachel Wohnungsnummer Input',
        angaben[4],
        index
      );
    } else {
      throw new Error(
        `Unexpected address format "${angabenString}"; Correct address format: "[PLZ], [Ort], [Strasse], [Hausnummer], [Wohnungsnummer]"`
      );
    }
  }
);

When(/^I set Versand der Police to "([^"]*)"$/, (police) => {
  cy.get('[data-cy=police-versandArt-dropdown]', {
    timeout: globalTimeout,
  }).click();
  cy.get(getSelector('Dropdown Item'), {timeout: globalTimeout})
    .contains(getTextOrRegex(replaceCustomTextCommands(police)), {
      timeout: globalTimeout,
    })
    .click();
});

When(/^I set Vertragsschlussverfahren to "([^"]*)"(?: Uhrzeit to "([^"]*)")?(?: Datum to "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?)?$/,
  (verfahren, uhrzeit, datum, addDays, addYears) => {
    selectDropdownValue(
      'Checkout Vertragsschlussverfahren Dropdown',
      verfahren
    );
    if (uhrzeit != null) {
      replaceText('Checkout Telefonverkauf Uhrzeit', uhrzeit);
    }
    if (datum != null) {
      replaceText(
        'Checkout Telefonverkauf Datum Input',
        getDate(datum, addDays, addYears)
      );
    }
  }
);

When(/^I set Meldebehoerde Vorhanden to "(Ja|Nein)"(?: and fill Meldebehoerde with "([^"]*)" and Behördenadresse with "([^"]*)" and set Datum to "([^"]*)"(?: plus "([^"]*)" Tage)?(?: plus "([^"]*)" Jahre)?)?$/,
  (vorhanden, angabeString, adresseString, datum, addDays, addYears) => {
    cy.get(getSelector('Checkout Hund MeldebehoerdeVorhanden Titel'), {timeout: globalTimeout,})
      .contains(getTextOrRegex(replaceCustomTextCommands(vorhanden)), {timeout: globalTimeout,}).click()
      .then(() => {
        if (vorhanden === 'Ja') {
          const angaben = angabeString.split(', ');
          const adresse = adresseString.split(', ');

          cy.get(`[data-cy="checkout-nameMeldebehoerde"]`, {timeout: globalTimeout,}).type('{selectall}').typeWithTabSupport(replaceCustomTextCommands(angaben[0]))
            .then(() => {
              if (angaben[1] === 'unbekannt') {
                cy.get(`[data-cy="checkout-meldebehoerdeAktenzeichen"]`, {timeout: globalTimeout}).type('{selectall}').typeWithTabSupport(replaceCustomTextCommands(angaben[1]));
              } else {
                cy.get('[data-cy="checkout-meldebehoerdeAktZeichen-Vorhanden"]', {timeout: globalTimeout,}).click();
              }
            }).then(() => {
            const selectors = [
              '[data-cy="checkout-meldebehoerdePlz"]',
              '[data-cy="checkout-meldebehoerdeOrt"]',
              '[data-cy="checkout-meldebehoerdeStrasse"]',
              '[data-cy="checkout-meldebehoerde-hausnummer-input"]',
            ];
            setCheckoutAdresse(
              adresse[0],
              adresse[1],
              adresse[2],
              adresse[3],
              selectors
            );
            replaceText(
              'Checkout Hund Meldebehoerde SicherungsbestatigungsDatum',
              getDate(datum, addDays, addYears)
            );
          });
        }
      });
  }
);

When(/^I set Angaben zum Hund "([^"]*)" to "([^"]*)" and Datum to "([^"]*)"(?: minus "([^"]*)" Tage)?(?: minus "([^"]*)" Jahre)?$/,
  (number, angabeString, datum, subDays, subYears) => {
    const numberInt = parseInt(number, 10) - 1;
    const angaben = angabeString.split(', ');

    replaceText('Checkout Hund Angaben Name with Index', angaben[1], numberInt);
    replaceText(
      'Checkout Hund Angaben Geburtsdatum with Index',
      getDate(datum, -subDays, -subYears),
      numberInt
    );
    cy.get(
      `[data-cy="thh-hund-angaben-geschlecht-${
        angaben[0] === 'Weiblich' || angaben[0] === 'W' ? 'W' : 'M'
      }-${numberInt}"]`,
      {timeout: globalTimeout}
    ).click();
    cy.get(
      `[data-cy="thh-hund-angaben-${numberInt}-tier-kennzeichnung-radio-${angaben[2]}"]`,
      {timeout: globalTimeout}
    ).click();

    if (angaben[2] === 'chip' || angaben[2] === 'tätowierung') {
      replaceText(
        'Checkout Hund Kennzeichnung Input with Index',
        angaben[3],
        numberInt
      );
    }
  }
);

When(/^I set Angaben zum Pferd "([^"]*)" to "([^"]*)" and Datum to "([^"]*)"(?: minus "([^"]*)" Tage)?(?: minus "([^"]*)" Jahre)?$/,
  (number, angabeString, datum, subDays, subYears) => {
    const numberInt = parseInt(number, 10) - 1;
    const angaben = angabeString.split(', ');

    replaceText(
      'Checkout Pferd Angaben Geburtsdatum with Index',
      getDate(datum, -subDays, -subYears),
      numberInt
    );
    cy.get(
      `[data-cy="thh-pferd-angaben-geschlecht-${
        angaben[0] === 'Weiblich' || angaben[0] === 'W' ? 'W' : 'M'
      }-${numberInt}"]`,
      {timeout: globalTimeout}
    ).click();
    replaceText(
      'Checkout Pferd Angaben Name with Index',
      angaben[1],
      numberInt
    );
    selectDropdownValue(
      `[data-cy="thh-pferd-angaben-rasse-dropdown-${numberInt}"]`,
      angaben[2]
    );
    cy.get(
      `[data-cy="thh-pferd-angaben-${numberInt}-tier-kennzeichnung-radio-${angaben[3]}"]`,
      {timeout: globalTimeout}
    ).click();
    if (
      angaben[3] === 'chip' ||
      angaben[3] === 'tätowierung' ||
      angaben[3] === 'lebensnummer'
    ) {
      replaceText(
        'Checkout Pferd Kennzeichnung Input with Index',
        angaben[4],
        numberInt
      );
    }
  }
);

When(/^I set Angaben zum TKV "([^"]*)" "(with|with not|without)" Fehlentwicklungen to "([^"]*)"(?: and einsatzgebiet to "([^"]*)")?$/,
  (number, fehlentwicklungen, angabeString, einsatz) => {
    const numberInt = parseInt(number, 10) - 1;
    const angaben = angabeString.split(', ');
    replaceText(
      'Checkout TKV Angaben with Index Tiername',
      angaben[0],
      numberInt
    );
    if (einsatz) {
      cy.get(`[data-cy="checkout-tkv-angaben-einsatzgebiet-${numberInt}"]`, {
        timeout: globalTimeout,
      })
        .contains(einsatz, {timeout: globalTimeout})
        .click();
    }
    if (angaben[1] === 'lebensnummer') {
      clickElement('Checkout TKV Angaben Kennzeichnungsart', 'Lebensnummer');
    } else if (angaben[1] === 'chip') {
      clickElement('Checkout TKV Angaben Kennzeichnungsart', 'Transpondernummer (Chip)');
    } else {
      cy.get(
        `[data-cy="checkout-tkv-angaben-${numberInt}-kennzeichnung-radio"]`,
        {timeout: globalTimeout}
      )
        .contains(angaben[1], {timeout: globalTimeout})
        .click();
    }
    if (
      angaben[1] === 'chip' ||
      angaben[1] === 'tätowierung' ||
      angaben[1] === 'lebensnummer'
    ) {
      replaceText(
        'Checkout TKV Angaben Kennzeichnung with Index',
        angaben[2],
        numberInt
      );
    }
    if (fehlentwicklungen === 'with not') {
      cy.get(`[data-cy="tkv-tierarztbesucht-radio-group-${numberInt}-nein"]`, {
        timeout: globalTimeout,
      }).click();
    }
  }
);

When(/^I fill the Angaben zum Gegenstandsschutz for Gegenstand "([1-9]|10)" with Modell "([^"]*)" and Informationen "([^"]*)"$/,
  (nummer, modell, informationen) => {
    replaceText(`Checkout GEGE Angebot 1 Gegenstand ${nummer} Modell`, modell);
    replaceText(`Checkout GEGE Angebot 1 Gegenstand ${nummer} Informationen`, informationen);
  }
);

When(/^I click Checkout Ausschluss$/, () => {
  clickElement(`Checkout GEGE Checkbox ausschluss`)
  }
);
When(/^I fill the Angaben zur Jagd-Haftpflichtversicherung with "(Jahres-Jagdschein|Dreijahres-Jagdschein)" and Name der Behörde "([^"]*)" PLZ "([^"]*)" Strasse "([^"]*)" Hausnummer "([^"]*)"$/,
  (jagdschein, behoerde, plz, strasse, hausnummer) => {
    clickElement('Checkout JHP Jagdschein Radio', jagdschein);
    replaceText('Checkout JHP Jagdbehoerde Name', behoerde);
    replaceText('Checkout JHP Jagdbehoerde PLZ', plz);
    cy.wait(3000);
    selectDropdownValue('Checkout JHP Jagdbehoerde Strasse Dropdown', strasse);
    replaceText('Checkout JHP Jagdbehoerde Hausnummer', hausnummer);
  }
);

When(/^I fill the Angaben zur Unfallversicherung(?: with Bezugsrecht "([^"]*)")?$/,
  (bezugsrecht) => {
    clickElement('Checkout Unfall Einwilligung Checkbox');
    clickElement('Checkout Unfall Pflegefrage Radiogroup 0', 'Nein');
    if (bezugsrecht) {
      selectDropdownValue('Checkout Unfall Bezugsrecht Dropdown', bezugsrecht);
    }
  }
);

When(/^I set Bankverbindung to "([^"]*)"(?: and fill with "([^"]*)")?$/,
  (bankverbindung, iban) => {
    cy.get('[data-cy="checkout-zahlung-radio-bankverbindungen"]')
      .contains(bankverbindung, {timeout: globalTimeout})
      .click();
    cy.wait(1000);
    replaceText('Checkout Zahlung Iban', iban);
  }
);

When(/^I select Wohnung with PLZ "([0-9]*)" and enter Wohnungsnummer "([^"]*)"(?: for Kachel "([1-9])")?$/,
  (plz, wohnungsnummer, kachel) => {
    if (kachel) {
      clickElement(`Checkout Vermietete Wohnung ${kachel}. Kachel Open Immobilien Auswahl Link`)
    }

    clickElement("Immobilienauswahl Dialog", plz);
    clickButton("Übernehmen");
    replaceText(`Checkout Vermietete Wohnung ${kachel}. Kachel Wohnungsnummer Input`, wohnungsnummer);
  }
);

Then(/^I start Einreichen by clicking "(Antrag einreichen|Aushändigen und unterschreiben)" and expect it to end with "(No Error|Success Page)"$/,
  (buttonLabel, ending) => {
    clickButton(buttonLabel);
    if (ending === 'No Error') {
      shouldNotBeVisible('Checkout Error Message');
    } else if (ending === 'Success Page') {
      cy.wait(2000);
      cy.get('checkout-danke-seite', {timeout: increasedTimeout}).contains('Antrag erfolgreich versandt');
      cy.contains('Policenkontrollblatt', {timeout: increasedTimeout}).click();
      cy.get('[data-cy="pdf-pkb-success-icon"]', {timeout: increasedTimeout});
    }
  }
);

Then(/^I check the Vermittlernummer "([^"]*)" with incorrect FOM "([^"]*)" and correct FOM "([^"]*)" and except it to be "([^"]*)"$/,
  (vermittlernummer, incorrectFom, correctFom, type) => {
    clickElement('Checkout Vermittler Fremd Radio');
    replaceText('Checkout Vermittler Fremd Nummer Input', `${vermittlernummer}{tab}`);
    replaceText('Checkout Vermittler Fremd Fremdordnungsmerkmal', `${incorrectFom}{tab}`);
    cy.get(getSelector('Checkout Vermittler Fremd Fremdordnungsmerkmal Error'))
      .contains('Das eingegebene Fremd-Ordnungsmerkmal entspricht nicht den Vorgaben');
    replaceText('Checkout Vermittler Fremd Fremdordnungsmerkmal', `${correctFom}{tab}`);
    shouldNotBeVisible('Checkout Vermittler Fremd Fremdordnungsmerkmal Error');
    clickElement('Checkout Vermittler Fremd Fremdordnungsmerkmal Info');
    cy.get(getSelector('Checkout Info Icon Modal')).contains(type.toString());
    clickButton('Schließen');
  }
);

function setCheckoutAdresse(plz, ort, strasse, hausnummer, selectors) {
  cy.get(selectors[0], {timeout: globalTimeout})
    .type('{selectall}')
    .typeWithTabSupport(replaceCustomTextCommands(plz))
    .then(() => {
      selectDropdownValue(selectors[2], strasse);

      cy.get(selectors[1], {timeout: globalTimeout}).then(($el) => {
        if (!$el.is(':disabled')) {
          selectDropdownValue(selectors[1], ort);
        }
      });
      cy.get(selectors[3], {timeout: globalTimeout})
        .type('{selectall}')
        .typeWithTabSupport(replaceCustomTextCommands(hausnummer));

    });
}
