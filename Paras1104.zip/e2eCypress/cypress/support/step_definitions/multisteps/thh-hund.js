import { When } from '@badeball/cypress-cucumber-preprocessor';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { replaceTextInsideElement } from '../common/typing';
import { globalTimeout } from '../common/common';
import {
  clickButton,
  clickElement,
  replaceText,
  selectDropdownValue,
} from '../common/interactions';

When(/^I fill THH-Hund Basisangaben with Anzahl "(einen Hund|mehrere Hunde)" Rasse "([^"]*)"(?: Vorschaeden "([^"]*)")?$/,
  (anzahl, rasseString, vorschaeden) => {
    selectDropdownValue('THH-Hund Eingabe AnzahlTiere Dropdown', anzahl);
    if (anzahl === 'einen Hund') {
      selectDropdownValue('THH-Hund Eingabe EinHundRasse Dropdown', rasseString);
    } else {
      const rasseAngaben = rasseString.split(';');
      replaceText('THH Hund Eingabe MehrereHundeRassen Stepper - Input', rasseAngaben.length);
      for (let i = 0; i < rasseAngaben.length; i++) {
        selectDropdownValue('THH-Hund Eingabe MehrereHundeRassen Dropdown with Index', rasseAngaben[i], i);
      }
    }
    if (vorschaeden === 'Nein') {
      clickElement('THH-Hund Eingabe Vorschaeden Radio Nein');
    } else if (vorschaeden) {
      clickElement('THH-Hund Eingabe Vorschaeden Radio Ja');
      replaceTextInsideElement('Input', 'THH-Hund Eingabe Vorschaeden Stepper', vorschaeden);
    }
    clickButton('Zum Angebot');
  }
);
