import { When } from '@badeball/cypress-cucumber-preprocessor';
import {
  clickButton, clickElement,
  replaceText,
  selectDropdownValue,
} from '../common/interactions';

export const familienStandDropdownElements = {
  ['sich']: 'nur sich',
  ['sich, Partner']: 'sich und seinen Partner',
  ['sich, Kinder']: 'sich und sein(e) Kind(er)',
  ['sich, Partner, Kinder']: 'sich, seinen Partner und Kind(er)',
};

When(/^I fill PH Basisangaben(?: with Familienstand "(sich|sich, Partner|sich, Kinder|sich, Partner, Kinder)")?(?: and Vorschäden "([^"]*)")?$/,
  (familienstand, vorschaeden) => {
    if (familienstand) {
      selectDropdownValue('PH Eingabe Familienstand Dropdown', familienStandDropdownElements[familienstand]);
    }
    if (vorschaeden === 'Nein') {
      clickElement('PH Eingabe Vorschaeden Radio Nein');
    } else if (vorschaeden) {
      clickElement('PH Eingabe Vorschaeden Radio Ja');
      replaceText('PH Eingabe Vorschaeden PH Stepper Input', vorschaeden);
    }
    clickButton('Zum Angebot');
  }
);
