import { When } from '@badeball/cypress-cucumber-preprocessor';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout } from '../common/common';
import { familienStandDropdownElements } from './ph';
import {
  clickButton,
  clickConditionalElement,
  clickElement,
  replaceText,
  selectDropdownValue,
} from '../common/interactions';

When(/^I fill RS Basisangaben with Familienstand "(sich|sich, Partner|sich, Kinder|sich, Partner, Kinder)"(?: Arbeit "(Selbstsaendig|Oeffentlicher Dienst|Geschaeftsfuehrer Vorstand)")?(?: Rechtsstreit "(Nein|Ja)")?$/,
  (familienstand, arbeit, streit) => {
    const familienStandText = familienStandDropdownElements[familienstand];
    selectDropdownValue('RS Eingabe Familienstand Dropdown', familienStandText);
    clickConditionalElement(streit, `RS Eingabe Rechtsstreitigkeiten Radio ${streit}`);
    clickConditionalElement(arbeit, `RS Eingabe ${arbeit} Checkbox`);
    clickButton('Zum Angebot');
  }
);

When(/^I choose Vermieter Zusatzoption with "([^"]*)" Objekten$/, (anzahl) => {
  cy.get(getSelector('RS Angebot Zusatzoptionen Vermieter'), {
    timeout: globalTimeout,
  })
    .contains(
      getSelector('Button'),
      getTextOrRegex(replaceCustomTextCommands('Berechnen')),
      { timeout: globalTimeout }
    )
    .click();

  const anzahlInt = parseInt(anzahl, 10) - 1;
  for (let i = 0; i < anzahlInt; i++) {
    cy.get(getSelector('RS Zusatzoption Vermietetes Objekt hinzufuegen'), {
      timeout: globalTimeout,
    }).click();
  }
});

When(/^I fill Vermieter Objekt "([^"]*)" with "([^"]*)"(?: (und schließe das Modal))?$/,
  (anzahl, wohnung, close) => {
    const anzahlInt = parseInt(anzahl, 10) - 1;
    const wohnungWerteArray = wohnung.split(' ');
    let j = 0;
    while (j < wohnungWerteArray.length) {
      switch (wohnungWerteArray[j]) {
        case 'Bebaut': {
          cy.get(
            getSelector(
              `RS Zusatzoption Vermietetes Objekt Bebaut Radio ${
                wohnungWerteArray[j + 1]
              } ${anzahlInt}`
            ),
            { timeout: globalTimeout }
          ).click();
          break;
        }
        case 'Ort':
        case 'Hausnummer':
        case 'Flurstücknummer':
        case 'Grundstueckflaeche':
        case 'PLZ': {
          replaceText(
            `RS Zusatzoption Vermietetes Objekt ${wohnungWerteArray[j]} Input ${anzahlInt}`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        case 'Stellplatzmiete': {
          replaceText(
            `RS Zusatzoption Vermietetes Objekt Stellplaetze Input ${anzahlInt}`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        case 'Gewerbemiete': {
          replaceText(
            `RS Zusatzoption Vermietetes Objekt Gewerbeeinheiten Input ${anzahlInt}`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        case 'Wohnmiete': {
          replaceText(
            `RS Zusatzoption Vermietetes Objekt Wohneinheiten Input ${anzahlInt}`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        case 'Gewerbeeinheiten':
        case 'Stellplaetze':
        case 'Wohneinheiten': {
          replaceText(
            `RS Zusatzoption Vermietetes Objekt ${wohnungWerteArray[j]} Stepper ${anzahlInt} Input`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        case 'Strasse': {
          selectDropdownValue(
            `RS Zusatzoption Vermietetes Objekt ${wohnungWerteArray[j]} Dropdown ${anzahlInt}`,
            wohnungWerteArray[j + 1]
          );
          break;
        }
        default: {
          break;
        }
      }
      j += 2;
    }
    if (close) {
      cy.get(
        getSelector('RS Zusatzoption VermieteteObjekte Uebernehmen Button'),
        { timeout: globalTimeout }
      ).click();
    }
  }
);
