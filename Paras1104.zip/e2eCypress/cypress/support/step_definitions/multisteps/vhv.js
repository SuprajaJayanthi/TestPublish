import {Then, When} from '@badeball/cypress-cucumber-preprocessor';
import {
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands,
} from '../common/helpers';
import { globalTimeout } from '../common/common';
import {
  clickButton,
  clickConditionalElement,
  clickElement,
  replaceConditionalText,
  replaceText, selectConditionalDropdownValue,
  selectDropdownValue,
} from '../common/interactions';

let lastVhvAdress;

When(/^I fill VHV Basisangaben with(?: PLZ "([^"]*)")?(?: Ort "([^"]*)")?(?: Straße "([^"]*)")?(?: Hausnummer "([^"]*)")? Familienstand "([^"]*)"(?: bewohnt "(ständig|nicht ständig)")? Wohnflaeche "([^"]*)" Haushalt "(Einfamilienhaus|Mehrfamilienhaus)"(?: Geschoss "(Erdgeschoss|Obergeschoss)")?(?: Vorschaeden "([^"]*)")?(?: ausländische Adresse "(Ja|Nein)")?$/,
  (plz, ort, strasse, hausnummer, familienstand, bewohnt, flaeche, haushalt, geschoss, vorschaeden, auslaendischeAdresse) => {
    replaceConditionalText(plz, 'VHV Eingabe PLZ Input', plz);
    selectConditionalDropdownValue(ort,'VHV Eingabe Ort Dropdown', ort);
    selectConditionalDropdownValue(strasse,'VHV Eingabe Strasse Dropdown', strasse);
    replaceConditionalText(hausnummer, 'VHV Eingabe Hausnr Input', hausnummer);
    selectDropdownValue('VHV Eingabe Familienstand Dropdown', familienstand);
    selectConditionalDropdownValue(bewohnt, 'VHV Eingabe Bewohnt Dropdown', bewohnt);
    replaceText('VHV Eingabe Wohnflaeche Input', flaeche);

    if (vorschaeden === 'Nein') {
      cy.get(getSelector('VHV Eingabe Vorschaeden Radio ' + vorschaeden), { timeout: globalTimeout }).click();
    } else if (vorschaeden) {
      cy.get(getSelector('VHV Eingabe Vorschaeden Radio Ja'), { timeout: globalTimeout }).click();
      let i = 0;
      const vorschaedenArray = vorschaeden.split(' ');
      while (i < vorschaedenArray.length) {
        replaceText(`VHV Eingabe Vorschaeden ${vorschaedenArray[i]} Stepper Input`, vorschaedenArray[i + 1]);
        i += 2;
      }
    }

    clickElement(`VHV Eingabe Haushalt Radio ${haushalt}`)
    clickConditionalElement(geschoss, `VHV Eingabe Stockwerk Radio ${geschoss}`)
    if (auslaendischeAdresse) {
      clickElement('Vhv Auslaendische Adresse Checkbox')
    }
    clickButton('Zum Angebot');
    lastVhvAdress = `${strasse} ${hausnummer}, ${plz}`;
  }
);

When(/^I fill VHV Basisangaben$/, () => {
  selectDropdownValue('VHV Eingabe Familienstand Dropdown', "alleine");
  clickElement('VHV Eingabe Vorschaeden Radio Nein');
  clickButton('Zum Angebot');
});

export function getLastVhvAddress() {
  return lastVhvAdress;
}
