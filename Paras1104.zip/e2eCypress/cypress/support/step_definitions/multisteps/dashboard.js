import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getSelector, getTextOrRegex, replaceCustomTextCommands, } from '../common/helpers';
import { globalTimeout } from '../common/common';
import {
  clickButton,
  clickElement,
  clickElementAtIndex,
  replaceText,
  selectDropdownValue,
} from '../common/interactions';

When(/^I set Zahlungsperiode "(monatlich|vierteljährlich|halbjährlich|jährlich)" and Zahlungsart "(Rechnung|Lastschrift)"$/,
  (periode, art) => {
    cy.wait(3000);
    cy.get(getSelector('Toolbar Gesamtbeitrag Button'), {
      timeout: globalTimeout,
    }).click({
      force: Boolean(true),
    });
    if (periode === 'jährlich') {
      periode = '/^ jährlich $/';
    }
    selectDropdownValue('Toolbar Zahlungsweise Dropdown', periode);
    cy.get(getSelector('Toolbar Zahlungsart Radio Group'), {
      timeout: globalTimeout,
    })
      .contains(
        getSelector('Radio'),
        getTextOrRegex(replaceCustomTextCommands(art)),
        { timeout: globalTimeout }
      )
      .click();
  }
);

When(/^I set(?: RBD to "([^"]*)")?(?: and| ,)?(?: Treuebonus to "([^"]*)")? for "([^"]*)"$/,
  (rbd, tb, target) => {
    cy.get(getSelector('Toolbar Gesamtbeitrag Button'), {
      timeout: globalTimeout,
    }).click();
    cy.get(getSelector('Toolbar Vereinbarungen'), {
      timeout: globalTimeout,
    }).click();

    if (rbd && target) {
      cy.get(getSelector('Button'), { timeout: globalTimeout })
        .contains(getTextOrRegex(replaceCustomTextCommands('Risikobonus')), {
          timeout: globalTimeout,
        })
        .click();

      cy.get('[data-cy="toolbar-rbd-row"]', { timeout: globalTimeout })
        .contains(getTextOrRegex(replaceCustomTextCommands(target)))
        .parent()
        .parent()
        .within(() => {
          replaceText('Toolbar RBD Modal Number Stepper Input', rbd + '{tab}');
        });
    }

    if (tb && target) {
      cy.get(getSelector('Button'), { timeout: globalTimeout })
        .contains(getTextOrRegex(replaceCustomTextCommands('Treuebonus')), {
          timeout: globalTimeout,
        })
        .click();

      cy.get('[data-cy="toolbar-tb-row"]', { timeout: globalTimeout })
        .contains(getTextOrRegex(replaceCustomTextCommands(target)))
        .parent()
        .parent()
        .within(() => {
          replaceText('Toolbar TB Modal Number Stepper Input', tb + '{tab}');
        });
    }

    cy.get(getSelector('Toolbar RBD Modal Button'), {
      timeout: globalTimeout,
    }).click();
  }
);

When(/^I (select|toggle|modify) Assekuranztarif$/,
  action => {
    clickElement('Toolbar VN Box');
    if (action !== 'modify') {
      clickElement('Toolbar VN Assekuranztarif');
    } else {
      clickElement('Toolbar VN Assekuranztarif Button');
    }
    if (action === 'toggle') {
      clickElement('Toolbar VN Box');
    }
  }
);

When(/^I create new Angebot "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|Unfall|Gegenstandsschutz|Jagdhaft)"(?: and choose Immobilie with PLZ "([^"]*)")?$/,
  (strecke, plz) => {
    clickElement('Dashboard Produktkarte ' + strecke);
    cy.wait(3000);
    clickElement('Dashboard Angebotsuebersicht ' + strecke, 'Berechnen');
    if (['VWG', 'VHV'].includes(strecke)) {
      if (plz) {
        clickElement('Dashboard Immobilienauswahl Dialog', plz);
        clickElement('Dashboard Immobilienauswahl Dialog', 'Weiter');
      } else {
        clickElement('Immobilienauswahl Neue Adresse Radio');
        clickElement('Dashboard Immobilienauswahl Dialog', 'Weiter');
      }
    } else if (strecke === 'Unfall') {
      cy.wait(1000);
      clickElement('Personenauswahl Element Peter');
      clickButton('Weiter');
    }
  }
);

When(/^I create new Angebot from Vorvertrag at index "([0-9])"$/,
  index => {
    clickElementAtIndex('Dashboard Vorvertrag', index);
  }
);

When(/^I create Beibehaltung from Vorvertrag at index "([0-9])"$/,
  index => {
    clickElementAtIndex('Dashboard Vorvertrag Beibehalten Button', index);
  }
);

When(/^I remove Fremdvertrag at index "([0-9])" and "(cancel|confirm)"$/,
  (index, action) => {
    clickElementAtIndex("Dashboard Fremdvertrag Options Button", index);
    clickElement("Dashboard Delete Fremdvertrag Button");
    if (action === 'cancel') {
      clickElement("Modal secondary button");
    } else {
      clickElement("Modal primary button");
    }
  }
);

When(/^I open Angebot "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|Unfall|Gegenstandsschutz|Jagdhaft)"(?: with Adresse "([^"]*)")?$/,
  (strecke, adresse) => {
    clickElement('Dashboard Angebotsuebersicht ' + strecke, 'Berechnen');
    if (['VWG', 'VHV'].includes(strecke)) {
      clickElement('Immobilienauswahl Valide Adressen', adresse);
      clickElement('Dashboard Immobilienauswahl Dialog', 'Weiter');
    } else if (strecke === 'Unfall') {
      cy.wait(1000);
      clickElement('Personenauswahl Dialog', 'Weiter');
    }
  }
);

When(/^I add "([1-9])" Unfallzählstücke$/,
  number => {
    for (let i = 0; i < number; i++) {
      clickElement("Dashboard Angebotsuebersicht Unfall Zaehlstuecke Button");
    }
  }
);

When(/^I choose "(Ja|Nein)" in the RS Zusammenfuehren Modal and click "(Bestaetigen|Abbrechen)"$/,
  (radio, button) => {
    clickElement(`Dashboard RS Zusammenfuehren Modal ${radio} Radio`);
    clickElement(`Dashboard RS Zusammenfuehren Modal ${button} Button`);
  }
);

When(/^I select the checkboxes in the Dashboard EHV Dialog containing the (?:text|texts): "(.*)"/,
  (texts) => {
    const textArray = texts.split(',').map((t) => t.trim());

    textArray.forEach((text) => {
      cy.get(getSelector("Dashboard EHV Dialog"), { timeout: globalTimeout })
        .contains(
          getSelector("Checkbox"),
          getTextOrRegex(replaceCustomTextCommands(text)),
          { timeout: globalTimeout }
        )
        .click();
    })
  }
);