import {
  getSelector,
  getTextOrRegex,
  isDataCySelector,
  replaceCustomTextCommands,
} from './helpers';
import {globalTimeout} from './common';

export function clickButton(text) {
  cy.contains(
    getSelector('Button'),
    getTextOrRegex(replaceCustomTextCommands(text)),
    { timeout: globalTimeout }
  ).click();
}

export function clickElement(selector, text) {
  if (!text) {
    cy.get(getSelector(selector), { timeout: globalTimeout }).click();
  } else {
    cy.get(getSelector(selector), { timeout: globalTimeout })
      .contains(getTextOrRegex(replaceCustomTextCommands(text)), { timeout: globalTimeout })
      .click();
  }
}

export function clickConditionalElement(condition, selector, text) {
  if (condition) {
    clickElement(selector, text);
  }
}

export function clickElementAtIndex(selector, index) {
  cy.get(getSelector(selector)(index), {timeout: globalTimeout}).click();
}

export function selectDropdownValue(dropdownElement, value, index) {
  let selector;
  if (isDataCySelector(dropdownElement)) {
    selector = dropdownElement;
  } else {
    selector = index != null
      ? getSelector(dropdownElement)(index)
      : getSelector(dropdownElement);
  }
  cy.get(selector, { timeout: globalTimeout})
    .trigger('mouseover')
    .click()
    .then(($dropdown) => {
      cy.get('body').then((body) => {
        if (body.find(getSelector('Dropdown Option')).length === 0) {
          cy.wrap($dropdown).click();
        }
      }).then(() => {
        clickElement('Dropdown Option', value)
      });
    });
}

export function selectConditionalDropdownValue(condition, dropdownElement, value, index) {
  if (condition) {
    selectDropdownValue(dropdownElement, value, index);
  }
}

export function replaceText(element, text, index) {
  const selector =
    index != null ? getSelector(element)(index) : getSelector(element);
  cy.get(selector, { timeout: globalTimeout }).clear();
  if (text && text.length > 0) {
    cy.get(selector, { timeout: globalTimeout })
      .type('{selectall}')
      .typeWithTabSupport(replaceCustomTextCommands(text));
    cy.get(selector)
      .invoke('val')
      .then((val) => {
        expect(val).to.contain(text.replace('{tab}', ''));
      });
  }
}

export function replaceConditionalText(condition, element, text, index) {
  if (condition) {
    replaceText(element, text, index);
  }
}
