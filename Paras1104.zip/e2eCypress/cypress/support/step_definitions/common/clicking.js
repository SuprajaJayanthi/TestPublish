import { When } from '@badeball/cypress-cucumber-preprocessor';
import { clickMultiple, getSelector, getTextOrRegex, replaceCustomTextCommands, } from './helpers';
import { globalTimeout } from './common';
import { clickButton } from "./interactions";

When(/^I (force )?click (?:a |on |into )?(?:the )?"([^"]*)" (element|elements)$/,
  (force, element, type) => {
    cy.get(getSelector(element), { timeout: globalTimeout }).click({
      multiple: clickMultiple(type),
      force: Boolean(force),
    });
  }
);

When(/^I (force )?click (?:a |on |into )?(?:the )?"([^"]*)" (element|elements) ([0-9]+) times$/,
  (force, element, type, n) => {
    for (let i = 0; i < parseInt(n); ++i) {
      cy.get(getSelector(element), { timeout: globalTimeout }).click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
    }
  }
);

When(/^I (force )?click (?:a |on |into )?(?:all )?(?:the )?"([^"]*)" (text|texts)$/,
  (force, text, type) => {
    cy.contains(getTextOrRegex(replaceCustomTextCommands(text)), {
      timeout: globalTimeout,
    }).click({
      multiple: clickMultiple(type),
      force: Boolean(force),
    });
  }
);

When(/^I (force )?click (?:on )?(?:the )?"([^"]*)" (element|elements) containing "([^"]*)" text$/,
  (force, element, type, text) => {
    cy.contains(
      getSelector(element),
      getTextOrRegex(replaceCustomTextCommands(text)),
      { timeout: globalTimeout }
    ).click({
      multiple: clickMultiple(type),
      force: Boolean(force),
    });
  }
);

When(/^I (force )?click on "([^"]*)" (element|elements) at index "([^"]*)"$/,
  (force, element, type, index) => {
    cy.get(getSelector(element)(index)).click({
      multiple: clickMultiple(type),
      force: Boolean(force),
    });
  }
);

When(/^I (force )?click (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" (element|elements) (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" element$/,
  (force, element1, type, element2) => {
    cy.get(getSelector(element2), { timeout: globalTimeout })
      .find(getSelector(element1), { timeout: globalTimeout })
      .first()
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I (force )?click (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" (text|texts) (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" element$/,
  (force, text, type, element1) => {
    cy.get(getSelector(element1), { timeout: globalTimeout })
      .contains(getTextOrRegex(replaceCustomTextCommands(text)), {
        timeout: globalTimeout,
      })
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I (force )?click (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" (element|elements) (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" element containing "([^"]*)" text$/,
  (force, element1, type, element2, text) => {
    cy.get(getSelector(element2), { timeout: globalTimeout })
      .contains(
        getSelector(element1),
        getTextOrRegex(replaceCustomTextCommands(text)),
        { timeout: globalTimeout }
      )
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I (force )?click on "([^"]*)" (element|elements) at index "([^"]*)" containing "([^"]*)" text$/,
  (force, element, type, index, text) => {
    cy.get(getSelector(element)(index))
      .contains(
        getSelector(element),
        getTextOrRegex(replaceCustomTextCommands(text))
      )
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I (force )?click (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" (element|elements) (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" element at index "([^"]*)" containing "([^"]*)" text$/,
  (force, element1, type, element2, index, text) => {
    cy.get(getSelector(element2)(index))
      .contains(
        getSelector(element1),
        getTextOrRegex(replaceCustomTextCommands(text))
      )
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I (force )?click (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" (element|elements) (?:on |of |in |inside |inside of )?(?:the )?"([^"]*)" element at index "([^"]*)"$/,
  (force, element1, type, element2, index) => {
    cy.get(getSelector(element2)(index))
      .contains(getSelector(element1))
      .click({
        multiple: clickMultiple(type),
        force: Boolean(force),
      });
  }
);

When(/^I click Zum Angebot$/, () => {
    clickButton('Zum Angebot');
  }
);

When(/^I click Angebot übernehmen$/, () => {
    clickButton('Angebot übernehmen')
  }
);

When(/^I click ERNEUT VERSUCHEN$/, () => {
    clickButton('ERNEUT VERSUCHEN');
  }
);
