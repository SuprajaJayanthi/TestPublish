import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getLatestBffVersionForHeader } from '../../commands';
import { addWeeks, format, subDays } from "date-fns";

export const method = 'POST';
export const statusCode = 200;

export const pollingId = '1234567890';

When(/^I add Kundennummer to AmisCrm(?: for "(Checkout mit BSVTNR|Checkout ohne E-Mail|VWG Elementar|VWG Ersatzgeschäft)")?$/,
  addition => {
    let filePath = 'shared/einstieg';
    switch (addition) {
      case "Checkout mit BSVTNR":
        filePath = 'sonstiges/checkout/einstieg-mit-bsvtnr';
        break;
      case "Checkout ohne E-Mail":
        filePath = 'sonstiges/checkout/einstieg-ohne-email';
        break;
      case 'VWG Elementar':
        filePath = 'ersatzgeschaeft/weitere-tests/vwg-elementar/einstieg';
        break;
      case 'VWG Ersatzgeschäft':
        filePath = 'ersatzgeschaeft/weitere-tests/vwg-mehrfamilienhaus/einstieg';
        break;
    }
    cy.fixture(filePath).then(body => {
      const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
      cy.intercept('/privatschutz/api/einstieg', { method, headers, statusCode, body }).as('amisCRM');
    });
  }
);

When(/^I activate Load Vorgang Mock with Fixture File "([^"]*)"$/,
  filename => {
    cy.request('GET', '/privatschutz/api/authenticate', { role: 'vertreter', anonym: true })
      .then(() => {
        cy.fixture(`sonstiges/${filename}`).then(body => {
          const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
          cy.intercept('/privatschutz/api/load', { method, headers, statusCode, body });
        });
      });
  }
);

When(/^I activate AZAM Einstieg Mock$/, () => {
  cy.fixture('azam/einstieg').then(body => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.intercept('/privatschutz/api/einstieg', { method, headers, statusCode, body }).as('amisCRM');
  });
});

When(/^I activate Vertragsübersicht Service Mock for "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|UNF|GEGE|JHP)" with "(Umstellung Zwang|Umstellung optional|Beibehaltung|Nicht umstellbar)"$/,
  (angebot, option) => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.fixture(`ersatzgeschaeft/basis-tests/${angebot.toLowerCase()}/vertragsuebersicht`)
      .then(body => {
        const produkt = body.standardProdukte[0];
        produkt.beibehaltung = option === 'Beibehaltung';
        produkt.umstellungszwang = option === 'Umstellung Zwang';
        produkt.ersetzen = option !== 'Nicht umstellbar';
        produkt.infoText = option === 'Nicht umstellbar'
          ? 'Der Vertrag wurde ab Beginn storniert. Bitte reichen Sie den Antrag als Neugeschäft ein.'
          : null;
        cy.intercept('/privatschutz/api/vertragsuebersicht', { method, headers, statusCode, body });
      });
  }
);

When(/^I activate Vertragsübersicht Service Mock for VHV with Vorbelegungsdaten staendigBewohnt "([^"]*)", versicherungssumme "([^"]*)" and wertsachensumme "([^"]*)"$/,
  (staendigBewohnt, versicherungssumme, wertsachensumme) => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.fixture('ersatzgeschaeft/weitere-tests/vhv-wertsachensumme/vertragsuebersicht-ohne-vorversicherungssumme')
      .then(body => {
        const vorbelegungdaten = body.standardProdukte[0].vorbelegungdaten[0].vorbelegungdaten;
        vorbelegungdaten.staendigBewohnt = staendigBewohnt;
        vorbelegungdaten.versicherungssumme = +versicherungssumme;
        vorbelegungdaten.wertsachensumme = +wertsachensumme;
        cy.intercept('/privatschutz/api/vertragsuebersicht', { method, headers, statusCode, body });
      });
  }
);

When(/^I activate Vertragsübersicht Service Mock for VHV with modified Wirksamkeitsbeginn$/, () => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    const wirksamkeitsbeginn = format(subDays(addWeeks(new Date(), 2), 1), 'yyyy-MM-dd');
    cy.fixture('sonstiges/beibehaltung/vertragsuebersicht-wirksamkeitsbeginn')
      .then(body => {
        body.standardProdukte[0].vorbelegungdaten[0].vorbelegungdaten.wirksamkeitsbeginn = wirksamkeitsbeginn;
        body.standardProdukte[2].vorbelegungdaten[0].vorbelegungdaten.wirksamkeitsbeginn = wirksamkeitsbeginn;
        cy.intercept('/privatschutz/api/vertragsuebersicht', { method, headers, statusCode, body });
      });
  }
);

When(/^I activate Vertragsübersicht Service Mock with Fixture File "([^"]*)"(?: for "(AZAM|Ersatzgeschaeft|Sonstiges)")?$/,
  (fileName, type) => {
    let folder = 'ersatzgeschaeft/weitere-tests';
    if (type === 'AZAM') {
      folder = 'azam';
    } else if (type === 'Sonstiges') {
      folder = 'sonstiges';
    }
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.fixture(`${folder}/${fileName}`).then(body => {
      cy.intercept('/privatschutz/api/vertragsuebersicht', { method, headers, statusCode, body });
    });
  }
);

When(/^I activate Fremdvertragsübersicht Service Mock with Fixture File "([^"]*)"(?: for "(AZAM|Ersatzgeschaeft)")?$/,
  (fileName, type) => {
    const folder = type === 'AZAM' ? 'azam' : 'ersatzgeschaeft/weitere-tests';
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.fixture(`${folder}/${fileName}`).then(body => {
      cy.intercept('/privatschutz/api/fremdvertragsuebersicht', { method, headers, statusCode, body });
    });
  }
);

When(/^I activate Vertragsdaten Service Mock(?: with Familienstand "(SINGLE|FAMILIE|PARTNER|KIND)")?(?: with(?: "([1-2])" Hunde)?(?: "([1-2])" Pferde)?(?: (ohne Pferdegrößen))?)?$/,
  (familienstand, hunde, pferde, ohnePferdeGroessen) => {
    let body;
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    if (familienstand) {
      body = { familienstand };
    } else if (hunde) {
      const tierrasse = hunde === '1' ? ['H263'] : ['H263', 'H094'];
      body = { anzTiere: +hunde, tierrasse }
    } else {
      body = { anzTiere: +pferde };
      if (!ohnePferdeGroessen) {
        body.stockmassListe = pferde === '1' ? ['KLEINPFERD'] : ['KLEINPFERD', 'GROSSPFERD'];
      }
    }
    cy.intercept('/privatschutz/api/vertragsdaten', { method, headers, statusCode, body });
  }
);

When(/^I activate Vertragsdaten Service Mock with Fixture File "([^"]*)"(?: for "(Ersatzgeschaeft|Sonstiges)")?$/,
  (fileName, type) => {
    const folder = type === 'Sonstiges' ? 'sonstiges' : 'ersatzgeschaeft/weitere-tests';
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.fixture(`${folder}/${fileName}`).then(body => {
      cy.intercept('/privatschutz/api/vertragsdaten', { method, headers, statusCode, body });
    });
  }
);

When(/^I activate Vertragsdaten Service Mock for Multiple PH Vorverträge and Fremdverträge$/, () => {
  const answers = [];
  let numberOfIntercepts = 0;
  cy.fixture('ersatzgeschaeft/weitere-tests/vn-wechsel/vertragsuebersicht-ph-vhv').then(resp => answers.push(resp));
  cy.fixture('ersatzgeschaeft/weitere-tests/vn-wechsel/vertragsuebersicht-ph-vhv-fremdvertraege').then(resp => answers.push(resp));
  cy.fixture('ersatzgeschaeft/weitere-tests/vn-wechsel/vertragsuebersicht-ph-vhv-invalid').then(resp => answers.push(resp));

  cy.intercept('POST', '/privatschutz/api/vertragsuebersicht', req => {
      if (numberOfIntercepts < 4) {
        const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
        req.reply(statusCode, answers[numberOfIntercepts], headers);
      } else {
        req.continue();
      }
      numberOfIntercepts++;
    }
  );
});

When(/^I activate Vorvertrag Tarifierung Mock for "(PH|VHV|RS|VWG|THH-Hund|THH-Pferd|TKV|UNF|GEGE|JHP)"(?: with Fixture File "([^"]*)")?$/,
  (angebot, filePath) => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    const taasName = ['THH-Hund', 'THH-Pferd'].includes(angebot) ? 'thh' : angebot.toLowerCase();
    filePath = filePath ? filePath : `ersatzgeschaeft/basis-tests/${angebot.toLowerCase()}/tarifierung`;
    cy.fixture(filePath)
      .then(body =>
        cy.intercept(`/privatschutz/api/taas/${taasName}`, { method, headers, statusCode, body })
      ).as(`${taasName}TaasCall`);
  }
);

When(/^I activate Vorvertrag Tarifierung Mock for Multiple VHV Vorverträge$/,
  () => {
    const answers = [];
    let numberOfIntercepts = 0;
    cy.fixture('sonstiges/beibehaltung/tarifierung-mpf-vhv-1').then(resp => answers.push(resp));
    cy.fixture('sonstiges/beibehaltung/tarifierung-mpf-vhv-2').then(resp => answers.push(resp));
    cy.fixture('sonstiges/beibehaltung/tarifierung-mpf-vhv-3').then(resp => answers.push(resp));

    return cy.intercept('POST', '/privatschutz/api/taas/vhv', req => {
        if (numberOfIntercepts < answers.length) {
          const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
          req.reply(statusCode, answers[numberOfIntercepts], headers);
        } else {
          req.continue();
        }
        numberOfIntercepts++;
      }
    );
  }
);

When(/^I activate Vorvertrag Tarifierung Mock for Multiple PH Vorverträge and Fremdverträge$/,
  () => {
    const answers = [];
    let numberOfIntercepts = 0;
    cy.fixture('ersatzgeschaeft/weitere-tests/vn-wechsel/tarifierung-ph-fremdvertrag-strecke').then(resp => answers.push(resp));
    cy.fixture('ersatzgeschaeft/weitere-tests/vn-wechsel/tarifierung-ph-fremdvertrag-shop').then(resp => answers.push(resp));

    return cy.intercept('POST', '/privatschutz/api/taas/ph', (req) => {
        if (numberOfIntercepts < answers.length) {
          const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
          req.reply(statusCode, answers[numberOfIntercepts], headers);
        } else {
          req.continue();
        }
        numberOfIntercepts++;
      }
    );
  });

When(/^I activate Vorgang Laden Mock with Fixture File "([^"]*)"$/,
  filePath => {
    cy.request('GET', '/privatschutz/api/authenticate', {
      role: 'vertreter',
      anonym: true,
    }).then(response => {
      cy.fixture(filePath.toString()).then(body => {
        const headers = { 'x-ps20-bff-version': response.headers['x-ps20-bff-version'] }
        cy.intercept('/privatschutz/api/load', { method, headers, statusCode, body });
      });
    });
  }
);

When(/^I activate Bank-Service Mock for IBAN "([^"]*)", Bankname "([^"]*)", BIC "([^"]*)"$/,
  (iban, institutName, swiftcode) => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    const body = {
      iban,
      institutName,
      wert: null,
      swiftcode,
      bankValidierungsStatus: 'OK',
    };
    cy.intercept('/privatschutz/api/bankService', { method, headers, statusCode, body });
  }
);

When(/^I deactivate Bank-Service Mock$/, () => {
  cy.intercept('POST', '/privatschutz/api/bankService', req => req.continue());
});

When(/^I activate Tarifierung Service Mock with Success for VHV$/, () => {
    cy.fixture('sonstiges/kartenfenster/taas-success-vhv')
      .then(body => {
        const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
        cy.intercept(`/privatschutz/api/taas/vhv`, { method, headers, statusCode, body, delay: 500 });
      }).as('vhvTaasCallSuccess');
  }
);

When(/^I activate Adressverzeichnis-Service Mock$/, () => {
  const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
  const body = {
    strassen: ['Hopfenstr.', 'Marsplatz', 'Erzgießereistr.'],
    orte: ['München'],
    adressen: null,
    suchkriterium: null,
    meldung: null,
    status: null,
  };
  cy.intercept('/privatschutz/api/adressverzeichnis', { method, headers, statusCode, body });
});

When(/^I activate Programmteilnahme Mock$/, () => {
  cy.intercept('/privatschutz/api/findprogrammteilnahme', {
    method: 'POST',
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 200,
    body: {
      programmteilnahmeEmail: 'email@email.de',
      programmname: 'MEINEALLIANZ',
      programmteilnahmeStatus: 'AKTIV',
      programmteilnahmeEmailFieldBehaviour: 'GESPERRT',
    },
  });
});

When(/^I activate Programmteilnahme Mock with E-Mail "([^"]*)" and Field Behaviour "(OFFEN|EDITIERBAR|GESPERRT)" and Programmname "(MEINEALLIANZ|DIGITALEKOMMUNIKATION|DIGITALEVOLLPOLICE)"$/,
  (email, behavior, name) => {
    cy.intercept('/privatschutz/api/findprogrammteilnahme', {
      method: 'POST',
      headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
      statusCode: 200,
      delay: 1000,
      body: {
        programmteilnahmeEmail: email,
        programmname: name,
        programmteilnahmeStatus: 'AKTIV',
        programmteilnahmeEmailFieldBehaviour: behavior,
      },
    });
  }
);

When(/^I activate Immobiliensuche-Service Mock$/, () => {
  cy.fixture('shared/immobiliensuche').then(body => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.intercept('/privatschutz/api/amiscrmsucheImmobilien', { method, headers, statusCode, body });
  });
});

When(/^I activate Personensuche Service Mock$/, () => {
  cy.fixture('shared/personensuche').then(body => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.intercept('/privatschutz/api/personensuche', { method, headers, statusCode, body });
  });
});

When(/^I activate Infopaket Mock$/, () => {
  cy.fixture('sonstiges/mein-haushalt/dokumentenerstellung').then(body => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    cy.intercept('/privatschutz/api/dokumentenerstellung', { method, headers, statusCode, body });
  });
});

When(/^I activate Einreichen Polling Mock$/, () => {
  const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
  cy.intercept('/privatschutz/api/einreichen/async',
    { method, headers, statusCode, body: { id: pollingId },
  });
  cy.intercept(`/privatschutz/api/einreichen/poll?pollingId=${pollingId}`,
    { method: 'GET', headers, statusCode, body: { pollingStatus: 'FINISHED' },
  });
});

When(/^I activate the Polling Einreichen With eSign Mock$/, () => {
  const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
  cy.intercept(`/privatschutz/api/einreichenwithesign/async`,
    { method, headers, statusCode, body: { id: pollingId },
  });
  cy.intercept(`/privatschutz/api/einreichenwithesign/poll?pollingId=${pollingId}`,
    { method: 'GET', headers, statusCode, body: { pollingStatus: 'FINISHED' },
  });
});