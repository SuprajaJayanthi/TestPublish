import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getSelector, replaceCustomTextCommands } from './helpers';
import { globalTimeout } from './common';
import dayjs from 'dayjs';

When(/^I type "([^"]*)" text (?:in |into )(?:the )?"([^"]*)" element$/,
  (text, element) => {
    cy.get(getSelector(element), { timeout: globalTimeout }).typeWithTabSupport(
      replaceCustomTextCommands(text)
    );
  }
);

When(/^I replace the contents of "([^"]*)" element with "([^"]*)" text$/,
  (element, text) => {
    cy.get(getSelector(element), { timeout: globalTimeout }).clear();

    if (text && text.length > 0) {
      cy.get(getSelector(element), { timeout: globalTimeout })
        .type('{selectall}')
        .typeWithTabSupport(replaceCustomTextCommands(text));
    }
  }
);

When(/^I replace the contents of "([^"]*)" element at index "([^"]*)" with "([^"]*)" text$/,
  (element, index, text) => {
    cy.get(getSelector(element)(index)).clear();

    if (text && text.length > 0) {
      cy.get(getSelector(element)(index))
        .type('{selectall}')
        .typeWithTabSupport(replaceCustomTextCommands(text));
    }
  }
);

When(/^I type "([^"]*)" text (?:in |into )(?:the )?"([^"]*)" element at index "([^"]*)"$/,
  (text, element, index) => {
    cy.get(`${getSelector(element)(index)}`).typeWithTabSupport(
      replaceCustomTextCommands(text)
    );
  }
);

When(/^I replace the contents of "([^"]*)" element with today plus "([^"]*)" days plus "([^"]*)" month plus "([^"]*)" years$/,
  (element, days, months, years) => {
    cy.get(getSelector(element), { timeout: globalTimeout }).clear();

    const text = dayjs().startOf('day').add(years, 'years').add(months, 'months').add(days, 'days').format('DD.MM.YYYY');

    if (text && text.length > 0) {
      cy.get(getSelector(element), { timeout: globalTimeout })
        .type('{selectall}')
        .typeWithTabSupport(replaceCustomTextCommands(text));
    }
  }
);

When(/^I type "([^"]*)" text (?:in |into )(?:the )?"([^"]*)" element (?:on |in |inside |inside of )?(?:the )?"([^"]*)" element$/,
  (text, element1, element2) => {
    cy.get(getSelector(element2), { timeout: globalTimeout })
      .find(getSelector(element1), { timeout: globalTimeout })
      .typeWithTabSupport(replaceCustomTextCommands(text));
  }
);

When(/^I replace the contents of "([^"]*)" element (?:on |in |inside |inside of )?(?:the )?"([^"]*)" element with "([^"]*)" text$/,
  (element1, element2, text) => {
    replaceTextInsideElement(element1, element2, text);
  }
);

When(/^I leave the "([^"]*)" element (?:on |in |inside |inside of )?(?:the )?"([^"]*)" element$/,
  (element1, element2) => {
    cy.get(getSelector(element2), { timeout: globalTimeout })
    .find(getSelector(element1), { timeout: globalTimeout })
    .focus()
    .blur();
  }
);

When(/^I leave the "([^"]*)" element$/,
  (element1) => {
    cy.get(getSelector(element1), { timeout: globalTimeout })
    .focus()
    .blur();
  }
);

export function replaceTextInsideElement(element1, element2, text) {
  cy.get(getSelector(element2), { timeout: globalTimeout })
    .find(getSelector(element1), { timeout: globalTimeout })
    .clear();

  if (text && text.length > 0) {
    cy.get(getSelector(element2), { timeout: globalTimeout })
      .find(getSelector(element1), { timeout: globalTimeout })
      .type('{selectall}')
      .typeWithTabSupport(replaceCustomTextCommands(text));
  }
}
