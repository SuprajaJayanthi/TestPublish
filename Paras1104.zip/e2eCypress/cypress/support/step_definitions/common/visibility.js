import {Then} from '@badeball/cypress-cucumber-preprocessor';
import {
  attributeToCypressShould,
  getInputIfCheckboxOrSelect,
  getSelector,
  getTextOrRegex,
  inputAttributes,
  isRegex,
  replaceCustomTextCommands,
} from './helpers';
import {globalTimeout} from './common';

Then(/^I should see (?:a |an )?(?:the )?"([^"]*)" text$/, (text) => {
  cy.contains(getTextOrRegex(replaceCustomTextCommands(text)), {
    timeout: globalTimeout,
  })
    .first()
    .should('exist');
});

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements)$/,
  (numElements, attribute, element) => {
    const elements = getInputIfCheckboxOrSelect(
      attribute,
      cy.get(getSelector(element), {timeout: globalTimeout})
    );

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.each(($el) => {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      });
    }
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(readonly)? "([^"]*)" (field)$/,
  (numElements, attribute, element) => {
    cy.get(getSelector(element), {timeout: globalTimeout}).as('field');
    cy.get('@field').should('have.attr', attribute);
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:button|buttons)$/,
  (numElements, attribute, element) => {
    cy.get(getSelector(element), {timeout: globalTimeout}).as('button');
    cy.get('@button').should(attributeToCypressShould(attribute));
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:component|components)$/,
  (numElements, attribute, element) => {
    cy.get(getSelector(element), {timeout: globalTimeout}).as('component');
    cy.get('@component').should(attributeToCypressShould(attribute));
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:input|inputs)$/,
  (numElements, attribute, element) => {
    cy.get(getSelector(element), {timeout: globalTimeout}).as('input');
    cy.get('@input').should(attributeToCypressShould(attribute));
  }
);

Then(/^I should see (?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) containing "([^"]*)" text$/,
  (attribute, element, text) => {
    const transformedText = getTextOrRegex(replaceCustomTextCommands(text));
    const selector = getSelector(element);
    cy.contains(selector, transformedText, {timeout: globalTimeout}).within(
      () => {
        if (attribute && inputAttributes.includes(attribute.trim())) {
          cy.get('input', {timeout: globalTimeout}).should(
            attributeToCypressShould(attribute)
          );
        }
      }
    );
  }
);

Then(/^I see (?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) containing "([^"]*)" text$/,
  (attribute, element, text) => {
    const transformedText = getTextOrRegex(replaceCustomTextCommands(text));
    const selector = getSelector(element);
    cy.contains(selector, transformedText, {timeout: globalTimeout}).within(
      () => {
        if (attribute && inputAttributes.includes(attribute.trim())) {
          cy.contains('button', text);
        }
      }
    );
  }
);

Then(/^I should see (\d*\s+)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) containing "([^"]*)" text$/,
  (numElements, attribute, element, text) => {
    if (isRegex(text)) {
      throw new Error(
        'You can not use a regular expressions if you want to check for element count.'
      );
    }

    const elements = getInputIfCheckboxOrSelect(
      attribute,
      cy.get(
        `${getSelector(element)}:contains(${replaceCustomTextCommands(text)})`,
        {timeout: globalTimeout}
      )
    );

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.each(($el) => {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      });
    }
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements)$/,
  (numElements, attribute, element1, element2) => {
    const elements = getInputIfCheckboxOrSelect(
      attribute,
      cy.get(getSelector(element2), {timeout: globalTimeout})
    ).find(getSelector(element1), {timeout: globalTimeout});

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.each(($el) => {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      });
    }
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:button|buttons) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements)$/,
  (numElements, attribute, element1, element2) => {
    cy.get(getSelector(element2), {timeout: globalTimeout}).find(getSelector(element1), {timeout: globalTimeout}).as('button');
    cy.get('@button').should(attributeToCypressShould(attribute));
  }
);

Then(/^I should see (?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements) containing "([^"]*)" text$/,
  (attribute, element1, element2, text) => {
    getInputIfCheckboxOrSelect(
      attribute,
      cy
        .get(getSelector(element2), {timeout: globalTimeout})
        .contains(
          getSelector(element1),
          getTextOrRegex(replaceCustomTextCommands(text)),
          {timeout: globalTimeout}
        )
    ).should(attributeToCypressShould(attribute));
  }
);

Then(/^I should see the (checked |unchecked )?Checkbox (?:on |in |inside |inside of )?(?:the )?Dashboard EHV Dialog containing the (?:text|texts): "(.*)"/,
  (checkboxState, texts) => {
    const textArray = texts.split(',').map((t) => t.trim());

    textArray.forEach((text) => {
      getInputIfCheckboxOrSelect(
        checkboxState,
        cy
          .get(getSelector("Dashboard EHV Dialog"), {timeout: globalTimeout})
          .contains(
            getSelector("Checkbox"),
            getTextOrRegex(replaceCustomTextCommands(text)),
            {timeout: globalTimeout}
          )
      ).should(attributeToCypressShould(checkboxState));
    })
  }
);

Then(/^I should see (?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) with value "([^"]*)"$/,
  (attribute, element1, value) => {
    getInputIfCheckboxOrSelect(
      attribute,
      cy.get(getSelector(element1), {timeout: globalTimeout})
    ).should('have.value', value);
  }
);

Then(/^I should see (\d*\s+)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" element containing "([^"]*)" text$/,
  (numElements, attribute, element1, element2, text) => {
    if (isRegex(text)) {
      throw new Error(
        'You can not use a regular expressions if you want to check for element count.'
      );
    }

    const elements = getInputIfCheckboxOrSelect(
      attribute,
      cy.get(getSelector(element2), {timeout: globalTimeout})
    ).find(
      `${getSelector(element1)}:contains(${replaceCustomTextCommands(text)})`,
      {timeout: globalTimeout}
    );

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.each(($el) => {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      });
    }
  }
);

Then(/^I should see (?:the )?"([^"]*)" value (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element$/,
  (value, element) => {
    cy.get(getSelector(element), {timeout: globalTimeout}).first().should('have.value', value);
  }
);

Then(/^I should see (?:the )?"([^"]*)" text (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element$/,
  (text, element) => {
    containsText(text, element);
  }
);

Then(/^I should see (?:the )?"([^"]*)" texts (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element$/,
  (texts, element) => {
    texts.split(', ').forEach(text => {
      containsText(text, element)
    });
  }
);

Then(/^I should not see (?:a |an )?(?:the )?"([^"]*)" text$/, (text) => {
  cy.contains(getTextOrRegex(replaceCustomTextCommands(text)), {
    timeout: globalTimeout,
  }).should('not.exist');
});

Then(/^I should not see (?:a |an |any )?(?:the )?"([^"]*)" (?:element|elements)$/,
  (element) => {
    shouldNotBeVisible(element);
  }
);

Then(/^I should not see (?:a |an )?(?:the )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements)$/,
  (element1, element2) => {
    cy.get(getSelector(element2), {timeout: globalTimeout})
      .find(getSelector(element1), {timeout: globalTimeout})
      .should('not.exist');
  }
);

Then(/^I should not see (?:the )?"([^"]*)" text (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element$/,
  (text, element) => {
    doesNotContainText(element, text);
  }
);

Then(/^I should not see (?:the )?"([^"]*)" texts (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element$/,
  (texts, element) => {
    texts.split(', ').forEach(text => {
      doesNotContainText(element, text);
    });
  }
);

Then(/^I should not see (?:a |an )?(?:the )?"([^"]*)" element containing "([^"]*)" text$/,
  (element, text) => {
    cy.contains(
      getSelector(element),
      getTextOrRegex(replaceCustomTextCommands(text)),
      {timeout: globalTimeout}
    ).should('not.exist');
  }
);

Then(/^I should not see (?:a |an )?(?:the )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements) containing "([^"]*)" text$/,
  (element1, element2, text) => {
    cy.get(getSelector(element2), {timeout: globalTimeout})
      .contains(
        getSelector(element1),
        getTextOrRegex(replaceCustomTextCommands(text)),
        {timeout: globalTimeout}
      )
      .should('not.exist');
  }
);

Then(/^I should see (?:a |an |the )?"([^"]*)" element at index "([^"]*)" containing "([^"]*)" text$/,
  (element, index, text) => {
    cy.contains(`${getSelector(element)(index)}`,replaceCustomTextCommands(text));
  }
);

Then(/^I should see (?:a |an |the )?"([^"]*)" element at indexes "([^"]*)" containing "([^"]*)" text$/,
  (element, indexes, text) => {
    indexes.split(', ').forEach(index => {
      cy.get(
        `${getSelector(element)(index)}:contains(${replaceCustomTextCommands(text)})`
      );
    });
  }
);

Then(/^I should see (?:the )?"([^"]*)" text (?:on |inside |inside of )?(?:the |a )?"([^"]*)" element at index "([^"]*)"$/,
  (text, element, index) => {
    cy.contains(
      getSelector(element)(index),
      getTextOrRegex(replaceCustomTextCommands(text)),
      { timeout: globalTimeout }
    )
      .first()
      .should('exist');
  }
);

Then(/^I should not see (?:the |a )?"([^"]*)" element at index "([^"]*)"$/,
  (element, index) => {
    cy.contains(getSelector(element)(index), { timeout: globalTimeout }).should(
      'not.exist'
    );
  }
);

Then(/^I should see (\d*\s?)(?:a |an |the )?(disabled |enabled |checked |unchecked |selected |deselected |unselectable |selectable )?"([^"]*)" (?:element|elements) at (?:index|indices) "([^"]*)"$/,
  (numElements, attribute, element, indices) => {
    const indexArray = indices.split(',').map((t) => t.trim());

    let elements = [];
    indexArray.forEach(index => {
      elements.push(getInputIfCheckboxOrSelect(attribute,
        cy.get(getSelector(element)(index), { timeout: globalTimeout })));
    })

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.forEach(elem => {
          elem.each(($el) => {
            cy.wrap($el).should(attributeToCypressShould(attribute));
          });
        }
      )
    }
  }
);

Then(/^I should see (\d*\s?)(?:a |an )?(?:the )?(disabled |enabled |checked |unchecked |selected |deselected )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements) at index "([^"]*)"$/,
  (numElements, attribute, childElem, parentElem, index) => {
    const elements = getInputIfCheckboxOrSelect(
      attribute,
      cy.get(getSelector(parentElem)(index))
    ).find(getSelector(childElem));

    if (numElements) {
      elements.should('have.length', numElements);
    }

    if (attribute) {
      elements.each(($el) => {
        cy.wrap($el).should(attributeToCypressShould(attribute));
      });
    }
  }
);

Then(/^I should not see (?:a |an )?(?:the )?"([^"]*)" (?:element|elements) (?:on |in |inside |inside of )?(?:the )?"([^"]*)" (?:element|elements) at index "([^"]*)"$/,
  (childElem, parentElem, index) => {
    cy.get(getSelector(parentElem)(index))
      .contains(getSelector(childElem))
      .should('not.exist');
  }
);

Then(/^The element with id "([^"]*)" should be focused$/, (id) => {
  cy.focused().should('have.attr', 'id', id);
});

function containsText(text, element) {
  cy.contains(
    getSelector(element),
    getTextOrRegex(replaceCustomTextCommands(text)),
    {timeout: globalTimeout}
  )
    .first()
    .should('exist');
}


function doesNotContainText(element, text) {
  cy.contains(
    getSelector(element),
    getTextOrRegex(replaceCustomTextCommands(text)),
    {timeout: globalTimeout}
  ).should('not.exist');
}

export function shouldNotBeVisible(element) {
  cy.get('body').then(($body) => {
    if ($body.find(getSelector(element), {timeout: globalTimeout}).length) {
      cy.get(getSelector(element), {timeout: globalTimeout})
        .children()
        .should('have.length', 0);
    } else {
      cy.get(getSelector(element), {timeout: globalTimeout}).should(
        'not.exist'
      );
    }
  });
}
