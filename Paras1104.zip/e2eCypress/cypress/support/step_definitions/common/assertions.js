import { Then } from '@badeball/cypress-cucumber-preprocessor';
import {
  attributeToCypressShould,
  getInputIfCheckboxOrSelect,
  getSelector,
  getTextOrRegex,
  replaceCustomTextCommands
} from './helpers';
import { globalTimeout } from "./common";

Then(/^I should see an Error Page$/, () => {
  cy.get('#errorpage').then((element) => {
    expect(element).to.not.equal(null);
  });
});

Then(/^I should see a valid Gesamtpreis$/, () => {
  cy.get('nxt-price-tag[data-cy="shop-toolbar-gesamtbeitrag"]').then(
    (element) => {
      assert.include(element.text(), ',');
      assert.notInclude(element.text(), '0,00');
    }
  );
});

Then(/^Dokumentenerstellung should be successful/, (value) => {
  cy.wait('@dokumentenerstellung')
    .its('response')
    .should('have.property', 'statusCode', 200);
});

Then(/^The eSign Upload with Vertragsschlussverfahren "([^"]*)" should be called$/, (value) => {
  cy.wait('@esignUpload')
    .then((xhr) => {
      expect(xhr.request.body.vertragsschlussverfahren).to.equal(value.toUpperCase());
    })
});

Then(/^I should see Dashboard Tabelle Vorvertraege and Dashboard Angebotsuebersicht VWG$/,
  () => {
    cy.get(getSelector("Dashboard Tabelle Vorvertraege"), { timeout: globalTimeout })
    cy.get(getSelector("Dashboard Angebotsuebersicht VWG"), { timeout: globalTimeout })
  }
);

Then(/^The Standalone-Produktauswahl Dialog should contain "([^"]*)"$/,
  (text) => {
    cy.contains(getSelector("Dashboard Standaloneproduktauswahl Dialog"),
      getTextOrRegex(replaceCustomTextCommands(text)),
      {timeout: globalTimeout}
    ).first().should('exist');
    cy.get(getSelector("Dashboard Standard Modal Checkbox")(0), {timeout: globalTimeout})
    cy.get(getSelector("Dashboard Hinweismeldung gleiche Adresse"), {timeout: globalTimeout})
    getInputIfCheckboxOrSelect(
      "checked ",
      cy
        .get(getSelector("Dashboard Standard Modal Checkbox"), {timeout: globalTimeout})
        .contains(
          getSelector("Checkbox"),
          getTextOrRegex(replaceCustomTextCommands(text)),
          {timeout: globalTimeout}
        )
    ).should(attributeToCypressShould("checked "));
  }
);

Then(/^I should see(?: PLZ "([^"]*)")?(?: Ort "([^"]*)")?(?: Straße "([^"]*)")?(?: Hausnummer "([^"]*)")?(?: Wohnfläche "([^"]*)")? text on the VHV Eingabe Page$/,
  (plz, ort, strasse, hausnummer, wohnflaeche) => {
    cy.contains(getSelector("VHV Eingabe PLZ Vorbelegt"),
      getTextOrRegex(replaceCustomTextCommands(plz)),
      {timeout: globalTimeout}
    ).first().should('exist');
    cy.contains(getSelector("VHV Eingabe Ort Vorbelegt"),
      getTextOrRegex(replaceCustomTextCommands(ort)),
      {timeout: globalTimeout}
    ).first().should('exist');
    cy.contains(getSelector("VHV Eingabe Strasse Vorbelegt"),
      getTextOrRegex(replaceCustomTextCommands(strasse)),
      {timeout: globalTimeout}
    ).first().should('exist');
    cy.contains(getSelector("VHV Eingabe Hausnr Vorbelegt"),
      getTextOrRegex(replaceCustomTextCommands(hausnummer)),
      {timeout: globalTimeout}
    ).first().should('exist');
    cy.contains(getSelector("VHV Eingabe Wohnflaeche Input"),
      getTextOrRegex(replaceCustomTextCommands(wohnflaeche)),
      {timeout: globalTimeout}
    ).first().should('exist');
  }
);