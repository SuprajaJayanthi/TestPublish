import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getRandomInt } from './helpers';
import {
  addDays,
  addMonths,
  addYears,
  format,
  subDays,
  subYears,
} from 'date-fns';
import {
  setFeatureToggles,
  startApp,
  startAppAsJuristischePerson,
} from '../../commands';
import { clickElement } from "./interactions";

export const globalTimeout = 60000;
export const increasedTimeout = 120000;

let storedCryptId;

Cypress.config({
  defaultCommandTimeout: globalTimeout,
  pageLoadTimeout: globalTimeout,
  requestTimeout: globalTimeout,
  responseTimeout: globalTimeout,
});

export const textCommandMapping = {
  '{Tagesdatum + 1 Jahr und 1 Tag}': (() =>
    format(addYears(addDays(new Date(), 1), 1), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 1 Jahr und 14 Tage}': (() =>
    format(addYears(addDays(new Date(), 14), 1), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 2 Jahre und 1 Tag}': (() =>
    format(addYears(addDays(new Date(), 1), 2), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 3 Jahre und 1 Tag}': (() =>
    format(addYears(addDays(new Date(), 1), 3), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 3 Jahre und 14 Tage}': (() =>
    format(addYears(addDays(new Date(), 14), 3), 'dd.MM.yyyy'))(),
  '{Tagesdatum}': (() => format(new Date(), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 1 Tag}': (() =>
    format(addDays(new Date(), 1), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 14 Tage}': (() =>
    format(addDays(new Date(), 14), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 55 Tage}': (() =>
    format(addDays(new Date(), 55), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 10 Tage - 17 Jahre}': (() =>
    format(subYears(addDays(new Date(), 10), 17), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 10 Tage - 27 Jahre}': (() =>
    format(subYears(addDays(new Date(), 10), 27), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 1 Monat}': (() =>
    format(addMonths(new Date(), 1), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 6 Monate}': (() =>
    format(addMonths(new Date(), 6), 'dd.MM.yyyy'))(),
  '{Tagesdatum + 18 Monate und 2 Tage}': (() =>
    format(addMonths(addDays(new Date(), 2), 18), 'dd.MM.yyyy'))(),
  '{Tagesdatum - 1 Tag}': (() =>
    format(subDays(new Date(), 1), 'dd.MM.yyyy'))(),
  '{Aktuelles Jahr}': (() => format(new Date(), 'yyyy'))(),
  '{Aktuelles Jahr + 1 Jahr}': (() =>
    format(addYears(new Date(), 1), 'yyyy'))(),
  '{Aktuelles Jahr + 2 Jahre}': (() =>
    format(addYears(new Date(), 2), 'yyyy'))(),
  '{Tagesdatum - 18 Jahre}': (() =>
    format(subYears(new Date(), 18), 'dd.MM.yyyy'))(),
  '{Tagesdatum - 18 Jahre + 1 Tag}': (() =>
    format(subYears(addDays(new Date(), 1), 18), 'dd.MM.yyyy'))(),
  '{Tagesdatum - 18 Jahre + 3 Monate + 1 Tag}': (() =>
    format(subYears(addMonths(subDays(new Date(), 1), 3), 18), 'dd.MM.yyyy'))(),
  '{Tagesdatum - 18 Jahre + beliebige Monate}': (() =>
    format(subYears(addMonths(subDays(new Date(), 1), getRandomInt(1, 18)), 18), 'dd.MM.yyyy'))(),
  '{Hauptfaelligkeit (Tagesdatum + 3 Tage)}': (() =>
    format(addDays(new Date(), 3), 'dd.MM'))(),
  '{Hauptfaelligkeit (Tagesdatum + 14 Tage)}': (() =>
    format(addDays(new Date(), 14), 'dd.MM'))(),
  '{Hauptfaelligkeit (Tagesdatum + 1 Tag)}': (() =>
    format(addDays(new Date(), 1), 'dd.MM.'))(),
  '{Hauptfaelligkeit (Tagesdatum - 1 Tag)}': (() =>
    format(subDays(new Date(), 1), 'dd.MM.'))(),
  '{Ablaufdatum mit Hauptfaelligkeit}': (() =>
    format(addYears(addDays(new Date(), 3), 2), 'dd.MM.yyyy'))(),
  '{Ablaufdatum mit Hauptfaelligkeit 1 Jahr}': (() =>
    format(addYears(addDays(new Date(), 3), 1), 'dd.MM.yyyy'))(),
  '{Ablaufdatum mit Hauptfaelligkeit 3 Jahre minus 1 Tag}': (() =>
    format(addYears(subDays(new Date(), 1), 3), 'dd.MM.yyyy'))(),
  '{Ablaufdatum mit Hauptfaelligkeit 2 Jahre minus 1 Tag}': (() =>
    format(addYears(subDays(new Date(), 1), 2), 'dd.MM.yyyy'))(),
};

const defaultToggles = {
  NEUE_ANWENDERINFO: false,
};

const defaultConsumer = {
  toggles: defaultToggles,
};

export const virtualConsumerIdToFeatureToggle = {
  'PS20-AZAM-MOCK': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles,
      AZAM_MOCK: true,
    },
  },
  'PS20-CURRENT-PROD': {
    toggles: {
      ...defaultToggles,
      CAN_DEACTIVATE_NGSPERRE: true,
    },
  },
  'PS20-DEFAULT': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles
    }
  },
  'PS20-ERSATZGESCHAEFT': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles,
    },
  },
  'PS20-ERSATZGESCHAEFT-PROGRAMMTEILNAHME': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles,
    },
  },
  'PS20_KARTENFENSTER_CYPRESS_TEST': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles,
      PS20_KARTENFENSTER_CYPRESS_TEST: true,
    },
  },
  'PS20_NEUE_ANWENDERINFO': {
    ...defaultConsumer,
    toggles: {
      ...defaultToggles,
      NEUE_ANWENDERINFO: true,
    },
  },
};

When(/^I activate the Feature-Toggle Mock "([^"]*)"$/,
  consumer => {
    setFeatureToggles(virtualConsumerIdToFeatureToggle[consumer]);
  }
);

When(/^I open the Antragsstrecke(?: as "(Makler|Maklerbetreuer|UWPSHRK|Nebenberufsvertreter|OLB|GENO|Agenturangestellter|Leitender_Kundenbetreuer|VTTEL|VTKUS)" User)?$/,
  role => {
  cy.viewport(1400, 1600).then(() => {
    if (!role) {
      startApp();
    } else {
      startApp(null, null, null, null, role.toLowerCase());
    }
  });
});

When(/^I open the Antragsstrecke with aid "([^"]*)" and pid "([^"]*)"$/,
  (aid, pid) => {
    cy.viewport(1400, 1600).then(() => {
      startApp(aid, pid);
    });
  }
);

When(/^I open the Antragsstrecke with cryptId "([^"]*)"$/, cryptId => {
  cy.viewport(1400, 1600).then(() => {
    startApp(null, null, cryptId);
  });
});

When(/^I open the Antragsstrecke with cryptId "([^"]*)" for AZAM$/, cryptId => {
  cy.viewport(1400, 1600).then(() => {
    startApp(null, null, cryptId, null, 'UWPSHRK');
  });
});

When(/^I open the Antragsstrecke with stored crypdId$/, () => {
  cy.viewport(1200, 1600).then(() =>
    startApp(null, null, storedCryptId)
  );
});

When(/^I open the Antragsstrecke as juristische Person$/, () => {
  startAppAsJuristischePerson();
});

When(/^I store crypdId$/, () => {
  cy.intercept('/privatschutz/api/save', (req) => {
    req.on('response', (res) => {
      storedCryptId = res.body.CryptId;
    })
  });
});

When(/^I wait for "([^"]*)" ms$/, (value) => {
  cy.wait(Number(value));
});

When(/^I scroll to the top of the page$/, () => {
  cy.scrollTo(0, 0);
});

When(/^I simulate loaded MapView$/, () => {
  clickElement('Kartenfenster Dialog Spinner');
});
When(/^I clear local storage$/, () => {
  cy.clearLocalStorage();
});
