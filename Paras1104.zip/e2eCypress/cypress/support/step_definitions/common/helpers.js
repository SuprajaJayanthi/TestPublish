import { addDays, addYears, format } from 'date-fns';
import dayjs from 'dayjs';
import { selectorMapping as basicSelectorMapping } from '../selectors/basic';
import { selectorMapping as toolbarSelectorMapping } from '../selectors/toolbar';
import { selectorMapping as vwgEingabeSelectorMapping } from '../selectors/vwg/eingabe';
import { selectorMapping as vwgAngebotSelectorMapping } from '../selectors/vwg/angebot';
import { selectorMapping as dashboardSelectorMapping } from '../selectors/dashboard';
import { selectorMapping as checkoutSelectorMapping } from '../selectors/checkout';
import { selectorMapping as vhvEingabeSelectorMapping } from '../selectors/vhv/eingabe';
import { selectorMapping as vhvAngebotSelectorMapping } from '../selectors/vhv/angebot';
import { selectorMapping as gegeEingabeSelectorMapping } from '../selectors/gege/eingabe';
import { selectorMapping as gegeAngebotSelectorMapping } from '../selectors/gege/angebot';
import { selectorMapping as jhpEingabeSelectorMapping } from '../selectors/jhp/eingabe';
import { selectorMapping as jhpAngebotSelectorMapping } from '../selectors/jhp/angebot';
import { selectorMapping as unfallEingabeSelectorMapping } from '../selectors/unf/eingabe';
import { selectorMapping as unfallAngebitSelectorMapping } from '../selectors/unf/angebot';
import { selectorMapping as phEingabeSelectorMapping } from '../selectors/ph/eingabe';
import { selectorMapping as phAngebotSelectorMapping } from '../selectors/ph/angebot';
import { selectorMapping as rsEingabeSelectorMapping } from '../selectors/rs/eingabe';
import { selectorMapping as rsAngebotSelectorMapping } from '../selectors/rs/angebot';
import { selectorMapping as rsVermietungEingabeSelectorMapping } from '../selectors/rs-vermietung/eingabe';
import { selectorMapping as rsVermietungAngebotSelectorMapping } from '../selectors/rs-vermietung/angebot';
import { selectorMapping as thhHundEingabeSelectorMapping } from '../selectors/thh-hund/eingabe';
import { selectorMapping as thhHundAngebotSelectorMapping } from '../selectors/thh-hund/angebot';
import { selectorMapping as thhPferdEingabeSelectorMapping } from '../selectors/thh-pferd/eingabe';
import { selectorMapping as thhPferdAngebotSelectorMapping } from '../selectors/thh-pferd/angebot';
import { selectorMapping as tkvEingabeSelectorMapping } from '../selectors/tkv/eingabe';
import { selectorMapping as tkvAngebotSelectorMapping } from '../selectors/tkv/angebot';
import { textCommandMapping as commonTextCommandMapping } from './common';

const selectorMapping = {
  ...basicSelectorMapping,
  ...toolbarSelectorMapping,
  ...vwgEingabeSelectorMapping,
  ...vwgAngebotSelectorMapping,
  ...dashboardSelectorMapping,
  ...checkoutSelectorMapping,
  ...vhvEingabeSelectorMapping,
  ...vhvAngebotSelectorMapping,
  ...gegeEingabeSelectorMapping,
  ...gegeAngebotSelectorMapping,
  ...jhpEingabeSelectorMapping,
  ...jhpAngebotSelectorMapping,
  ...unfallEingabeSelectorMapping,
  ...unfallAngebitSelectorMapping,
  ...phEingabeSelectorMapping,
  ...phAngebotSelectorMapping,
  ...rsEingabeSelectorMapping,
  ...rsAngebotSelectorMapping,
  ...rsVermietungEingabeSelectorMapping,
  ...rsVermietungAngebotSelectorMapping,
  ...thhHundEingabeSelectorMapping,
  ...thhHundAngebotSelectorMapping,
  ...thhPferdEingabeSelectorMapping,
  ...thhPferdAngebotSelectorMapping,
  ...tkvEingabeSelectorMapping,
  ...tkvAngebotSelectorMapping,
};

const textCommandMapping = {
  ...commonTextCommandMapping,
};

export const inputAttributes = [
  'checked',
  'unchecked',
  'selected',
  'deselected',
  'unselectable',
  'selectable',
  'disabled',
  'enabled',
];

export function getSelector(string) {
  const selector = selectorMapping[string];
  if (!selector) {
    throw new Error(`No selector found for ${string}`);
  }
  return selectorMapping[string];
}

export function replaceCustomTextCommands(string) {
  if (!string.includes('{')) {
    return string;
  }

  let processed_string = string;
  const customCommands = string.match(/({.*?})/gm);

  for (const command of customCommands) {
    if ({}.hasOwnProperty.call(textCommandMapping, command)) {
      processed_string = processed_string.replace(
        command,
        textCommandMapping[command]
      );
    }
  }
  return processed_string;
}

export function clickMultiple(type) {
  return type === 'elements' || type === 'texts';
}

export function attributeToCypressShould(type) {
  if (type === 'enabled ' || type === 'selectable ') {
    return 'be.enabled';
  } else if (type === 'disabled ' || type === 'unselectable ') {
    return 'be.disabled';
  } else if (type === 'checked ') {
    return 'be.checked';
  } else if (type === 'unchecked ') {
    return 'not.be.checked';
  } else if (type === 'selected ') {
    return 'be.selected';
  } else if (type === 'deselected ') {
    return 'not.be.selected';
  } else {
    return 'exist';
  }
}

export function getInputIfCheckboxOrSelect(attribute, element) {
  if (attribute && inputAttributes.includes(attribute.trim())) {
    return element.find('input');
  }

  return element;
}

export function isRegex(text) {
  return text.startsWith('/') && text.endsWith('/');
}

export function isDataCySelector(text) {
  return text.startsWith('[data-cy="') && text.endsWith('"]');
}

export function getTextOrRegex(text) {
  let textOrRegex = text;

  if (isRegex(text)) {
    textOrRegex = new RegExp(text.slice(1, -1));
  }

  return textOrRegex;
}

export function getRandomInt(min, max) {
  const minC = Math.ceil(min);
  return Math.floor(Math.random() * (Math.floor(max) - minC + 1)) + minC;
}

export function getDate(date, additionalDays, additionalYears) {
  const dateObj = new Date();
  if (date === 'Nächster 1. April') {
    date = dayjs();
    let yearOffset = date.month() < 3 || (date.month() === 3 && date.date() === 1) ? 0 : 1;
    if (additionalYears) {
      yearOffset += parseInt(additionalYears, 10);
    }
    return dayjs().date(1).month(3).year(date.year()).add(yearOffset, 'year').format('DD.MM.YYYY');
  } else if (date !== 'Tagesdatum' && date !== 'Aktuelles Jahr') {
    const dateArray = date.split('.');
    dateObj.setDate(dateArray[0]);
    dateObj.setMonth(dateArray[1] - 1);
    if (dateArray[3]) {
      dateObj.setFullYear(dateArray[1]);
    }
  }
  const additionalDaysInt = additionalDays ? parseInt(additionalDays, 10) : 0;
  const additionalYearsInt = additionalYears
    ? parseInt(additionalYears, 10)
    : 0;
  return format(
    addYears(addDays(dateObj, additionalDaysInt), additionalYearsInt),
    'dd.MM.yyyy'
  );
}
