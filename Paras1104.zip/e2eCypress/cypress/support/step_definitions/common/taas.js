import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getLatestBffVersionForHeader } from '../../commands';

const activateTaasServiceErrorModal = (returnCodeTaas) => (app, maxNumberOfResponses = '1') => {
  let numberOfResponses = 0;
  maxNumberOfResponses = parseInt(maxNumberOfResponses, 10);
  return cy.intercept('POST', `/privatschutz/api/taas/${app.toLowerCase()}`,
    request => {
      numberOfResponses += 1;
      if (numberOfResponses <= maxNumberOfResponses + 1) {
        const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
        const body = {
          taasStatus: {
            returnCodeTaas,
            fehlerCode: '123456',
            fehlermeldung: `Mocked Taas Error Description for ${app}`,
          }
        };
        request.reply(500, body, headers);
      } else {
        request.continue();
      }
    }
  );
};

When(/^I activate "([^"]*)" TaasServiceErrorModal with Retry$/,
  activateTaasServiceErrorModal('FEHLER_MIT_RETRY_MIT_VERFUEGBAR')
);

When(/^I activate "([^"]*)" TaasServiceErrorModal without Retry$/,
  activateTaasServiceErrorModal('FEHLER_OHNE_RETRY_NICHT_VERFUEGBAR')
);

When(/^I activate "([^"]*)" TaasServiceErrorModal with Retry for "([^"]*)" Responses$/,
  activateTaasServiceErrorModal('FEHLER_MIT_RETRY_MIT_VERFUEGBAR')
);

When(/^I activate "([^"]*)" TaasServiceErrorModal without Retry for "([^"]*)" Responses$/,
  activateTaasServiceErrorModal('FEHLER_OHNE_RETRY_NICHT_VERFUEGBAR')
);
