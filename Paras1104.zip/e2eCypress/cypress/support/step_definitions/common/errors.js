import { When } from '@badeball/cypress-cucumber-preprocessor';
import { getLatestBffVersionForHeader } from '../../commands';
import { method, pollingId } from "./mocks";

When(/^I activate Einstiegservice Mock with Error$/, () => {
  cy.intercept('/privatschutz/api/einstieg', {
    method: 'POST',
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 400,
    body: {
      detail: 'EINSTIEG_INVALID_VN_DATA_FEHLER',
      additionalInformation: ['Zeile 1', 'Zeile 2'],
    },
  });
});

When(/^I force an Error for Vertragsdaten Service with HTTP Status "([^"]*)"$/,
  (value) => {
    cy.intercept('privatschutz/api/vertragsdaten', {
      method: 'POST',
      delay: 3000,
      headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
      status: value,
      body: {
        timestamp: '2019-12-10T14:03:23.883+0000',
        path: '/privatschutz/api/adressverzeichnis',
        status: value,
        error: 'Internal Server Error',
        trace: null,
      },
    });
  }
);

When(/^I deactivate Adressverzeichnis-Service Mock$/, () => {
  const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
  const body = {
    plz: '88888',
    ortschaft: null,
    strasse: null,
    hausnummer: null,
    timestamp: '2019-12-10T14:03:23.883+0000',
    path: '/privatschutz/api/adressverzeichnis',
    statusCode: 500,
    error: 'Internal Server Error',
    trace: null,
  };
  cy.intercept('/privatschutz/api/adressverzeichnis', { method, headers, statusCode: 500, body });
});

When(/^I deactivate AmisCrmSucheImmobilien-Service$/, () => {
  cy.intercept('/privatschutz/api/amiscrmsucheImmobilien', {
    method: 'POST',
    delay: 3000,
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 500,
    body: {
      plz: '88888', ortschaft: null, strasse: null,
      timestamp: '2019-12-10T14:03:23.883+0000',
      path: '/privatschutz/api/amiscrmsucheImmobilien',
      statusCode: 500,
      error: 'Internal Server Error',
      trace: null,
    },
  });
});

When(/^I activate Tarifierung Service Mock with Error 99500 for "(VHV|VWG)"$/,
  strecke => {
    strecke = strecke.toLowerCase();
    cy.fixture('sonstiges/kartenfenster/taas-error-995000')
      .then(body => {
        const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
        cy.intercept(`/privatschutz/api/taas/${strecke}`, { method, headers, statusCode: 500, body });
      }).as(`${strecke}TaasCallWithError`);
  }
);

When(/^I activate Kontaflex Service Mock (with|without|with Callback) Error$/,
  error => {
    const headers = { 'x-ps20-bff-version': getLatestBffVersionForHeader() };
    let body;
    const statusCode = error === 'with Callback' ? 500 : 200;
    if (error === 'without') {
      body = { status: 'OK', serviceError: '' };
    } else if (error === 'with') {
      body = { status: 'NOK', serviceError: 'TREUEBONUS_DECKUNG_ERROR' };
    } else {
      body = {};
    }
    cy.intercept('/privatschutz/api/kontaflex', { method, headers, statusCode, body });
  }
);

When(/^I activate the eSign Error Mock$/, () => {
  cy.intercept(`/privatschutz/api/esign/upload/async`, {
    method: 'POST',
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 500,
    body: {},
  });
});

When(/^I activate the eSign Polling Error Mock$/, () => {
  cy.intercept(`/privatschutz/api/esign/upload/async`, {
    method: 'POST',
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 200,
    body: { id: pollingId },
  });

  cy.intercept(`/privatschutz/api/esign/upload/poll?pollingId=${pollingId}`, {
    method: 'GET',
    headers: { 'x-ps20-bff-version': getLatestBffVersionForHeader() },
    statusCode: 500,
    body: 'AV_TECHNISCHER_FEHLER'
  });
});