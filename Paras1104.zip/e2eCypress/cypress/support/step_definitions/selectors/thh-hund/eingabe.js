const navigationMapping = {
  'THH-Hund Eingabe Progressbar Item': `[data-cy="progressbar_item_0"]`,
  'THH-Hund Eingabe Zurück zum Shop': `[data-cy="thh-hund-navigateToDashboard-link"]`,
  'THH-Hund Eingabe Page': `thh-hund-angebot-eingabe`,
  'THH-Hund Tarif Berechnen Button': `[data-cy="thh-hund-tarif-berechnen-button"]`,
  'THH-Hund Angebot Page': `thh-hund-angebot-angebot`,
};

const eingabeBasisangaben = {
  'THH-Hund Eingabe PLZ Input': `[data-cy="thh-hund-basisangaben-plz-input"]`,
  'THH-Hund Eingabe PLZ Vorbelegt': `[data-cy="thh-hund-basisangaben-plz-vorbelegt"]`,

  'THH-Hund Eingabe Ort Input': `[data-cy="thh-hund-basisangaben-ort-input"]`,
  'THH-Hund Eingabe Ort Vorbelegt': `[data-cy="thh-hund-basisangaben-ort-vorbelegt"]`,
  'THH-Hund Eingabe Ort Dropdown': `[data-cy="thh-hund-basisangaben-ort-dropdown"]`,

  'THH-Hund Eingabe Strasse Input': `[data-cy="thh-hund-basisangaben-strasse"]`,
  'THH-Hund Eingabe Strasse Vorbelegt': `[data-cy="thh-hund-basisangaben-strasse-vorbelegt"]`,
  'THH-Hund Eingabe Strasse Dropdown': `[data-cy="thh-hund-basisangaben-strasse-dropdown"]`,

  'THH-Hund Eingabe Hausnr Input': `[data-cy="thh-hund-basisangaben-hausnummer-input"]`,
  'THH-Hund Eingabe Hausnr Vorbelegt': `[data-cy="thh-hund-basisangaben-hausmnummer-vorbelegt"]`,

  'THH-Hund Eingabe Geburtsdatum Input': `[data-cy="thh-hund-basisangaben-geburtsdatum-input"]`,
  'THH-Hund Eingabe Geburtsdatum Vorbelegt': `[data-cy="thh-hund-basisangaben-geburtsdatum-vorbelegt"]`,

  'THH-Hund Eingabe NLF Error': `[data-cy="thh-hund-basisangaben-nlf-error"]`,

  'THH-Hund Eingabe AnzahlTiere Dropdown': `[data-cy="thh-hund-basisangaben-anzahlTiere-dropdown"]`,
  'THH-Hund Eingabe AnzahlTiere Dropdown Item - ein Hund': `[data-cy="thh-hund-basisangaben-anzahlTiere-dropdown-item-EIN_TIER"]`,
  'THH-Hund Eingabe AnzahlTiere Dropdown Item - mehrere Hunde': `[data-cy="thh-hund-basisangaben-anzahlTiere-dropdown-item-MEHRERE_TIERE"]`,
};

const eingabeHunderasseEinHund = {
  'THH-Hund Eingabe EinHundRasse Dropdown': `[data-cy="thh-hund-hunderasse-dropdown-ein-hund"]`,
  'THH-Hund Eingabe EinHundRasse Dropdown - First Item': `[data-cy="thh-hund-hunderasse-dropdown-ein-hund-item-0"]`,
  'THH-Hund Eingabe EinHundRasse Required Error': `[data-cy="thh-hund-hunderasse-required-error"]`,
};

const eingabeHunderasseMehrereHunde = {
  'THH Hund Eingabe MehrereHundeRassen Stepper':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-stepper"]',
  'THH Hund Eingabe MehrereHundeRassen Stepper - Input':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-stepper"] input',
  'THH Hund Eingabe MehrereHundeRassen Underwriter Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-underwriter-error"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown with Index': (index) =>
    `[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-${index}"]`,
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 0':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-0"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 1':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-1"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 2':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-2"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 3':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-3"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 4':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-4"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 5':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-5"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 6':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-6"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 7':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-7"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 8':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-8"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 9':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-9"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 10':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-10"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 0 - First Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-0-0"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 1 - First Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-1-0"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 2 - First Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-2-0"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 0 - Second Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-0-1"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 1 - Second Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-1-1"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 2 - Second Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-2-1"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 0 - Third Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-0-2"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 1 - Third Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-1-2"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 2 - Third Item':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-dropdown-item-2-2"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 0 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-0"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 1 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-1"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 2 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-2"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 3 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-3"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 4 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-4"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 5 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-5"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 6 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-6"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 7 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-7"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 8 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-8"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 9 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-9"]',
  'THH-Hund Eingabe MehrereHundeRassen Dropdown - 10 - Required Error':
    '[data-cy="thh-hund-hunderasse-mehrere-hunde-required-error-10"]',
};

const eingabeVorschaeden = {
  'THH-Hund Eingabe Vorschäden Radio': `[data-cy="thh-hund-basisangaben-vorschaeden-radio"]`,
  'THH-Hund Eingabe Vorschaeden Radio Ja': `[data-cy="thh-hund-basisangaben-vorschaeden-radio-ja"]`,
  'THH-Hund Eingabe Vorschaeden Radio Nein': `[data-cy="thh-hund-basisangaben-vorschaeden-radio-nein"]`,
  'THH-Hund Eingabe Vorschäden Required Message':
    '[data-cy=thh-hund-basisangaben-vorschaeden-required-error-msg]',
  'THH-Hund Eingabe Vorschaeden Stepper':
    '[data-cy="thh-hund-basisangaben-vorschaeden-thhHundVorschaeden-stepper"]',
  'THH-Hund Eingabe Vorschäden Anzahl Required Message':
    '[data-cy=thh-hund-basisangaben-vorschaeden-number-required-error-msg]',
  'THH-Hund Eingabe Vorschäden Anzahl Überschritten Message':
    '[data-cy="thh-hund-basisangaben-vorschaeden-uberschritten-error-msg"]',
};

const eingabeMapping = {
  ...eingabeBasisangaben,
  ...eingabeHunderasseEinHund,
  ...eingabeHunderasseMehrereHunde,
  ...eingabeVorschaeden,
};

export const selectorMapping = {
  ...navigationMapping,
  ...eingabeMapping,
};
