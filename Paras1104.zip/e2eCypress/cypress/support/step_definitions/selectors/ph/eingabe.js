export const selectorMapping = {
  'PH Eingabe Page': `ph-angebot-eingabe`,

  'PH Eingabe PLZ Input': `[data-cy="ph-basisangaben-plz-input"]`,
  'PH Eingabe PLZ Vorbelegt': `[data-cy="ph-basisangaben-plz-vorbelegt"]`,

  'PH Eingabe Ort Input': `[data-cy="ph-basisangaben-ort-input"]`,
  'PH Eingabe Ort Vorbelegt': `[data-cy="ph-basisangaben-ort-vorbelegt"]`,
  'PH Eingabe Ort Dropdown': `[data-cy="ph-basisangaben-ort-dropdown"]`,

  'PH Eingabe Strasse Input': `[data-cy="ph-basisangaben-strasse"]`,
  'PH Eingabe Strasse Vorbelegt': `[data-cy="ph-basisangaben-strasse-vorbelegt"]`,
  'PH Eingabe Strasse Dropdown': `[data-cy="ph-basisangaben-strasse-dropdown"]`,

  'PH Eingabe Hausnr Input': `[data-cy="ph-basisangaben-hausnummer-input"]`,
  'PH Eingabe Hausnr Vorbelegt': `[data-cy="ph-basisangaben-hausnummer-vorbelegt"]`,

  'PH Eingabe Geburtsdatum Input': `[data-cy="ph-basisangaben-geburtsdatum-input"]`,
  'PH Eingabe Geburtsdatum Vorbelegt': `[data-cy="ph-basisangaben-geburtsdatum-vorbelegt"]`,

  'PH Eingabe Familienstand Dropdown': `[data-cy="ph-basisangaben-familienstand-dropdown"]`,

  'PH Eingabe NLF Error': `[data-cy="ph-basisanageben-nlf-error"]`,

  'PH Eingabe Vorschaeden Radio': `[data-cy="ph-basisangaben-vorschaeden-radio"]`,
  'PH Eingabe Vorschaeden Radio Ja':
    '[data-cy="ph-basisangaben-vorschaeden-radio-ja"]',
  'PH Eingabe Vorschaeden Radio Nein':
    '[data-cy="ph-basisangaben-vorschaeden-radio-nein"]',
  'PH Eingabe Vorschaeden PH Stepper':
    '[data-cy="ph-basisangaben-vorschaeden-phVorschaeden-stepper"]',
  'PH Eingabe Vorschaeden PH Stepper Input':
    '[data-cy="ph-basisangaben-vorschaeden-phVorschaeden-stepper"] input',
  'PH Eingabe Vorschaeden Required Meldung': `[data-cy="ph-basisangaben-vorschaeden-required-error-msg"]`,
  'PH Eingabe Vorschaeden Number Required Meldung': `[data-cy="ph-basisangaben-vorschaeden-number-required-error-msg"]`,
  'PH Eingabe Vorschaeden Number Ueberschritten Meldung': `[data-cy="ph-basisangaben-vorschaeden-uberschritten-error-msg"]`,

  'PH Eingabe Zurück zum Shop': `[data-cy="ph-navigateToDashboard-link"]`,
};
