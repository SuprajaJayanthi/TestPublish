export const selectorMapping = {
  'PH Angebot Page': `ph-angebot-angebot`,

  'PH Angebot Selbstbeteiligung Dropdown': `[data-cy="global-vertragsoption-selbstbeteiligung"]`,

  'PH Angebot Weitere Leistungen': `[data-cy="ph-angebot-weitere-leistungen"]`,
  'PH Angebot Weitere Leistungen Mallorca-Deckung': `[data-cy="ph-angebot-weitere-leistungen-content-5"]`,

  'PH Angebot Zusatzoptionen Öltank': `[data-cy="ph-angebot-zusatzoption-oeltankHaftpflichtschutz"]`,
  'PH Angebot Zusatzoptionen Dienst': `[data-cy="ph-angebot-zusatzoption-dienstHaftpflichtschutz"]`,
  'PH Angebot Zusatzoptionen Wohnung': `[data-cy="ph-angebot-zusatzoption-wohnungsHaftpflichtschutz"]`,
  'PH Angebot Zusatzoptionen Anzahl Wohnung Stepper': `[data-cy="ph-angebot-zusatzoption-wohnungsHaftpflichtschutz-anzahlWohnung-stepper"]`,
  'PH Angebot Zusatzoptionen Anzahl Wohnung Input': `[data-cy="ph-angebot-zusatzoption-wohnungsHaftpflichtschutz-anzahlWohnung-stepper"] input`,

  'PH Angebot übernehmen': `[id="weiter-zum-antrag-button"]`,
};
