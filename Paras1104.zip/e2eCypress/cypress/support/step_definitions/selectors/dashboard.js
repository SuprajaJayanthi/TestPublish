export const selectorMapping = {
  'Dashboard Page': `ps20-shop-dashboard-gui-uebersicht`,

  'Dashboard Produktkarte VWG':
    '[data-cy="dashboard-produkt-karte-vwg-angebot"]',
  'Dashboard Produktkarte VWG deaktiviert':
    '[data-cy="dashboard-produkt-karte-vwg-angebot"] .is-disabled',
  'Dashboard Angebotsuebersicht VWG':
    '[data-cy="dashboard-uebersicht-angebote-vwg-angebot"]',
  'Dashboard Angebotsuebersicht VWG with Index': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-vwg-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Dashboard Kombirabatt Cell with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht VWG with Index'](
      index
    )} [data-cy="kombirabatt-cell"]`,
  'Dashboard Optionbutton VWG Angebot':
    '[data-cy="dashboard-option-button-vwg-angebot"]',
  'Dashboard Optionbutton VWG Angebot with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht VWG with Index'](
      index
    )} [data-cy="dashboard-option-button-vwg-angebot"]`,
  'Dashboard delete VWG Angebot':
    `[data-cy="dashboard-delete-button-vwg-angebot"]`,
  'Dashboard edit VWG Angebot':
    `[id="bearbeiten-button-vwg-angebot"]`,
  'Dashboard edit VWG Angebot with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht VWG with Index'](
      index
    )} [id="bearbeiten-button-vwg-angebot"]`,

  'Dashboard Produktkarte VHV deaktiviert':
    '[data-cy="dashboard-produkt-karte-vhv-angebot"] .is-disabled',
  'Dashboard Produktkarte VHV':
    '[data-cy="dashboard-produkt-karte-vhv-angebot"]',
  'Dashboard Angebotsuebersicht VHV':
    '[data-cy="dashboard-uebersicht-angebote-vhv-angebot"]',
  'Dashboard Optionbutton VHV Angebot':
    '[data-cy="dashboard-option-button-vhv-angebot"]',
  'Dashboard Angebotsuebersicht VHV with Index': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-vhv-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Dashboard Optionbutton VHV Angebot with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht VHV with Index'](
      index
    )} [data-cy="dashboard-option-button-vhv-angebot"]`,
  'Dashboard delete VHV Angebot':
    `[data-cy="dashboard-delete-button-vhv-angebot"]`,
  'Dashboard edit VHV Angebot':
    `[id="bearbeiten-button-vhv-angebot"]`,

  'Dashboard Produktkarte PH deaktiviert':
    '[data-cy="dashboard-produkt-karte-ph-angebot"] .is-disabled',
  'Dashboard Produktkarte PH':
    '[data-cy="dashboard-produkt-karte-ph-angebot"]',
  'Dashboard Angebotsuebersicht PH':
    '[data-cy="dashboard-uebersicht-angebote-ph-angebot"]',
  'Dashboard Optionbutton PH Angebot':
    '[data-cy="dashboard-option-button-ph-angebot"]',
  'Dashboard delete PH Angebot':
    `[data-cy="dashboard-delete-button-ph-angebot"]`,
  'Dashboard edit PH Angebot':
    `[id="bearbeiten-button-ph-angebot"]`,

  'Dashboard Produktkarte RS':
    '[data-cy="dashboard-produkt-karte-rs-angebot"]',
  'Dashboard Produktkarte RS deaktiviert':
    '[data-cy="dashboard-produkt-karte-rs-angebot"] .is-disabled',
  'Dashboard Angebotsuebersicht RS':
    '[data-cy="dashboard-uebersicht-angebote-rs-angebot"]',
  'Dashboard edit RS Angebot':
    `[id="bearbeiten-button-rs-angebot"]`,

  'Dashboard Produktkarte RS Vermietung':
    '[data-cy="dashboard-produkt-karte-rs-vermietung-angebot"]',
  'Dashboard Produktkarte RS Vermietung deaktiviert':
    '[data-cy="dashboard-produkt-karte-rs-vermietung-angebot"] .is-disabled',
  'Dashboard Angebotsuebersicht RS Vermietung':
    '[data-cy="dashboard-uebersicht-angebote-rs-vermietung-angebot"]',
  'Dashboard edit RS Vermietung Angebot':
    `[id="bearbeiten-button-rs-angebot"]`,

  'Dashboard RS Zusammenfuehren Modal':
    '[data-cy="rs-zusammenfuehren-modal"]',
  'Dashboard RS Zusammenfuehren Modal Nein Radio':
    '[data-cy="rs-zusammenfuehren-modal-nein-radio"]',
  'Dashboard RS Zusammenfuehren Modal Ja Radio':
    '[data-cy="rs-zusammenfuehren-modal-ja-radio"]',
  'Dashboard RS Zusammenfuehren Modal Abbrechen Button':
    '[data-cy="rs-zusammenfuehren-modal-abbrechen-button"]',
  'Dashboard RS Zusammenfuehren Modal Bestaetigen Button':
    '[data-cy="rs-zusammenfuehren-modal-bestaetigen-button"]',

  'Dashboard Produktkarte THH-Hund':
    '[data-cy="dashboard-produkt-karte-thh-hund-angebot"]',
  'Dashboard Angebotsuebersicht THH-Hund':
    '[data-cy="dashboard-uebersicht-angebote-thh-hund-angebot"]',
  'Dashboard edit THH-Hund Angebot': `[id="bearbeiten-button-thh-hund-angebot"]`,
  'Dashboard Optionbutton THH-Hund Angebot':
    '[data-cy="dashboard-option-button-thh-hund-angebot"]',
  'Dashboard delete THH-Hund Angebot': `[data-cy="dashboard-delete-button-thh-hund-angebot"]`,

  'Dashboard Produktkarte THH-Pferd':
    '[data-cy="dashboard-produkt-karte-thh-pferd-angebot"]',
  'Dashboard Angebotsuebersicht THH-Pferd':
    '[data-cy="dashboard-uebersicht-angebote-thh-pferd-angebot"]',
  'Dashboard edit THH-Pferd Angebot': `[id="bearbeiten-button-thh-pferd-angebot"]`,
  'Dashboard Optionbutton THH-Pferd Angebot':
    '[data-cy="dashboard-option-button-thh-pferd-angebot"]',
  'Dashboard delete THH-Pferd Angebot': `[data-cy="dashboard-delete-button-thh-pferd-angebot"]`,

  'Dashboard Produktkarte TKV':
    '[data-cy="dashboard-produkt-karte-tkv-angebot"]',
  'Dashboard Angebotsuebersicht TKV':
    '[data-cy="dashboard-uebersicht-angebote-tkv-angebot"]',
  'Dashboard edit TKV Angebot': `[id="bearbeiten-button-tkv-angebot"]`,
  'Dashboard Optionbutton TKV Angebot':
    '[data-cy="dashboard-option-button-tkv-angebot"]',
  'Dashboard delete TKV Angebot': `[data-cy="dashboard-delete-button-tkv-angebot"]`,
  'Dashboard Optionbutton TKV Angebot with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht TKV with Index'](
      index
    )} [data-cy="dashboard-option-button-tkv-angebot"]`,
  'Dashboard Angebotsuebersicht TKV with Index': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-tkv-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Dashboard TKV Kombirabatt Cell with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht TKV with Index'](
      index
    )} [data-cy="kombirabatt-cell"]`,

  'Dashboard Produktkarte TKV deaktiviert':
    '[data-cy="dashboard-produkt-karte-tkv-angebot"] .is-disabled',
  'Dashboard edit TKV Angebot with Index': (index) =>
    `${selectorMapping['Dashboard Angebotsuebersicht TKV with Index'](
      index
    )} [id="bearbeiten-button-tkv-angebot"]`,

  'Dashboard Produktkarte Unfall':
    '[data-cy="dashboard-produkt-karte-unf-angebot"] button',
  'Dashboard Angebotsuebersicht Unfall':
    '[data-cy="dashboard-uebersicht-angebote-unf-angebot"]',
  'Dashboard Angebotsuebersicht Unfall Zaehlstuecke':
    '[data-cy="unfall-zaehlstuecke-badge"]',
  'Dashboard Angebotsuebersicht Unfall 0 oeffnen':
    '[data-cy="dashboard-uebersicht-angebote-link-unf-angebot-0"]',
  'Dashboard Angebotsuebersicht Unfall Zaehlstuecke Button':
    '[data-cy="dashboard-produkt-karte-unf-angebot-zaehlstueck"]',
  'Dashboard Produktkarte Unfall Edit':
    '[data-cy="dashboard-unfall-karte-edit"]',
  'Dashboard Unfall Modal':
    '[data-cy="dashboard-unfall-modal"]',
  'Dashboard Unfall Modal Numberstepper':
    '[data-cy="dashboard-unfall-modal-numberstepper"]',
  'Dashboard Unfall Modal Numberstepper Input':
    '#nx-number-stepper-0',
  'Dashboard Unfall Modal Uebernehmen':
    '[data-cy="dashboard-unfall-modal-uebernehmen"]',
  'Dashboard Optionbutton Unfall':
    '[data-cy="dashboard-option-button-unf-angebot"]',
  'Dashboard delete Unfall':
    '[data-cy="dashboard-delete-button-unf-angebot"]',
  'Dashboard Keine Angebote':
    '[data-cy="no-angebot-content"]',

  'Dashboard Produktkarte Jagdhaft':
    '[data-cy="dashboard-weiter-produkt-karte-jhp-angebot"] button',
  'Dashboard Angebotsuebersicht Jagdhaft':
    '[data-cy="dashboard-uebersicht-angebote-jhp-angebot"]',
  'Dashboard Angebotsuebersicht Weiter zum Antrag':
    'button[id="weiterZumAntragButton"]',

  'Dashboard Produktkarte Gegenstandsschutz':
    '[data-cy="dashboard-weiter-produkt-karte-gege-angebot"] button',
  'Dashboard Angebotsuebersicht Gegenstandsschutz':
    '[data-cy="dashboard-uebersicht-angebote-gege-angebot"]',
  'Dashboard Optionbutton Gegenstandsschutz':
    '[data-cy="dashboard-option-button-gege-angebot"]',
  'Dashboard delete Gegenstandsschutz':
    '[data-cy="dashboard-delete-button-gege-angebot"]',
  'Dashboard Angebotsuebersicht Gegenstandsschutz Aendern':
    '[data-cy="dashboard-uebersicht-angebote-link-gege-angebot-0"]',
  'Dashboard Angebotsuebersicht Gegenstandsschutz Pen':
    '[id="bearbeiten-button-gege-angebot"]',

  'Dashboard Immobilienauswahl Dialog':
    '[data-cy="immobilien-auswahl-dialog"]',
  'Dashboard Immobilienauswahl Neue Adresse Radio':
    '[data-cy="immobilienauswahl-neue-adresse-radio"]',
  'Dashboard Immobilienauswahl Error':
    '[data-cy="immobilienauswahl-error-message"]',
  'Dashboard Notification':
    '[data-cy*="dashboard-notification-"]',
  'Dashboard Eingabe Geburtsdatum Input':
    `[data-cy="vwg-basisangaben-geburtsdatum-input"]`,

  'Dashboard Laufzeit 1 Jahr Button':
    `#laufzeitAuf1JahrButton`,
  'Dashboard Laufzeit 3 Jahre Button':
    `#laufzeitAuf3JahreButton`,

  'Dashbaord Rabatt Hinweis Meldung':
    '[data-cy="rabatt-hinweis-meldung"]',
  'Dashboard Sofortschutz Hinweistext':
    `[data-cy="dashboard-sofortschutz-hinweistext"]`,

  'Dashboard Tabelle Vorvertraege':
    `[data-cy="vorvertraege-table"]`,
  'Dashboard Vorvertrag': (index) =>
    `[data-cy="vorvertraege-${index}"]`,
  'Dashboard Vorvertrag Status': (index) =>
    `[data-cy="vorvertraege-status-${index}"]`,
  'Dashboard Vorvertrag Beitrag': (index) =>
    `[data-cy="vorvertraege-beitrag-${index}"]`,
  'Dashboard Vorvertrag Zum Angebot Link': (index) =>
    `[data-cy="vorvertraege-zumAngebotLink-${index}"]`,
  'Dashboard Vorvertrag Vertrag Button': (index) =>
    `[data-cy="vorvertraege-vertragButton-${index}"]`,
  'Dashboard Vorvertrag Beibehalten Button': (index) =>
    `[data-cy="vorvertraege-beibehalten-${index}"]`,
  'Dashboard Info Modal Button': (index) =>
    `[data-cy="vorvertraege-infoModalButton-${index}"]`,
  'Dashboard Zusatz-Info': (index) =>
    `[data-cy="vorvertraege-zusatzinformation-${index}"]`,
  'Dashboard Standalone-Produkt Einschliessen Dialog':
    '[data-cy="standalone-produkt-einschliessen-dialog"]',
  'Dashboard Standalone-Produkt Einschliessen Dialog Hinweis Message':
    '[data-cy="standalone-modal-hinweis-message"]',
  'Dashboard Standaloneproduktauswahl Dialog':
    '[data-cy="standalone-produkt-auswahl-dialog"]',

  'Dashboard EHV Dialog':
    '[data-cy="ehv-produkt-auswahl-dialog"]',

  'Dashboard Info Modal Badge':
    `[data-cy="vorvertrag-infoModalBadge"]`,
  'Dashboard Info Modal Anzeigename':
    `[data-cy="vorvertrag-infoModalAnzeigename"]`,
  'Dashboard Info Modal Vertragsnummer':
    `[data-cy="vorvertrag-infoModalVertragsnummer"]`,
  'Dashboard Info Modal Infotext':
    `[data-cy="vorvertrag-infoModalInfotext"]`,
  'Dashboard Info Modal Close Button':
    `[data-cy="vorvertrag-infoModalButton"]`,

  'Dashboard Tacho Zaehlstuecke':
    `[data-cy="tacho-zaehlstuecke"]`,
  'Dashboard Tacho Ersparnis':
    `[data-cy="tacho-ersparnis"]`,

  'Dashboard No Angebote Content':
    '.no-angebote-content',
  'Dashboard No Vertraege Content':
    '.no-vertraege-content',

  'Dashbaord Geladene Vorgaenge Hinweis':
    '[data-cy="dashboard-geladeneVorgaenge-hinweis"]',

  'Fremde Vertraege Button':
    '[data-cy="fremde-vertraege-button"]',
  'Fremde Vertraege Auswahl Modal':
    '[data-cy="fremd-vertraege-auswahl-modal"]',
  'Fremde Vertraege Toggle All Checkbox':
    '[data-cy="fremdVertragAuswahlModal-toggleAll"]',
  'Fremde Vertraege Auswahl Gewaehlter Kunde':
    '[data-cy="fremd-vertraege-selected-kunde"]',
  'Fremde Vertraege Person Anpassen Button':
    '[data-cy="fremd-vertraege-person-anpassen"]',
  'Fremde Vertraege Auswaehlbaerer Vorvertrag':
    '[data-cy*="selectable-fremdvertrag-"]',

  'Fremde Vertrag Auswahl Modal Button Abbrechen':
    '[data-cy=vertrag-auswahl-abbrechen-button]',
  'Fremde Vertrag Auswahl Modal Button Weiter':
    '[data-cy=vertrag-auswahl-weiter-button]',

  'Dashboard Fremdvertrag Options Button': (index) =>
    `[data-cy=fremdVertraege-options-button-${index}]`,
  'Dashboard Delete Fremdvertrag Button':
    '[data-cy=fremdVertraege-option-delete-button]',
  'Dashboard Fremdvertrag': (index) => `[data-cy="fremdVertraege-${index}"]`,
  'Dashboard Fremdvertrag Vertragsnummer': (index) =>
    `[data-cy="fremdVertraege-vertragsnummer-${index}"]`,
  'Dashboard Fremdvertrag Vertrag Umstellen': (index) =>
    `[data-cy="fremdVertraege-vertragButton-${index}"]`,
  'Dashboard Fremdvertrag Vertrag Status': (index) =>
    `[data-cy="fremdVertraege-status-${index}"]`,

  'Dashboard Standard Modal Checkbox': (index) =>
    `[data-cy="checkbox-standard-modal-${index}"]`,
  'Dashboard Standalone Modal Checkbox': (index) =>
    `[data-cy="checkbox-standalone-modal-${index}"]`,
  'Modal Vorvertraege Uebernehmen Button':
    `[data-cy="modal-vorvertraege-uebernehmen-button"]`,
  'Dashboard Hinweismeldung gleiche Adresse':
    `[data-cy="standalone-modal-hinweis-message"]`,
  'Einstieg Message Error':
    `[data-cy="einstieg-main-message"]`,
  'Einstieg Message Details':
    `[data-cy="einstieg-zusatz-message"]`,

  'Dashboard VHV Berechnen Link': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-link-vhv-angebot-${index}"]`,
  'Dashboard VWG Berechnen Link': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-link-vwg-angebot-${index}"]`,
  'Dashboard TKV Berechnen Link': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-link-tkv-angebot-${index}"]`,
  'Dashboard PH Berechnen Link': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-link-ph-angebot-${index}"]`,

  'Dashboard Unfall Berechnen Link': (index) =>
    `[data-cy="dashboard-uebersicht-angebote-link-unf-angebot-${index}"]`,

  'Dashboard Produktkarte JHP':
    '[data-cy="dashboard-weiter-produkt-karte-jhp-angebot"]',
  'Dashboard Optionbutton JHP Angebot':
    '[data-cy="dashboard-option-button-jhp-angebot"]',
  'News Modal': '[data-cy="news-modal"]',
  'Close News Button': '[data-cy="news-modal-close-button"]'
};
