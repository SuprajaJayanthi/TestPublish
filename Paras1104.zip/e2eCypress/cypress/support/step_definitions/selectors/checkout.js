export const selectorMapping = {
  'Checkout Page': `[data-cy="checkout-seite"]`,
  'Checkout Zurueck zum Shop': `[data-cy="checkout-navigateToDashboard-link"]`,
  'Checkout Zurueck Button': `[data-cy="checkout-zurueck-button"]`,
  'Checkout Dankeseite': `checkout-danke-seite`,

  'Checkout Antragsfragenblock': `[data-cy="checkout-antragsfragen-block"]`,

  'Checkout Versicherungsnehmer': `[data-cy="checkout-versicherungsnehmer"]`,
  'Checkout Versicherungsnehmer Email Input': `[data-cy="checkout-vn-email-input"]`,
  'Checkout Versicherungsnehmer Email Warning':
    '[data-cy="versicherungsnehmer-email-warning"]',
  'Checkout Versicherungsnehmer Email Error':
    '[data-cy="versicherungsnehmer-email-error"]',
  'Checkout Versicherungsnehmer Email Radio': `[data-cy="checkout-radios-email-angabe"]`,
  'Checkout Onboardingvideo Email Error Required': `[data-cy="checkout-onboardingvideo-email-error-required"]`,
  'Checkout Versicherungsnehmer Telefon Input': `[data-cy="checkout-vn-telefon-input"] input`,
  'Checkout Versicherungsnehmer Mobile Input': `[data-cy="checkout-vn-mobile-input"] input`,
  'Checkout Versicherungsnehmer Mobile Radio': `[data-cy="checkout-radios-mobil-angabe"]`,
  'Checkout Amtliches Kennzeichen Input': `[data-cy="checkout-amtlichesKennzeichen"]`,
  'Checkout Amtliches Kennzeichen Input Error Required': `[data-cy="checkout-amtlichesKennzeichen-error-required"]`,
  'Checkout Amtliches Kennzeichen Input Error Pattern': `[data-cy="checkout-amtlichesKennzeichen-error-pattern"]`,

  'Checkout Wartezeitverzicht': `[data-cy="checkout-wartezeitverzicht"]`,
  'Checkout Wartezeitverzicht Radio': `[data-cy="checkout-wartezeitverzicht-radio"]`,
  'Checkout Wartezeitverzicht Radio Ja': `[data-cy="checkout-wartezeitverzicht-radio-ja"]`,
  'Checkout Wartezeitverzicht Radio Nein': `[data-cy="checkout-wartezeitverzicht-radio-nein"]`,
  'Checkout Wartezeitverzicht Radio Error': `[data-cy="checkout-wartezeitverzicht-radio-error"]`,
  'Checkout Wartezeitverzicht Dropdown': `[data-cy="checkout-wartezeitverzicht-dropdown"]`,
  'Checkout Wartezeitverzicht Dropdown Fkombi': `[data-cy="checkout-wartezeitverzicht-dropdown-fkombi"]`,
  'Checkout Wartezeitverzicht Dropdown Ehepartner': `[data-cy="checkout-wartezeitverzicht-dropdown-ehepartner"]`,
  'Checkout Wartezeitverzicht Dropdown Eltern': `[data-cy="checkout-wartezeitverzicht-dropdown-eltern"]`,
  'Checkout Wartezeitverzicht Dropdown Error': `[data-cy="checkout-wartezeiterzicht-dropdown-error"]`,
  'Checkout Wartezeitverzicht Referenzvertrag': `[data-cy="checkout-wartezeitverzicht-referenzvertrag"]`,
  'Checkout Wartezeitverzicht Referenzvertrag Required': `[data-cy="checkout-wartezeiterzicht-referenzvertrag-required"]`,
  'Checkout Wartezeitverzicht Referenzvertrag Pattern': `[data-cy="checkout-wartezeiterzicht-referenzvertrag-pattern"]`,

  'Checkout Vermietete Wohnungen': `[data-cy="checkout-vermietete-wohnungen"]`,
  'Checkout Vermietete Wohnung Kachel': (index) =>
    `[data-cy*="checkout-vermietete-wohnung-card-${index}"]`,
  'Checkout Vermietete Wohnung Kacheln': `[data-cy*="checkout-vermietete-wohnung-card-"]`,
  'Checkout Vermietete Wohnung Kachel PLZ Input': (index) =>
    `[data-cy="checkout-vermietete-wohnung-plz-input-${index}"]`,
  'Checkout Vermietete Wohnung Kachel Ort Input': (index) =>
    `[data-cy="checkout-vermietete-wohnung-ort-input-${index}"]`,
  'Checkout Vermietete Wohnung Kachel Ort Dropdown': (index) =>
    `[data-cy="checkout-vermietete-wohnung-ort-dropdown${index}"]`,
  'Checkout Vermietete Wohnung Kachel Ort Vorschlag': (index) =>
    `[data-cy="checkout-vermietete-wohnung-ort-vorschlag${index}"]`,
  'Checkout Vermietete Wohnung Kachel Strasse Dropdown': (index) =>
    `[data-cy="checkout-vermietete-wohnung-strasse-dropdown${index}"]`,
  'Checkout Vermietete Wohnung Kachel Hausnummer Input': (index) =>
    `[data-cy="checkout-vermietete-wohnung-hausnummer-input-${index}"]`,
  'Checkout Vermietete Wohnung Kachel Wohnungsnummer Input': (index) =>
    `[data-cy="checkout-vermietete-wohnung-wohnungsnummer-input-${index}"]`,
  'Checkout Vermietete Wohnung 1. Kachel': `[data-cy="checkout-vermietete-wohnung-card-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel PLZ Input': `[data-cy="checkout-vermietete-wohnung-plz-input-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Ort Input': `[data-cy="checkout-vermietete-wohnung-ort-input-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Ort Dropdown': `[data-cy="checkout-vermietete-wohnung-ort-dropdown0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Strasse Input': `[data-cy="checkout-vermietete-wohnung-strasse-input-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Strasse Dropdown': `[data-cy="checkout-vermietete-wohnung-strasse-dropdown0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Hausnummer Input': `[data-cy="checkout-vermietete-wohnung-hausnummer-input-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Wohnungsnummer Input': `[data-cy="checkout-vermietete-wohnung-wohnungsnummer-input-0"]`,
  'Checkout Vermietete Wohnung 1. Kachel Open Immobilien Auswahl Link': `[data-cy="checkout-vermietete-wohnung-open-immobilien-auswahl-0-link"]`,
  'Checkout Vermietete Wohnung 1. Kachel Selected KDV Immobilie Adresse': `[data-cy="checkout-vermietete-wohnung-selected-kdv-immobilie-adresse-0"]`,

  'Checkout Vermietete Wohnung 2. Kachel Open Immobilien Auswahl Link': `[data-cy="checkout-vermietete-wohnung-open-immobilien-auswahl-1-link"]`,
  'Checkout Vermietete Wohnung 2. Kachel Selected KDV Immobilie Adresse': `[data-cy="checkout-vermietete-wohnung-selected-kdv-immobilie-adresse-1"]`,
  'Checkout Vermietete Wohnung 2. Kachel Wohnungsnummer Input': `[data-cy="checkout-vermietete-wohnung-wohnungsnummer-input-1"]`,

  'Checkout Vermietete Wohnung 3. Kachel PLZ Input': `[data-cy="checkout-vermietete-wohnung-plz-input-2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Ort Input': `[data-cy="checkout-vermietete-wohnung-ort-input-2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Ort Dropdown': `[data-cy="checkout-vermietete-wohnung-ort-dropdown2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Ort Vorschlag': `[data-cy="checkout-vermietete-wohnung-ort-vorschlag2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Strasse Input': `[data-cy="checkout-vermietete-wohnung-strasse-input-2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Strasse Dropdown': `[data-cy="checkout-vermietete-wohnung-strasse-dropdown2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Hausnummer Input': `[data-cy="checkout-vermietete-wohnung-hausnummer-input-2"]`,
  'Checkout Vermietete Wohnung 3. Kachel Wohnungsnummer Input': `[data-cy="checkout-vermietete-wohnung-wohnungsnummer-input-2"]`,

  'Checkout Vorversicherungen': `[data-cy="checkout-vorversicherungen"]`,
  'Checkout Beginn und Ablauf': `[data-cy="checkout-beginn-und-ablauf"]`,
  'Checkout Hauptfaelligkeit': `[data-cy="checkout-hauptfaelligkeit"]`,
  'Checkout Hauptfaelligkeit Input': `[data-cy="checkout-hauptfaelligkeit-input"]`,
  'Checkout Hauptfaelligkeit Input Error': `[data-cy="checkout-hauptfaelligkeit-input-error"]`,
  'Checkout BA Vertragslaufzeit Hinweis': `[data-cy="checkout-ba-vertragslaufzeit-hinweis"]`,
  'Checkout BA Kacheln': `[data-cy*="beginn-und-ablauf-kachel-"]`,
  'Checkout BA Kachel Hausratversicherung': `[data-cy="beginn-und-ablauf-kachel-vhv"]`,
  'Checkout BA Kachel Wohngebaeudeversicherung': `[data-cy="beginn-und-ablauf-kachel-vwg"]`,
  'Checkout BA Kachel Wohngebaeudeversicherung with Index': (index) =>
    `[data-cy="beginn-und-ablauf-kachel-vwg${index}"]`,
  'Checkout BA Kachel Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-kachel-ph"]`,
  'Checkout BA Kachel Hundehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-kachel-thh_hund"]`,
  'Checkout BA Kachel Pferdehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-kachel-thh_pferd"]`,
  'Checkout BA Kachel Tkv': `[data-cy="beginn-und-ablauf-kachel-tkv"]`,
  'Checkout BA Kachel Tkv with Index': (index) =>
    `[data-cy="beginn-und-ablauf-kachel-tkv${index}"]`,
  'Checkout BA Kachel Rechtschutzversicherung': `[data-cy="beginn-und-ablauf-kachel-rs"]`,
  'Checkout BA Kachel Beginn': `[data-cy="beginn-und-ablauf-beginn"]`,
  'Checkout BA Kachel Beginn Hausratversicherung': `[data-cy="beginn-und-ablauf-beginn-vhv"]`,
  'Checkout BA Kachel Beginn Hausratversicherung 0': `[data-cy="beginn-und-ablauf-beginn-vhv0"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung 0': `[data-cy="beginn-und-ablauf-ablauf-vhv0"]`,
  'Checkout BA Kachel Beginn Hausratversicherung 1': `[data-cy="beginn-und-ablauf-beginn-vhv1"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung 1': `[data-cy="beginn-und-ablauf-ablauf-vhv1"]`,
  'Checkout BA Kachel Beginn Hausratversicherung 2': `[data-cy="beginn-und-ablauf-beginn-vhv2"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung 2': `[data-cy="beginn-und-ablauf-ablauf-vhv2"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung Wirksamkeit Hinweis with Index':
    (index) =>
      `[data-cy="beginn-ablauf-wirksamkeitsbeginn-hinweis-vhv${index}-info"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung Beitragsfrei Hinweis with Index':
    (index) =>
      `[data-cy="beginn-ablauf-beitragsfrei-hinweis-vhv${index}-info"]`,
  'Checkout BA Kachel Beginn Hausratversicherung Error Message 0': `[data-cy="error-message-beginn-ablauf_vhv0"]`,
  'Checkout BA Kachel Beginn Hausratversicherung Error Message 1': `[data-cy="error-message-beginn-ablauf_vhv1"]`,
  'Checkout BA Kachel Beginn Wohngebaeudeversicherung': `[data-cy="beginn-und-ablauf-beginn-vwg"]`,
  'Checkout BA Kachel Beginn Wohngebaeudeversicherung 0': `[data-cy="beginn-und-ablauf-beginn-vwg0"]`,
  'Checkout BA Kachel Beginn Wohngebaeudeversicherung 1': `[data-cy="beginn-und-ablauf-beginn-vwg1"]`,
  'Checkout BA Kachel Beginn Wohngebaeudeversicherung 2': `[data-cy="beginn-und-ablauf-beginn-vwg2"]`,
  'Checkout BA Kachel Ablauf Wohngebaeudeversicherung Wirksamkeit Hinweis': `[data-cy="beginn-ablauf-wirksamkeitsbeginn-hinweis-vwg-info"]`,
  'Checkout BA Kachel Beginn Wohngebaeudeversicherung Error Message': `[data-cy="error-message-beginn-ablauf_vwg"]`,
  'Checkout BA Kachel Beginn Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-beginn-ph"]`,
  'Checkout BA Kachel Beginn Hundehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-beginn-thh_hund"]`,
  'Checkout BA Kachel Beginn Pferdehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-beginn-thh_pferd"]`,
  'Checkout BA Kachel Beginn Tkv': `[data-cy="beginn-und-ablauf-beginn-tkv"]`,
  'Checkout BA Kachel Beginn Tkv Error': `[data-cy="error-message-beginn-ablauf_tkv"]`,
  'Checkout BA Kachel Beginn Tkv with Index': (index) =>
    `[data-cy="beginn-und-ablauf-beginn-tkv${index}"]`,
  'Checkout BA Kachel Beginn Rechtschutzversicherung': `[data-cy="beginn-und-ablauf-beginn-rs"]`,
  'Checkout BA Kachel Laufzeit': `[data-cy="beginn-und-ablauf-laufzeit"]`,
  'Checkout BA Kachel Laufzeit Hausratversicherung': `[data-cy="beginn-und-ablauf-laufzeit-vhv"]`,
  'Checkout BA Kachel Laufzeit Wohngebaeudeversicherung': `[data-cy="beginn-und-ablauf-laufzeit-vwg"]`,
  'Checkout BA Kachel Laufzeit Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-laufzeit-ph"]`,
  'Checkout BA Kachel Laufzeit Hundehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-laufzeit-thh_hund"]`,
  'Checkout BA Kachel Laufzeit Pferdehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-laufzeit-thh_pferd"]`,
  'Checkout BA Kachel Laufzeit Tkv': `[data-cy="beginn-und-ablauf-laufzeit-tkv"]`,
  'Checkout BA Kachel Laufzeit Rechtschutzversicherung': `[data-cy="beginn-und-ablauf-laufzeit-rs"]`,
  'Checkout BA Kachel Ablauf': `[data-cy="beginn-und-ablauf-ablauf"]`,
  'Checkout BA Kachel Ablauf Hausratversicherung': `[data-cy="beginn-und-ablauf-ablauf-vhv"]`,
  'Checkout BA Kachel Ablauf Wohngebaeudeversicherung': `[data-cy="beginn-und-ablauf-ablauf-vwg"]`,
  'Checkout BA Kachel Ablauf Wohngebaeudeversicherung 0': `[data-cy="beginn-und-ablauf-ablauf-vwg0"]`,
  'Checkout BA Kachel Ablauf Wohngebaeudeversicherung 1': `[data-cy="beginn-und-ablauf-ablauf-vwg1"]`,
  'Checkout BA Kachel Ablauf Wohngebaeudeversicherung 2': `[data-cy="beginn-und-ablauf-ablauf-vwg2"]`,
  'Checkout BA Kachel Ablauf Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-ablauf-ph"]`,
  'Checkout BA Kachel Ablauf Hundehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-ablauf-thh_hund"]`,
  'Checkout BA Kachel Ablauf Pferdehalter-Haftpflichtversicherung': `[data-cy="beginn-und-ablauf-ablauf-thh_pferd"]`,
  'Checkout BA Kachel Ablauf Tkv': `[data-cy="beginn-und-ablauf-ablauf-tkv"]`,
  'Checkout BA Kachel Ablauf Rechtschutzversicherung': `[data-cy="beginn-und-ablauf-ablauf-rs"]`,

  'Checkout BA Vorversicherung Sparte': `[data-cy*="checkout-vorversicherung-sparte-"]`,
  'Checkout BA Vorversicherung Sparte PH': `[data-cy*="checkout-vorversicherung-sparte-ph-angebot"]`,
  'Checkout BA Vorversicherung DropDown Sparte PH': `[data-cy*="checkout-vorversicherungAngaben-ph-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr PH': `[data-cy="checkout-vorversicherungAngaben-ph-vsnrInput-0"]`,
  'Checkout BA Vorversicherung Ablaufdatum PH': `[data-cy="ablaufdatumVorversicherung_ph_0"]`,
  'Checkout BA Sofortschutz Hinweis PH': `[data-cy="beginn-ablauf-sofortschutz-hinweis-ph"]`,
  'Checkout BA Sofortschutz Hinweis PH Erfolg': `.context-success`,

  'Checkout BA Vorversicherung Sparte VWG': `[data-cy="checkout-vorversicherung-sparte-vwg-angebot"]`,
  'Checkout BA Vorversicherung Sparte VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherung-sparte-vwg-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Checkout BA Vorversicherung Sparte VHV with Index': (index) =>
    `[data-cy="checkout-vorversicherung-sparte-vhv-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Checkout BA Vorversicherung Sparte TKV with Index': (index) =>
    `[data-cy="checkout-vorversicherung-sparte-tkv-angebot"]:nth-of-type(${
      parseInt(index) + 1
    })`,
  'Checkout Vorversicherung Ablaufdatum TKV with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_tkv${index}_0"]`,
  'Checkout BA Vorversicherung DropDown Sparte VWG': `[data-cy="checkout-vorversicherungAngaben-vwg-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vwg${index}-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte TKV with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-tkv${index}-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte VHV with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vhv${index}-versicherungDropdown-0"]`,
  'Checkout BA VersichertesRisiko Sparte TKV with Index': (index) =>
    `[data-cy="checkout-versichertesRisiko-tkv${index}"]`,
  'Checkout BA VersichertesRisiko HausHalt VHV with Index': (index) =>
    `[data-cy="checkout-Haushalt-versichertesRisiko-${index}"]`,
  'Checkout BA Vorversicherung VersicherungsNr VWG': `[data-cy="checkout-vorversicherungAngaben-vwg-vsnrInput-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vwg${index}-vsnrInput-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr TKV with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-tkv${index}-vsnrInput-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr VHV with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vhv${index}-vsnrInput-0"]`,
  'Checkout BA Vorversicherung Gefahr Feuer VWG': `[data-cy="checkout-vorversicherungAngaben-vwg-gefahrenCheckbox-0"]`,
  'Checkout BA Vorversicherung Gefahr Feuer VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vwg${index}-gefahrenCheckbox-0"]`,
  'Checkout BA Vorversicherung Gefahr Feuer TKV with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-tkv${index}-gefahrenCheckbox-0"]`,
  'Checkout BA Vorversicherung Gefahr Sturm VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherungAngaben-vwg${index}-gefahrenCheckbox-1"]`,
  'Checkout BA Vorversicherung Ablaufdatum VWG': `[data-cy="ablaufdatumVorversicherung_vwg_0"]`,
  'Checkout BA Vorversicherung Ablaufdatum VWG with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_vwg${index}_0"]`,
  'Checkout BA Vorversicherung Ablaufdatum VHV with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_vhv${index}_0"]`,
  'Checkout BA Vorversicherung Ablaufdatum TKV with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_tkv${index}_0"]`,
  'Checkout BA Vorversicherung Warnung VWG': `#vorversicherungWarning_vwg`,
  'Checkout BA Sparte Vorversicherung Warnung VWG with Index': (index) =>
    `[data-cy="sparte_vorversicherungWarning_vwg${index}"]`,
  'Checkout BA Sparte Vorversicherung Warnung TKV with Index': (index) =>
    `[data-cy="sparte_vorversicherungWarning_tkv${index}"]`,

  'Checkout BA Sofortschutz Hinweis VWG': `[data-cy="beginn-ablauf-sofortschutz-hinweis-vwg"]`,
  'Checkout BA Sofortschutz Hinweis VWG error': `[data-cy="beginn-ablauf-sofortschutz-hinweis-vwg-error"]`,
  'Checkout BA Sofortschutz Hinweis VWG with Index': (index) =>
    `[data-cy="beginn-ablauf-sofortschutz-hinweis-vwg${index}"]`,
  'Checkout BA Sofortschutz Hinweis VHV with Index': (index) =>
    `[data-cy="beginn-ablauf-sofortschutz-hinweis-vhv${index}"]`,
  'Checkout BA Sofortschutz Hinweis VWG Erfolg': `.context-success`,

  'Checkout BA Vorversicherung Sparte VHV': `[data-cy="checkout-vorversicherung-sparte-vhv-angebot"]`,
  'Checkout BA Vorversicherung DropDown Sparte VHV': `[data-cy="checkout-vorversicherungAngaben-vhv-versicherungDropdown-0"]`,
  'Checkout BA 2nd Vorversicherung DropDown Sparte VHV': `[data-cy="checkout-vorversicherungAngaben-vhv-versicherungDropdown-1"]`,
  'Checkout BA Vorversicherung VersicherungsNr VHV': `[data-cy="checkout-vorversicherungAngaben-vhv-vsnrInput-0"]`,
  'Checkout BA 2nd Vorversicherung VersicherungsNr VHV': `[data-cy="checkout-vorversicherungAngaben-vhv-vsnrInput-1"]`,
  'Checkout BA Vorversicherung Ablaufdatum VHV': `[data-cy="ablaufdatumVorversicherung_vhv_0"]`,
  'Checkout BA 2nd Vorversicherung Ablaufdatum VHV': `[data-cy="ablaufdatumVorversicherung_vhv_1"]`,
  'Checkout BA Sofortschutz Hinweis VHV': `[data-cy="beginn-ablauf-sofortschutz-hinweis-vhv"]`,
  'Checkout BA Sofortschutz Hinweis VHV Erfolg': `.context-success`,

  'Checkout BA Vorversicherung Sparte RS': `[data-cy="checkout-vorversicherungcard-rs-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte RS': `[data-cy="checkout-vorversicherungAngaben-rs-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr RS': `[data-cy="checkout-vorversicherungAngaben-rs-vsnrInput-0"]`,
  'Checkout BA Vorversicherung Ablaufdatum RS': `[data-cy="ablaufdatumVorversicherung_rs_0"]`,
  'Checkout BA Vorversicherung Ablaufdatum RS Error': `[data-cy="ablaufdatumVorversicherung_rs_0_error"]`,
  'Checkout BA Sofortschutz Hinweis RS': `[data-cy="beginn-ablauf-sofortschutz-hinweis-rs"]`,
  'Checkout BA Sofortschutz Hinweis RS Erfolg': `.context-success`,

  'Checkout Vorversicherung VWG Sparte': `[data-cy="checkout-vorversicherung-sparte-vwg-"]`,
  'Checkout Vorversicherung VWG Sparte with Index': (index) =>
    `[data-cy="checkout-vorversicherung-sparte-vwg-${index}"]`,
  'Checkout Vorversicherung VHV Sparte': `[data-cy="checkout-vorversicherung-sparte-vhv-"]`,
  'Checkout Vorversicherung CheckoutSparte': `[data-cy="checkout-vorversicherung-sparte-vhv-"]`,
  'Checkout Vorversicherung VWG Radio': `[data-cy="checkout-vorversicherung-vwg-radio"]`,
  'Checkout Vorversicherung VWG Radio with Index': (index) =>
    `[data-cy="checkout-vorversicherung-vwg${index}-radio"]`,
  'Checkout Vorversicherung TKV Radio with Index': (index) =>
    `[data-cy="checkout-vorversicherung-tkv${index}-radio"]`,
  'Checkout Vorversicherung VHV Radio': `[data-cy="checkout-vorversicherung-vhv-radio"]`,
  'Checkout Vorversicherung VHV Radio with Index': (index) =>
    `[data-cy="checkout-vorversicherung-vhv${index}-radio"]`,
  'Checkout Vorversicherung PH Radio': `[data-cy="checkout-vorversicherung-ph-radio"]`,
  'Checkout Vorversicherung RS Radio': `[data-cy="checkout-vorversicherung-rs-radio"]`,
  'Checkout Vorversicherung RS Radio Nein': `[data-cy="vorversicherung-nein-rs"]`,
  'Checkout Vorversicherung RS Radio Ja': `[data-cy="vorversicherung-ja-rs"]`,
  'Checkout Vorversicherung THH_HUND Radio': `[data-cy="checkout-vorversicherung-thh_hund-radio"]`,
  'Checkout Vorversicherung THH_PFERD Radio': `[data-cy="checkout-vorversicherung-thh_pferd-radio"]`,
  'Checkout Wertsachen VHV Radio': `[data-cy="checkout-wertsachen-radio"]`,
  'Checkout Wertsachen VHV Radio with Index': (index) =>
    `[data-cy="checkout-wertsachen-radio-${index}"]`,
  'Checkout HausHaltWertsachen VHV Radio Error with Index': (index) =>
    `[data-cy="checkout-hasWertsachen-error-${index}"]`,
  'Checkout Wertsachen VHV Radio Error with Index': (index) =>
    `[data-cy="checkout-wertsachen-error-${index}"]`,
  'Checkout Wertsachen VHV Radio Error': `[data-cy="checkout-wertsachen-error"]`,
  'Checkout Vorversicherung Kachel': `[data-cy*="checkout-vorversicherungcard-"]`,
  'Checkout Vorversicherung Kachel VWG': `[data-cy*="checkout-vorversicherungcard-vwg"]`,
  'Checkout Vorversicherung Kachel VWG with Index': (index) =>
    `[data-cy="checkout-vorversicherungcard-vwg${index}-0"]`,
  'Checkout Vorversicherung Kachel TKV with Index': (index) =>
    `[data-cy="checkout-vorversicherungcard-tkv${index}-0"]`,
  'Checkout Vorversicherung Kachel VHV': `[data-cy*="checkout-vorversicherungcard-vhv"]`,
  'Checkout Vorversicherung VWG VSNR Input': `[data-cy="checkout-vorversicherungAngaben-vwg-vsnrInput-0"]`,
  'Checkout Vorversicherung VWG Gesellschaft Dropdown': `[data-cy="checkout-vorversicherungAngaben-vwg-versicherungDropdown-0"]`,
  'Checkout Vorversicherung Kachel VWG 0': `[data-cy="checkout-vorversicherungcard-vwg-0"]`,
  'Checkout Vorversicherung Kachel VWG 1': `[data-cy="checkout-vorversicherungcard-vwg-1"]`,
  'Checkout Vorversicherung Kachel VWG 2': `[data-cy="checkout-vorversicherungcard-vwg-2"]`,
  'Checkout Vorversicherung VWG Versicherte Gefahr required error': `[id="versichertegefahr_vwg_0_Error"]`,
  'Checkout Vorversicherung Kachel TKV 0': `[data-cy="checkout-vorversicherungcard-tkv-0"]`,
  'Checkout Vorversicherung Kachel TKV 1': `[data-cy="checkout-vorversicherungcard-tkv-1"]`,
  'Checkout Vorversicherung VHV VSNR Input': `[data-cy="checkout-vorversicherungAngaben-vhv-vsnrInput-0"]`,
  'Checkout Vorversicherung VHV Gesellschaft Dropdown': `[data-cy="checkout-vorversicherungAngaben-vhv-versicherungDropdown-0"]`,
  'Checkout Vorversicherung Kachel VHV 0': `[data-cy="checkout-vorversicherungcard-vhv-0"]`,
  'Checkout Vorversicherung Kachel VHV 1': `[data-cy="checkout-vorversicherungcard-vhv-1"]`,
  'Checkout Vorversicherung Kachel VHV 2': `[data-cy="checkout-vorversicherungcard-vhv-2"]`,

  'Checkout Vorversicherung Kachel THH_HUND 0': `[data-cy="checkout-vorversicherungcard-thh_hund-0"]`,
  'Checkout Vorversicherung Kachel THH_HUND 1': `[data-cy="checkout-vorversicherungcard-thh_hund-1"]`,
  'Checkout Vorversicherung Kachel THH_HUND 2': `[data-cy="checkout-vorversicherungcard-thh_hund-2"]`,
  'Checkout Vorversicherung THH_HUND Gesellschaft Dropdown': `[data-cy="checkout-vorversicherungAngaben-thh_hund-versicherungDropdown-0"]`,
  'Checkout Vorversicherung THH_HUND Gesellschaft Dropdown 1': `[data-cy="checkout-vorversicherungAngaben-thh_hund-versicherungDropdown-1"]`,
  'Checkout Vorversicherung THH_HUND VSNR Input': `[data-cy="checkout-vorversicherungAngaben-thh_hund-vsnrInput-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr THH_HUND': `[data-cy="checkout-vorversicherungAngaben-thh_hund-vsnrInput-0"]`,
  'Checkout Vorversicherung THH_HUND VSNR Input 1': `[data-cy="checkout-vorversicherungAngaben-thh_hund-vsnrInput-1"]`,
  'Checkout BA Sofortschutz Hinweis THH_HUND': `[data-cy="beginn-ablauf-sofortschutz-hinweis-thh_hund"]`,

  'Checkout Vorversicherung Kachel THH_PFERD 0': `[data-cy="checkout-vorversicherungcard-thh_pferd-0"]`,
  'Checkout Vorversicherung Kachel THH_PFERD 1': `[data-cy="checkout-vorversicherungcard-thh_pferd-1"]`,
  'Checkout Vorversicherung Kachel THH_PFERD 2': `[data-cy="checkout-vorversicherungcard-thh_pferd-2"]`,
  'Checkout Vorversicherung THH_PFERD Gesellschaft Dropdown': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-versicherungDropdown-0"]`,
  'Checkout Vorversicherung THH_PFERD Gesellschaft Dropdown 1': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-versicherungDropdown-1"]`,
  'Checkout Vorversicherung THH_PFERD Gesellschaft Dropdown 2': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-versicherungDropdown-2"]`,
  'Checkout Vorversicherung THH_PFERD VSNR Input': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-vsnrInput-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr THH_PFERD': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-vsnrInput-0"]`,
  'Checkout Vorversicherung THH_PFERD VSNR Input 1': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-vsnrInput-1"]`,
  'Checkout Vorversicherung THH_PFERD VSNR Input 2': `[data-cy="checkout-vorversicherungAngaben-thh_pferd-vsnrInput-2"]`,
  'Checkout BA Sofortschutz Hinweis THH_PFERD': `[data-cy="beginn-ablauf-sofortschutz-hinweis-thh_pferd"]`,

  'Checkout Vorversicherung Ablaufdatum VHV 0': `[data-cy="ablaufdatumVorversicherung_vhv_0"]`,
  'Checkout Vorversicherung Ablaufdatum VHV 0 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_vhv_0]`,
  'Checkout Vorversicherung Ablaufdatum VHV 0 Datepicker Right': `.nx-icon--chevron-right`,
  'Sofortschutz Hinweis VHV': `[data-cy="beginn-ablauf-sofortschutz-hinweis-Hausratversicherung"]`,

  'Checkout Vorversicherung Ablaufdatum VWG 0': `[data-cy="ablaufdatumVorversicherung_vwg_0"]`,
  'Checkout Vorversicherung Ablaufdatum VWG with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_vwg${index}_0"]`,

  'Checkout Vorversicherung Ablaufdatum VWG 0 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_vwg_0]`,
  'Checkout Vorversicherung Ablaufdatum VWG Datepicker with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_Datepicker_vwg${index}_0"]`,
  'Checkout Vorversicherung Ablaufdatum VWG 0 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum PH 0': `[data-cy="ablaufdatumVorversicherung_ph_0"]`,
  'Checkout Vorversicherung Ablaufdatum PH 0 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_ph_0]`,
  'Checkout Vorversicherung Ablaufdatum PH 0 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_HUND 0': `[data-cy="ablaufdatumVorversicherung_thh_hund_0"]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 0 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_hund_0]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 0 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_HUND 1': `[data-cy="ablaufdatumVorversicherung_thh_hund_1"]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 1 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_hund_1]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 1 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_HUND 2': `[data-cy="ablaufdatumVorversicherung_thh_hund_2"]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 2 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_hund_2]`,
  'Checkout Vorversicherung Ablaufdatum THH_HUND 2 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_PFERD 0': `[data-cy="ablaufdatumVorversicherung_thh_pferd_0"]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 0 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_pferd_0]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 0 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_PFERD 1': `[data-cy="ablaufdatumVorversicherung_thh_pferd_1"]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 1 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_pferd_1]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 1 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout Vorversicherung Ablaufdatum THH_PFERD 2': `[data-cy="ablaufdatumVorversicherung_thh_pferd_2"]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 2 Datepicker': `[data-cy=ablaufdatumVorversicherung_Datepicker_thh_pferd_2]`,
  'Checkout Vorversicherung Ablaufdatum THH_PFERD 2 Datepicker Right': `.nx-icon--chevron-right`,

  'Checkout BA Vorversicherung Sparte TKV': `[data-cy*="checkout-vorversicherung-sparte-tkv"]`,
  'Checkout Vorversicherung TKV Radio': `[data-cy="checkout-vorversicherung-tkv-radio"]`,
  'Checkout BA Vorversicherung DropDown Sparte TKV': `[data-cy*="checkout-vorversicherungAngaben-tkv-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte THH_HUND': `[data-cy*="checkout-vorversicherungAngaben-thh_hund-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung DropDown Sparte THH_PFERD': `[data-cy*="checkout-vorversicherungAngaben-thh_pferd-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr TKV': `[data-cy="checkout-vorversicherungAngaben-tkv-vsnrInput-0"]`,
  'Checkout BA Vorversicherung Ablaufdatum TKV': `[data-cy="ablaufdatumVorversicherung_tkv_0"]`,
  'Checkout Vorversicherung Ablaufdatum TKV Datepicker with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_Datepicker_tkv${index}_0"]`,
  'Checkout Vorversicherung Ablaufdatum TKV 0 Datepicker Right': `.nx-icon--chevron-right`,
  'Checkout BA Sofortschutz Hinweis TKV with Index': (index) =>
    `[data-cy="beginn-ablauf-sofortschutz-hinweis-tkv${index}"]`,
  'Checkout BA Sofortschutz Info TKV with Index': (index) =>
    `[data-cy="beginn-ablauf-sofortschutz-hinweis-tkv${index}-info"]`,
  'Checkout BA Sofortschutz Error TKV with Index': (index) =>
    `[data-cy="ablaufdatumVorversicherung_tkv${index}_${index}_error"]`,

  'Checkout BA Vorversicherung DropDown Sparte UNF': '[data-cy*="checkout-vorversicherungAngaben-unf-versicherungDropdown-0"]',
  'Checkout BA Vorversicherung VersicherungsNr UNF': '[data-cy="checkout-vorversicherungAngaben-unf-vsnrInput-0"]',

  'Checkout Vorversicherung JHP Radio': '[data-cy="checkout-vorversicherung-jhp-radio"]',
  'Checkout Vorversicherung UNF Radio': '[data-cy="checkout-vorversicherung-unf-radio"]',

  'Checkout Add Vorversicherung': `[data-cy="add-new-vorversicherung"]`,
  'Checkout Delete Vorversicherung': `[data-cy*="delete_vorversicherung_button_"]`,

  'Checkout Required Error VWG Vorversicherung': `[data-cy*="vorversicherungsError_vwg"]`,
  'Checkout Required Error VHV Vorversicherung': `[data-cy*="vorversicherungsError_vhv"]`,
  
  'Checkout SG Ja Nein Radio': `[data-cy="checkout-sg-ja-nein-radio"]`,
  'Checkout SG Hinweis': `[data-cy="checkout-sicherungsglaeubiger-info"]`,

  'Checkout SG Adressart Radio 0': `[data-cy="sicherungsglaeubiger-adressart-radio0"]`,
  'Checkout SG Name Input 0': `[data-cy="checkout-sg-name-input0"]`,
  'Checkout SG Plz Input 0': `[data-cy="checkout-sg-plz-input0"]`,
  'Checkout SG Ort Input 0': `[data-cy="checkout-sg-ort-input0"]`,
  'Checkout SG Ort Vorschlag 0': `[data-cy="checkout-sg-ort-vorschlag0"]`,
  'Checkout SG Ort Dropdown 0': `[data-cy="checkout-sg-ort-dropdown0"]`,
  'Checkout SG Strasse Input 0': `[data-cy="checkout-sg-strasse-input0"]`,
  'Checkout SG Strasse Vorschlag 0': `[data-cy="checkout-sg-strasse-vorschlag0"]`,
  'Checkout SG Strasse Dropdown 0': `[data-cy="checkout-sg-strasse-dropdown0"]`,
  'Checkout SG Hausnummer Input 0': `[data-cy="checkout-sg-hsnr-input0"]`,
  'Checkout SG Aktenzeichen Input 0': `[data-cy="checkout-sg-aktenzeichen-input0"]`,
  'Checkout SG Postfach Input 0': `[data-cy="sicherungsglaeubiger-adresse-postfach0"]`,

  'Checkout SG Adressart Radio 1': `[data-cy="sicherungsglaeubiger-adressart-radio1"]`,
  'Checkout SG Name Input 1': `[data-cy="checkout-sg-name-input1"]`,
  'Checkout SG Plz Input 1': `[data-cy="checkout-sg-plz-input1"]`,
  'Checkout SG Ort Input 1': `[data-cy="checkout-sg-ort-input1"]`,
  'Checkout SG Ort Vorschlag 1': `[data-cy="checkout-sg-ort-vorschlag1"]`,
  'Checkout SG Ort Dropdown 1': `[data-cy="checkout-sg-ort-dropdown1"]`,
  'Checkout SG Strasse Input 1': `[data-cy="checkout-sg-strasse-input1"]`,
  'Checkout SG Strasse Vorschlag 1': `[data-cy="checkout-sg-strasse-vorschlag1"]`,
  'Checkout SG Strasse Dropdown 1': `[data-cy="checkout-sg-strasse-dropdown1"]`,
  'Checkout SG Hausnummer Input 1': `[data-cy="checkout-sg-hsnr-input1"]`,
  'Checkout SG Aktenzeichen Input 1': `[data-cy="checkout-sg-aktenzeichen-input1"]`,
  'Checkout SG Postfach Input 1': `[data-cy="sicherungsglaeubiger-adresse-postfach1"]`,

  'Checkout SG Adressart Radio 2': `[data-cy="sicherungsglaeubiger-adressart-radio2"]`,
  'Checkout SG Name Input 2': `[data-cy="checkout-sg-name-input2"]`,
  'Checkout SG Plz Input 2': `[data-cy="checkout-sg-plz-input2"]`,
  'Checkout SG Ort Input 2': `[data-cy="checkout-sg-ort-input2"]`,
  'Checkout SG Ort Vorschlag 2': `[data-cy="checkout-sg-ort-vorschlag2"]`,
  'Checkout SG Ort Dropdown 2': `[data-cy="checkout-sg-ort-dropdown2"]`,
  'Checkout SG Strasse Input 2': `[data-cy="checkout-sg-strasse-input2"]`,
  'Checkout SG Strasse Vorschlag 2': `[data-cy="checkout-sg-strasse-vorschlag2"]`,
  'Checkout SG Strasse Dropdown 2': `[data-cy="checkout-sg-strasse-dropdown2"]`,
  'Checkout SG Hausnummer Input 2': `[data-cy="checkout-sg-hsnr-input2"]`,
  'Checkout SG Aktenzeichen Input 2': `[data-cy="checkout-sg-aktenzeichen-input2"]`,
  'Checkout SG Postfach Input 2': `[data-cy="sicherungsglaeubiger-adresse-postfach2"]`,

  'Checkout SG Link Weitere SG 0': `[data-cy="sicherungsglaeubiger-link-weitere0"]`,

  'Checkout Sicherungsglaeubiger': `checkout-sicherungsglaeubiger`,
  'Checkout Sicherungsglaeubiger Bankname 0 Input': `#bankname0`,
  'Checkout Sicherungsglaeubiger Postleitzahl 0 Input': `#plz0`,
  'Checkout Sicherungsglaeubiger Ort 0 Input': `#ort0`,
  'Checkout Sicherungsglaeubiger Strasse 0 Input': `#strasse0`,
  'Checkout Sicherungsglaeubiger Hausnr 0 Input': `#hausnr0`,
  'Checkout Sicherungsglaeubiger Aktenzeichen 0 Input': `#aktenzeichen0`,
  'Checkout Sicherungsglaeubiger Bankname 1 Input': `#bankname1`,
  'Checkout Sicherungsglaeubiger Postleitzahl 1 Input': `#plz1`,
  'Checkout Sicherungsglaeubiger Ort 1 Input': `#ort1`,
  'Checkout Sicherungsglaeubiger Strasse 1 Input': `#strasse1`,
  'Checkout Sicherungsglaeubiger Hausnr 1 Input': `#hausnr1`,
  'Checkout Sicherungsglaeubiger Aktenzeichen 1 Input': `#aktenzeichen1`,
  'Checkout Sicherungsglaeubiger Bankname 2 Input': `#bankname2`,
  'Checkout Sicherungsglaeubiger Postleitzahl 2 Input': `#plz2`,
  'Checkout Sicherungsglaeubiger Ort 2 Input': `#ort2`,
  'Checkout Sicherungsglaeubiger Strasse 2 Input': `#strasse2`,
  'Checkout Sicherungsglaeubiger Hausnr 2 Input': `#hausnr2`,
  'Checkout Sicherungsglaeubiger Aktenzeichen 2 Input': `#aktenzeichen2`,
  'Checkout Add Sicherungsglaeubiger': `#fremdfinanzierungHinzufuegen`,

  'Checkout Pferd Angaben Komponente':
    '[data-cy="thh-pferd-angaben-komponente"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 0':
    '[data-cy="thh-pferd-angaben-geschlecht-M-0"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 0':
    '[data-cy="thh-pferd-angaben-geschlecht-W-0"]',
  'Checkout Pferd Angaben Geschlecht Error 0':
    '[data-cy="thh-pferd-angaben-geschlecht-error-0"]',
  'Checkout Pferd Angaben Name with Index': (index) =>
    `[data-cy="thh-pferd-angaben-name-${index}"]`,
  'Checkout Pferd Angaben Geburtsdatum with Index': (index) =>
    `[data-cy="thh-pferd-angaben-geburtsdatum-${index}"]`,
  'Checkout Pferd Kennzeichnung Input with Index': (index) =>
    `[data-cy="thh-pferd-angaben-${index}-tier-kennzeichnung-input"]`,
  'Checkout Pferd Angaben Name 0': '[data-cy="thh-pferd-angaben-name-0"]',
  'Checkout Pferd Angaben Name Pattern Error 0':
    '[data-cy="thh-pferd-angaben-name-pattern-error-0"]',
  'Checkout Pferd Angaben Name Required Error 0':
    '[data-cy="thh-pferd-angaben-name-required-error-0"]',
  'Checkout Pferd Angaben Geburtsdatum 0':
    '[data-cy="thh-pferd-angaben-geburtsdatum-0"]',
  'Checkout Pferd Angaben Date Pattern Error 0':
    '[data-cy="thh-pferd-angaben-date-pattern-error-0"]',
  'Checkout Pferd Angaben Date Required Error 0':
    '[data-cy="thh-pferd-angaben-date-required-error-0"]',
  'Checkout Pferd Angaben Dropdown 0':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-0"]',
  'Checkout Pferd Angaben Dropdown First Item 0':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-0-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 0':
    '[data-cy="thh-pferd-angaben-rasse-required-error-0"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 1':
    '[data-cy="thh-pferd-angaben-geschlecht-M-1"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 1':
    '[data-cy="thh-pferd-angaben-geschlecht-W-1"]',
  'Checkout Pferd Angaben Geschlecht Error 1':
    '[data-cy="thh-pferd-angaben-geschlecht-error-1"]',
  'Checkout Pferd Angaben Name 1': '[data-cy="thh-pferd-angaben-name-1"]',
  'Checkout Pferd Angaben Name Pattern Error 1':
    '[data-cy="thh-pferd-angaben-name-pattern-error-1"]',
  'Checkout Pferd Angaben Name Required Error 1':
    '[data-cy="thh-pferd-angaben-name-required-error-1"]',
  'Checkout Pferd Angaben Geburtsdatum 1':
    '[data-cy="thh-pferd-angaben-geburtsdatum-1"]',
  'Checkout Pferd Angaben Date Pattern Error 1':
    '[data-cy="thh-pferd-angaben-date-pattern-error-1"]',
  'Checkout Pferd Angaben Date Required Error 1':
    '[data-cy="thh-pferd-angaben-date-required-error-1"]',
  'Checkout Pferd Angaben Dropdown 1':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-1"]',
  'Checkout Pferd Angaben Dropdown First Item 1':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-1-item-1"]',
  'Checkout Pferd Angaben Dropdown Required Error 1':
    '[data-cy="thh-pferd-angaben-rasse-required-error-1"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 2':
    '[data-cy="thh-pferd-angaben-geschlecht-M-2"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 2':
    '[data-cy="thh-pferd-angaben-geschlecht-W-2"]',
  'Checkout Pferd Angaben Geschlecht Error 2':
    '[data-cy="thh-pferd-angaben-geschlecht-error-2"]',
  'Checkout Pferd Angaben Name 2': '[data-cy="thh-pferd-angaben-name-2"]',
  'Checkout Pferd Angaben Name Pattern Error 2':
    '[data-cy="thh-pferd-angaben-name-pattern-error-2"]',
  'Checkout Pferd Angaben Name Required Error 2':
    '[data-cy="thh-pferd-angaben-name-required-error-2"]',
  'Checkout Pferd Angaben Geburtsdatum 2':
    '[data-cy="thh-pferd-angaben-geburtsdatum-2"]',
  'Checkout Pferd Angaben Date Pattern Error 2':
    '[data-cy="thh-pferd-angaben-date-pattern-error-2"]',
  'Checkout Pferd Angaben Date Required Error 2':
    '[data-cy="thh-pferd-angaben-date-required-error-2"]',
  'Checkout Pferd Angaben Dropdown 2':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-2"]',
  'Checkout Pferd Angaben Dropdown First Item 2':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-2-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 2':
    '[data-cy="thh-pferd-angaben-rasse-required-error-2"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 3':
    '[data-cy="thh-pferd-angaben-geschlecht-M-3"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 3':
    '[data-cy="thh-pferd-angaben-geschlecht-W-3"]',
  'Checkout Pferd Angaben Geschlecht Error 3':
    '[data-cy="thh-pferd-angaben-geschlecht-error-3"]',
  'Checkout Pferd Angaben Name 3': '[data-cy="thh-pferd-angaben-name-3"]',
  'Checkout Pferd Angaben Name Pattern Error 3':
    '[data-cy="thh-pferd-angaben-name-pattern-error-3"]',
  'Checkout Pferd Angaben Name Required Error 3':
    '[data-cy="thh-pferd-angaben-name-required-error-3"]',
  'Checkout Pferd Angaben Geburtsdatum 3':
    '[data-cy="thh-pferd-angaben-geburtsdatum-3"]',
  'Checkout Pferd Angaben Date Pattern Error 3':
    '[data-cy="thh-pferd-angaben-date-pattern-error-3"]',
  'Checkout Pferd Angaben Date Required Error 3':
    '[data-cy="thh-pferd-angaben-date-required-error-3"]',
  'Checkout Pferd Angaben Dropdown 3':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-3"]',
  'Checkout Pferd Angaben Dropdown First Item 3':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-3-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 3':
    '[data-cy="thh-pferd-angaben-rasse-required-error-3"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 4':
    '[data-cy="thh-pferd-angaben-geschlecht-M-4"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 4':
    '[data-cy="thh-pferd-angaben-geschlecht-W-4"]',
  'Checkout Pferd Angaben Geschlecht Error 4':
    '[data-cy="thh-pferd-angaben-geschlecht-error-4"]',
  'Checkout Pferd Angaben Name 4': '[data-cy="thh-pferd-angaben-name-4"]',
  'Checkout Pferd Angaben Name Pattern Error 4':
    '[data-cy="thh-pferd-angaben-name-pattern-error-4"]',
  'Checkout Pferd Angaben Name Required Error 4':
    '[data-cy="thh-pferd-angaben-name-required-error-4"]',
  'Checkout Pferd Angaben Geburtsdatum 4':
    '[data-cy="thh-pferd-angaben-geburtsdatum-4"]',
  'Checkout Pferd Angaben Date Pattern Error 4':
    '[data-cy="thh-pferd-angaben-date-pattern-error-4"]',
  'Checkout Pferd Angaben Date Required Error 4':
    '[data-cy="thh-pferd-angaben-date-required-error-4"]',
  'Checkout Pferd Angaben Dropdown 4':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-4"]',
  'Checkout Pferd Angaben Dropdown First Item 4':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-4-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 4':
    '[data-cy="thh-pferd-angaben-rasse-required-error-4"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 5':
    '[data-cy="thh-pferd-angaben-geschlecht-M-5"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 5':
    '[data-cy="thh-pferd-angaben-geschlecht-W-5"]',
  'Checkout Pferd Angaben Geschlecht Error 5':
    '[data-cy="thh-pferd-angaben-geschlecht-error-5"]',
  'Checkout Pferd Angaben Name 5': '[data-cy="thh-pferd-angaben-name-5"]',
  'Checkout Pferd Angaben Name Pattern Error 5':
    '[data-cy="thh-pferd-angaben-name-pattern-error-5"]',
  'Checkout Pferd Angaben Name Required Error 5':
    '[data-cy="thh-pferd-angaben-name-required-error-5"]',
  'Checkout Pferd Angaben Geburtsdatum 5':
    '[data-cy="thh-pferd-angaben-geburtsdatum-5"]',
  'Checkout Pferd Angaben Date Pattern Error 5':
    '[data-cy="thh-pferd-angaben-date-pattern-error-5"]',
  'Checkout Pferd Angaben Date Required Error 5':
    '[data-cy="thh-pferd-angaben-date-required-error-5"]',
  'Checkout Pferd Angaben Dropdown 5':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-5"]',
  'Checkout Pferd Angaben Dropdown First Item 5':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-5-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 5':
    '[data-cy="thh-pferd-angaben-rasse-required-error-5"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 6':
    '[data-cy="thh-pferd-angaben-geschlecht-M-6"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 6':
    '[data-cy="thh-pferd-angaben-geschlecht-W-6"]',
  'Checkout Pferd Angaben Geschlecht Error 6':
    '[data-cy="thh-pferd-angaben-geschlecht-error-6"]',
  'Checkout Pferd Angaben Name 6': '[data-cy="thh-pferd-angaben-name-6"]',
  'Checkout Pferd Angaben Name Pattern Error 6':
    '[data-cy="thh-pferd-angaben-name-pattern-error-6"]',
  'Checkout Pferd Angaben Name Required Error 6':
    '[data-cy="thh-pferd-angaben-name-required-error-6"]',
  'Checkout Pferd Angaben Geburtsdatum 6':
    '[data-cy="thh-pferd-angaben-geburtsdatum-6"]',
  'Checkout Pferd Angaben Date Pattern Error 6':
    '[data-cy="thh-pferd-angaben-date-pattern-error-6"]',
  'Checkout Pferd Angaben Date Required Error 6':
    '[data-cy="thh-pferd-angaben-date-required-error-6"]',
  'Checkout Pferd Angaben Dropdown 6':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-6"]',
  'Checkout Pferd Angaben Dropdown First Item 6':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-6-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 6':
    '[data-cy="thh-pferd-angaben-rasse-required-error-6"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 7':
    '[data-cy="thh-pferd-angaben-geschlecht-M-7"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 7':
    '[data-cy="thh-pferd-angaben-geschlecht-W-7"]',
  'Checkout Pferd Angaben Geschlecht Error 7':
    '[data-cy="thh-pferd-angaben-geschlecht-error-7"]',
  'Checkout Pferd Angaben Name 7': '[data-cy="thh-pferd-angaben-name-7"]',
  'Checkout Pferd Angaben Name Pattern Error 7':
    '[data-cy="thh-pferd-angaben-name-pattern-error-7"]',
  'Checkout Pferd Angaben Name Required Error 7':
    '[data-cy="thh-pferd-angaben-name-required-error-7"]',
  'Checkout Pferd Angaben Geburtsdatum 7':
    '[data-cy="thh-pferd-angaben-geburtsdatum-7"]',
  'Checkout Pferd Angaben Date Pattern Error 7':
    '[data-cy="thh-pferd-angaben-date-pattern-error-7"]',
  'Checkout Pferd Angaben Date Required Error 7':
    '[data-cy="thh-pferd-angaben-date-required-error-7"]',
  'Checkout Pferd Angaben Dropdown 7':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-7"]',
  'Checkout Pferd Angaben Dropdown First Item 7':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-7-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 7':
    '[data-cy="thh-pferd-angaben-rasse-required-error-7"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 8':
    '[data-cy="thh-pferd-angaben-geschlecht-M-8"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 8':
    '[data-cy="thh-pferd-angaben-geschlecht-W-8"]',
  'Checkout Pferd Angaben Geschlecht Error 8':
    '[data-cy="thh-pferd-angaben-geschlecht-error-8"]',
  'Checkout Pferd Angaben Name 8': '[data-cy="thh-pferd-angaben-name-8"]',
  'Checkout Pferd Angaben Name Pattern Error 8':
    '[data-cy="thh-pferd-angaben-name-pattern-error-8"]',
  'Checkout Pferd Angaben Name Required Error 8':
    '[data-cy="thh-pferd-angaben-name-required-error-8"]',
  'Checkout Pferd Angaben Geburtsdatum 8':
    '[data-cy="thh-pferd-angaben-geburtsdatum-8"]',
  'Checkout Pferd Angaben Date Pattern Error 8':
    '[data-cy="thh-pferd-angaben-date-pattern-error-8"]',
  'Checkout Pferd Angaben Date Required Error 8':
    '[data-cy="thh-pferd-angaben-date-required-error-8"]',
  'Checkout Pferd Angaben Dropdown 8':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-8"]',
  'Checkout Pferd Angaben Dropdown First Item 8':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-8-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 8':
    '[data-cy="thh-pferd-angaben-rasse-required-error-8"]',
  'Checkout Pferd Angaben Geschlecht Maennlich 9':
    '[data-cy="thh-pferd-angaben-geschlecht-M-9"]',
  'Checkout Pferd Angaben Geschlecht Weiblich 9':
    '[data-cy="thh-pferd-angaben-geschlecht-W-9"]',
  'Checkout Pferd Angaben Geschlecht Error 9':
    '[data-cy="thh-pferd-angaben-geschlecht-error-9"]',
  'Checkout Pferd Angaben Name 9': '[data-cy="thh-pferd-angaben-name-9"]',
  'Checkout Pferd Angaben Name Pattern Error 9':
    '[data-cy="thh-pferd-angaben-name-pattern-error-9"]',
  'Checkout Pferd Angaben Name Required Error 9':
    '[data-cy="thh-pferd-angaben-name-required-error-9"]',
  'Checkout Pferd Angaben Geburtsdatum 9':
    '[data-cy="thh-pferd-angaben-geburtsdatum-9"]',
  'Checkout Pferd Angaben Date Pattern Error 9':
    '[data-cy="thh-pferd-angaben-date-pattern-error-9"]',
  'Checkout Pferd Angaben Date Required Error 9':
    '[data-cy="thh-pferd-angaben-date-required-error-9"]',
  'Checkout Pferd Angaben Dropdown 9':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-9"]',
  'Checkout Pferd Angaben Dropdown First Item 9':
    '[data-cy="thh-pferd-angaben-rasse-dropdown-9-item-0"]',
  'Checkout Pferd Angaben Dropdown Required Error 9':
    '[data-cy="thh-pferd-angaben-rasse-required-error-9"]',

  'Checkout Pferd Kennzeichnung Radio 0':
    '[data-cy="thh-pferd-angaben-0-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 0':
    '[data-cy="thh-pferd-angaben-0-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 0':
    '[data-cy="thh-pferd-angaben-0-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 0':
    '[data-cy="thh-pferd-angaben-0-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 0':
    '[data-cy="thh-pferd-angaben-0-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 1':
    '[data-cy="thh-pferd-angaben-1-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 1':
    '[data-cy="thh-pferd-angaben-1-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 1':
    '[data-cy="thh-pferd-angaben-1-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 1':
    '[data-cy="thh-pferd-angaben-1-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 1':
    '[data-cy="thh-pferd-angaben-1-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 2':
    '[data-cy="thh-pferd-angaben-2-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 2':
    '[data-cy="thh-pferd-angaben-2-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 2':
    '[data-cy="thh-pferd-angaben-2-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 2':
    '[data-cy="thh-pferd-angaben-2-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 2':
    '[data-cy="thh-pferd-angaben-2-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 3':
    '[data-cy="thh-pferd-angaben-3-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 3':
    '[data-cy="thh-pferd-angaben-3-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 3':
    '[data-cy="thh-pferd-angaben-3-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 3':
    '[data-cy="thh-pferd-angaben-3-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 3':
    '[data-cy="thh-pferd-angaben-3-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 4':
    '[data-cy="thh-pferd-angaben-4-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 4':
    '[data-cy="thh-pferd-angaben-4-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 4':
    '[data-cy="thh-pferd-angaben-4-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 4':
    '[data-cy="thh-pferd-angaben-4-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 4':
    '[data-cy="thh-pferd-angaben-4-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 5':
    '[data-cy="thh-pferd-angaben-5-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 5':
    '[data-cy="thh-pferd-angaben-5-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 5':
    '[data-cy="thh-pferd-angaben-5-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 5':
    '[data-cy="thh-pferd-angaben-5-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 5':
    '[data-cy="thh-pferd-angaben-5-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 6':
    '[data-cy="thh-pferd-angaben-6-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 6':
    '[data-cy="thh-pferd-angaben-6-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 6':
    '[data-cy="thh-pferd-angaben-6-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 6':
    '[data-cy="thh-pferd-angaben-6-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 6':
    '[data-cy="thh-pferd-angaben-6-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 7':
    '[data-cy="thh-pferd-angaben-7-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 7':
    '[data-cy="thh-pferd-angaben-7-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 7':
    '[data-cy="thh-pferd-angaben-7-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 7':
    '[data-cy="thh-pferd-angaben-7-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 7':
    '[data-cy="thh-pferd-angaben-7-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 8':
    '[data-cy="thh-pferd-angaben-8-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 8':
    '[data-cy="thh-pferd-angaben-8-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 8':
    '[data-cy="thh-pferd-angaben-8-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 8':
    '[data-cy="thh-pferd-angaben-8-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 8':
    '[data-cy="thh-pferd-angaben-8-tier-kennzeichnung-input-required-error"]',
  'Checkout Pferd Kennzeichnung Radio 9':
    '[data-cy="thh-pferd-angaben-9-tier-kennzeichnung-radio"]',
  'Checkout Pferd Kennzeichnung Required Error 9':
    '[data-cy="thh-pferd-angaben-9-tier-kennzeichnung-required-error"]',
  'Checkout Pferd Kennzeichnung Input 9':
    '[data-cy="thh-pferd-angaben-9-tier-kennzeichnung-input"]',
  'Checkout Pferd Kennzeichnung Input Pattern Error 9':
    '[data-cy="thh-pferd-angaben-9-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Pferd Kennzeichnung Input Required Error 9':
    '[data-cy="thh-pferd-angaben-9-tier-kennzeichnung-input-required-error"]',

  'Checkout Hund Angaben Komponente': '[data-cy="thh-hund-angaben-komponente"]',
  'Checkout Hund Angaben Geschlecht Maennlich 0':
    '[data-cy="thh-hund-angaben-geschlecht-M-0"]',
  'Checkout Hund Angaben Geschlecht Weiblich 0':
    '[data-cy="thh-hund-angaben-geschlecht-W-0"]',
  'Checkout Hund Angaben Geschlecht Error 0':
    '[data-cy="thh-hund-angaben-geschlecht-error-0"]',
  'Checkout Hund Angaben Name with Index': (index) =>
    `[data-cy="thh-hund-angaben-name-${index}"]`,
  'Checkout Hund Angaben Name 0': '[data-cy="thh-hund-angaben-name-0"]',
  'Checkout Hund Angaben Name Pattern Error 0':
    '[data-cy="thh-hund-angaben-name-pattern-error-0"]',
  'Checkout Hund Angaben Name Required Error 0':
    '[data-cy="thh-hund-angaben-name-required-error-0"]',
  'Checkout Hund Angaben Geburtsdatum 0':
    '[data-cy="thh-hund-angaben-geburtsdatum-0"]',
  'Checkout Hund Angaben Date Pattern Error 0':
    '[data-cy="thh-hund-angaben-date-pattern-error-0"]',
  'Checkout Hund Angaben Date Required Error 0':
    '[data-cy="thh-hund-angaben-date-required-error-0"]',
  'Checkout Hund Angaben Geschlecht M with Index': (index) =>
    `[data-cy="thh-hund-angaben-geschlecht-M-${index}"]`,
  'Checkout Hund Angaben Geschlecht W with Index': (index) =>
    `[data-cy="thh-hund-angaben-geschlecht-W-${index}"]`,
  'Checkout Hund Angaben Geschlecht Maennlich 1':
    '[data-cy="thh-hund-angaben-geschlecht-M-1"]',
  'Checkout Hund Angaben Geschlecht Weiblich 1':
    '[data-cy="thh-hund-angaben-geschlecht-W-1"]',
  'Checkout Hund Angaben Geschlecht Error 1':
    '[data-cy="thh-hund-angaben-geschlecht-error-1"]',
  'Checkout Hund Angaben Name 1': '[data-cy="thh-hund-angaben-name-1"]',
  'Checkout Hund Angaben Name Pattern Error 1':
    '[data-cy="thh-hund-angaben-name-pattern-error-1"]',
  'Checkout Hund Angaben Name Required Error 1':
    '[data-cy="thh-hund-angaben-name-required-error-1"]',
  'Checkout Hund Angaben Geburtsdatum with Index': (index) =>
    `[data-cy="thh-hund-angaben-geburtsdatum-${index}"]`,
  'Checkout Hund Angaben Geburtsdatum 1':
    '[data-cy="thh-hund-angaben-geburtsdatum-1"]',
  'Checkout Hund Angaben Date Pattern Error 1':
    '[data-cy="thh-hund-angaben-date-pattern-error-1"]',
  'Checkout Hund Angaben Date Required Error 1':
    '[data-cy="thh-hund-angaben-date-required-error-1"]',
  'Checkout Hund Angaben Geschlecht Maennlich 2':
    '[data-cy="thh-hund-angaben-geschlecht-M-2"]',
  'Checkout Hund Angaben Geschlecht Weiblich 2':
    '[data-cy="thh-hund-angaben-geschlecht-W-2"]',
  'Checkout Hund Angaben Geschlecht Error 2':
    '[data-cy="thh-hund-angaben-geschlecht-error-2"]',
  'Checkout Hund Angaben Name 2': '[data-cy="thh-hund-angaben-name-2"]',
  'Checkout Hund Angaben Name Pattern Error 2':
    '[data-cy="thh-hund-angaben-name-pattern-error-2"]',
  'Checkout Hund Angaben Name Required Error 2':
    '[data-cy="thh-hund-angaben-name-required-error-2"]',
  'Checkout Hund Angaben Geburtsdatum 2':
    '[data-cy="thh-hund-angaben-geburtsdatum-2"]',
  'Checkout Hund Angaben Date Pattern Error 2':
    '[data-cy="thh-hund-angaben-date-pattern-error-2"]',
  'Checkout Hund Angaben Date Required Error 2':
    '[data-cy="thh-hund-angaben-date-required-error-2"]',
  'Checkout Hund Angaben Geschlecht Maennlich 3':
    '[data-cy="thh-hund-angaben-geschlecht-M-3"]',
  'Checkout Hund Angaben Geschlecht Weiblich 3':
    '[data-cy="thh-hund-angaben-geschlecht-W-3"]',
  'Checkout Hund Angaben Geschlecht Error 3':
    '[data-cy="thh-hund-angaben-geschlecht-error-3"]',
  'Checkout Hund Angaben Name 3': '[data-cy="thh-hund-angaben-name-3"]',
  'Checkout Hund Angaben Name Pattern Error 3':
    '[data-cy="thh-hund-angaben-name-pattern-error-3"]',
  'Checkout Hund Angaben Name Required Error 3':
    '[data-cy="thh-hund-angaben-name-required-error-3"]',
  'Checkout Hund Angaben Geburtsdatum 3':
    '[data-cy="thh-hund-angaben-geburtsdatum-3"]',
  'Checkout Hund Angaben Date Pattern Error 3':
    '[data-cy="thh-hund-angaben-date-pattern-error-3"]',
  'Checkout Hund Angaben Date Required Error 3':
    '[data-cy="thh-hund-angaben-date-required-error-3"]',
  'Checkout Hund Angaben Geschlecht Maennlich 4':
    '[data-cy="thh-hund-angaben-geschlecht-M-4"]',
  'Checkout Hund Angaben Geschlecht Weiblich 4':
    '[data-cy="thh-hund-angaben-geschlecht-W-4"]',
  'Checkout Hund Angaben Geschlecht Error 4':
    '[data-cy="thh-hund-angaben-geschlecht-error-4"]',
  'Checkout Hund Angaben Name 4': '[data-cy="thh-hund-angaben-name-4"]',
  'Checkout Hund Angaben Name Pattern Error 4':
    '[data-cy="thh-hund-angaben-name-pattern-error-4"]',
  'Checkout Hund Angaben Name Required Error 4':
    '[data-cy="thh-hund-angaben-name-required-error-4"]',
  'Checkout Hund Angaben Geburtsdatum 4':
    '[data-cy="thh-hund-angaben-geburtsdatum-4"]',
  'Checkout Hund Angaben Date Pattern Error 4':
    '[data-cy="thh-hund-angaben-date-pattern-error-4"]',
  'Checkout Hund Angaben Date Required Error 4':
    '[data-cy="thh-hund-angaben-date-required-error-4"]',
  'Checkout Hund Angaben Geschlecht Maennlich 5':
    '[data-cy="thh-hund-angaben-geschlecht-M-5"]',
  'Checkout Hund Angaben Geschlecht Weiblich 5':
    '[data-cy="thh-hund-angaben-geschlecht-W-5"]',
  'Checkout Hund Angaben Geschlecht Error 5':
    '[data-cy="thh-hund-angaben-geschlecht-error-5"]',
  'Checkout Hund Angaben Name 5': '[data-cy="thh-hund-angaben-name-5"]',
  'Checkout Hund Angaben Name Pattern Error 5':
    '[data-cy="thh-hund-angaben-name-pattern-error-5"]',
  'Checkout Hund Angaben Name Required Error 5':
    '[data-cy="thh-hund-angaben-name-required-error-5"]',
  'Checkout Hund Angaben Geburtsdatum 5':
    '[data-cy="thh-hund-angaben-geburtsdatum-5"]',
  'Checkout Hund Angaben Date Pattern Error 5':
    '[data-cy="thh-hund-angaben-date-pattern-error-5"]',
  'Checkout Hund Angaben Date Required Error 5':
    '[data-cy="thh-hund-angaben-date-required-error-5"]',
  'Checkout Hund Angaben Geschlecht Maennlich 6':
    '[data-cy="thh-hund-angaben-geschlecht-M-6"]',
  'Checkout Hund Angaben Geschlecht Weiblich 6':
    '[data-cy="thh-hund-angaben-geschlecht-W-6"]',
  'Checkout Hund Angaben Geschlecht Error 6':
    '[data-cy="thh-hund-angaben-geschlecht-error-6"]',
  'Checkout Hund Angaben Name 6': '[data-cy="thh-hund-angaben-name-6"]',
  'Checkout Hund Angaben Name Pattern Error 6':
    '[data-cy="thh-hund-angaben-name-pattern-error-6"]',
  'Checkout Hund Angaben Name Required Error 6':
    '[data-cy="thh-hund-angaben-name-required-error-6"]',
  'Checkout Hund Angaben Geburtsdatum 6':
    '[data-cy="thh-hund-angaben-geburtsdatum-6"]',
  'Checkout Hund Angaben Date Pattern Error 6':
    '[data-cy="thh-hund-angaben-date-pattern-error-6"]',
  'Checkout Hund Angaben Date Required Error 6':
    '[data-cy="thh-hund-angaben-date-required-error-6"]',
  'Checkout Hund Angaben Geschlecht Maennlich 7':
    '[data-cy="thh-hund-angaben-geschlecht-M-7"]',
  'Checkout Hund Angaben Geschlecht Weiblich 7':
    '[data-cy="thh-hund-angaben-geschlecht-W-7"]',
  'Checkout Hund Angaben Geschlecht Error 7':
    '[data-cy="thh-hund-angaben-geschlecht-error-7"]',
  'Checkout Hund Angaben Name 7': '[data-cy="thh-hund-angaben-name-7"]',
  'Checkout Hund Angaben Name Pattern Error 7':
    '[data-cy="thh-hund-angaben-name-pattern-error-7"]',
  'Checkout Hund Angaben Name Required Error 7':
    '[data-cy="thh-hund-angaben-name-required-error-7"]',
  'Checkout Hund Angaben Geburtsdatum 7':
    '[data-cy="thh-hund-angaben-geburtsdatum-7"]',
  'Checkout Hund Angaben Date Pattern Error 7':
    '[data-cy="thh-hund-angaben-date-pattern-error-7"]',
  'Checkout Hund Angaben Date Required Error 7':
    '[data-cy="thh-hund-angaben-date-required-error-7"]',
  'Checkout Hund Angaben Geschlecht Maennlich 8':
    '[data-cy="thh-hund-angaben-geschlecht-M-8"]',
  'Checkout Hund Angaben Geschlecht Weiblich 8':
    '[data-cy="thh-hund-angaben-geschlecht-W-8"]',
  'Checkout Hund Angaben Geschlecht Error 8':
    '[data-cy="thh-hund-angaben-geschlecht-error-8"]',
  'Checkout Hund Angaben Name 8': '[data-cy="thh-hund-angaben-name-8"]',
  'Checkout Hund Angaben Name Pattern Error 8':
    '[data-cy="thh-hund-angaben-name-pattern-error-8"]',
  'Checkout Hund Angaben Name Required Error 8':
    '[data-cy="thh-hund-angaben-name-required-error-8"]',
  'Checkout Hund Angaben Geburtsdatum 8':
    '[data-cy="thh-hund-angaben-geburtsdatum-8"]',
  'Checkout Hund Angaben Date Pattern Error 8':
    '[data-cy="thh-hund-angaben-date-pattern-error-8"]',
  'Checkout Hund Angaben Date Required Error 8':
    '[data-cy="thh-hund-angaben-date-required-error-8"]',
  'Checkout Hund Angaben Geschlecht Maennlich 9':
    '[data-cy="thh-hund-angaben-geschlecht-M-9"]',
  'Checkout Hund Angaben Geschlecht Weiblich 9':
    '[data-cy="thh-hund-angaben-geschlecht-W-9"]',
  'Checkout Hund Angaben Geschlecht Error 9':
    '[data-cy="thh-hund-angaben-geschlecht-error-9"]',
  'Checkout Hund Angaben Name 9': '[data-cy="thh-hund-angaben-name-9"]',
  'Checkout Hund Angaben Name Pattern Error 9':
    '[data-cy="thh-hund-angaben-name-pattern-error-9"]',
  'Checkout Hund Angaben Name Required Error 9':
    '[data-cy="thh-hund-angaben-name-required-error-9"]',
  'Checkout Hund Angaben Geburtsdatum 9':
    '[data-cy="thh-hund-angaben-geburtsdatum-9"]',
  'Checkout Hund Angaben Date Pattern Error 9':
    '[data-cy="thh-hund-angaben-date-pattern-error-9"]',
  'Checkout Hund Angaben Date Required Error 9':
    '[data-cy="thh-hund-angaben-date-required-error-9"]',

  'Checkout Hund Kennzeichnung Radio 0':
    '[data-cy="thh-hund-angaben-0-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 0':
    '[data-cy="thh-hund-angaben-0-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input with Index': (index) =>
    `[data-cy="thh-hund-angaben-${index}-tier-kennzeichnung-input"]`,
  'Checkout Hund Kennzeichnung Input 0':
    '[data-cy="thh-hund-angaben-0-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 0':
    '[data-cy="thh-hund-angaben-0-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 0':
    '[data-cy="thh-hund-angaben-0-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 1':
    '[data-cy="thh-hund-angaben-1-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 1':
    '[data-cy="thh-hund-angaben-1-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 1':
    '[data-cy="thh-hund-angaben-1-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 1':
    '[data-cy="thh-hund-angaben-1-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 1':
    '[data-cy="thh-hund-angaben-1-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 2':
    '[data-cy="thh-hund-angaben-2-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 2':
    '[data-cy="thh-hund-angaben-2-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 2':
    '[data-cy="thh-hund-angaben-2-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 2':
    '[data-cy="thh-hund-angaben-2-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 2':
    '[data-cy="thh-hund-angaben-2-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 3':
    '[data-cy="thh-hund-angaben-3-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 3':
    '[data-cy="thh-hund-angaben-3-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 3':
    '[data-cy="thh-hund-angaben-3-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 3':
    '[data-cy="thh-hund-angaben-3-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 3':
    '[data-cy="thh-hund-angaben-3-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 4':
    '[data-cy="thh-hund-angaben-4-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 4':
    '[data-cy="thh-hund-angaben-4-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 4':
    '[data-cy="thh-hund-angaben-4-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 4':
    '[data-cy="thh-hund-angaben-4-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 4':
    '[data-cy="thh-hund-angaben-4-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 5':
    '[data-cy="thh-hund-angaben-5-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 5':
    '[data-cy="thh-hund-angaben-5-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 5':
    '[data-cy="thh-hund-angaben-5-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 5':
    '[data-cy="thh-hund-angaben-5-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 5':
    '[data-cy="thh-hund-angaben-5-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 6':
    '[data-cy="thh-hund-angaben-6-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 6':
    '[data-cy="thh-hund-angaben-6-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 6':
    '[data-cy="thh-hund-angaben-6-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 6':
    '[data-cy="thh-hund-angaben-6-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 6':
    '[data-cy="thh-hund-angaben-6-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 7':
    '[data-cy="thh-hund-angaben-7-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 7':
    '[data-cy="thh-hund-angaben-7-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 7':
    '[data-cy="thh-hund-angaben-7-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 7':
    '[data-cy="thh-hund-angaben-7-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 7':
    '[data-cy="thh-hund-angaben-7-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 8':
    '[data-cy="thh-hund-angaben-8-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 8':
    '[data-cy="thh-hund-angaben-8-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 8':
    '[data-cy="thh-hund-angaben-8-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 8':
    '[data-cy="thh-hund-angaben-8-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 8':
    '[data-cy="thh-hund-angaben-8-tier-kennzeichnung-input-required-error"]',
  'Checkout Hund Kennzeichnung Radio 9':
    '[data-cy="thh-hund-angaben-9-tier-kennzeichnung-radio"]',
  'Checkout Hund Kennzeichnung Required Error 9':
    '[data-cy="thh-hund-angaben-9-tier-kennzeichnung-required-error"]',
  'Checkout Hund Kennzeichnung Input 9':
    '[data-cy="thh-hund-angaben-9-tier-kennzeichnung-input"]',
  'Checkout Hund Kennzeichnung Input Pattern Error 9':
    '[data-cy="thh-hund-angaben-9-tier-kennzeichnung-input-pattern-error"]',
  'Checkout Hund Kennzeichnung Input Required Error 9':
    '[data-cy="thh-hund-angaben-9-tier-kennzeichnung-input-required-error"]',

  'Checkout Hund Meldebehoerde': '[data-cy="checkout-meldebehoerde"]',
  'Checkout Hund MeldebehoerdeVorhanden Titel':
    '[data-cy="checkout-meldebehoerde-vorhanden-title"]',
  'Checkout Hund Meldebehoerde Name': '[data-cy="checkout-nameMeldebehoerde"]',
  'Checkout Hund Meldebehoerde Name Pattern Error':
    '[data-cy="thh-meldebehoerde-name-pattern-error"]',
  'Checkout Hund Meldebehoerde Name Required Error':
    '[data-cy="thh-meldebehoerde-name-required-error"]',
  'Checkout Hund Meldebehoerde Aktenzeichen':
    '[data-cy="checkout-meldebehoerdeAktenzeichen"]',
  'Checkout Hund Meldebehoerde Aktenzeichen Pattern Error':
    '[data-cy="thh-meldebehoerde-aktenzeichen-pattern-error"]',
  'Checkout Hund Meldebehoerde Aktenzeichen Required Error':
    '[data-cy="thh-meldebehoerde-aktenzeichen-required-error"]',
  'Checkout Hund Meldebehoerde Aktenzeichen Vorhanden':
    '[data-cy="checkout-meldebehoerdeAktZeichen-Vorhanden"]',
  'Checkout Hund Meldebehoerde Aktenzeichen Input':
    '[data-cy="checkout-meldebehoerdeAktenzeichen"]',
  'Checkout Hund Meldebehoerde Plz': '[data-cy="checkout-meldebehoerdePlz"]',
  'Checkout Hund Meldebehoerde Ort Vorschlag':
    '[data-cy="checkout-meldebehoerdeOrt"]',
  'Checkout Hund Meldebehoerde Ort Dropdown': '[id="meldebehoerdeOrtDropdown"]',
  'Checkout Hund Meldebehoerde Strasse Dropdown':
    '[data-cy="checkout-meldebehoerdeStrasse"]',
  'Checkout Hund Meldebehoerde Strasse Dropdown - First Item':
    '[data-cy="checkout-meldebehoerdeStrasse-items-0"]',
  'Checkout Hund Meldebehoerde Strasse Required Error':
    '[data-cy="checkout-meldebehoerde-strasse-error"]',
  'Checkout Hund Meldebehoerde Hausnummer':
    '[data-cy="checkout-meldebehoerde-hausnummer-input"]',
  'Checkout Hund Meldebehoerde Hausnummer Required Error':
    '[data-cy="checkout-meldebehoerdeHausnummer-required-error"]',
  'Checkout Hund Meldebehoerde Hausnummer Pattern Error':
    '[data-cy="checkout-meldebehoerdeHausnummer-pattern-error"]',
  'Checkout Hund Meldebehoerde SicherungsbestatigungsDatum':
    '[data-cy="checkout-SicherungsbestatigungsDatum-input"]',
  'Checkout Hund Meldebehoerde Falsch-Beginndatum':
    '[data-cy="checkout-SicherungsbestatigungsDatum-error_min"]',

  'Checkout TKV Angaben': `[data-cy="checkout-tkv-angaben"]`,
  'Checkout TKV Angaben Tiername': `[data-cy="checkout-tkv-angaben-name-0"]`,
  'Checkout TKV Angaben Tiername Error': `[data-cy="checkout-tkv-angaben-name-0-error"]`,
  'Checkout TKV Angaben Einsatzgebiet': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 0': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-0"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 1': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-1"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 2': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-2"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 3': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-3"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 4': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-4"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 5': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-5"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 6': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-6"]`,
  'Checkout TKV Angaben Einsatzgebiet Item 7': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-7"]`,
  'Checkout TKV Angaben Einsatzgebiet Error': `[data-cy="checkout-tkv-angaben-einsatzgebiet-0-error"]`,
  'Checkout TKV Angaben Kennzeichnungsart': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio"]`,
  'Checkout TKV Angaben Kennzeichnungsart Input': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio"] input`,
  'Checkout TKV Angaben Kennzeichnungsart Item Keine': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio-keine"]`,
  'Checkout TKV Angaben Kennzeichnungsart Item Chip': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio-chip"]`,
  'Checkout TKV Angaben Kennzeichnungsart Item Taetowierung': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio-taetowierung"]`,
  'Checkout TKV Angaben Kennzeichnungsart Item Lebensnummer': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio-lebensnummer"]`,
  'Checkout TKV Angaben Kennzeichnungsart Error': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-required-error"]`,
  'Checkout TKV Angaben Kennzeichnung': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-input"]`,
  'Checkout TKV Angaben Kennzeichnung with Index': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-input"]`,
  'Checkout TKV Angaben Kennzeichnung Pattern Error': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-input-pattern-error"]`,
  'Checkout TKV Angaben Kennzeichnung Required Error': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-input-required-error"]`,
  'Checkout TKV Angaben Tierarzt': `[data-cy="tkv-tierarztbesucht-radio-group-0"]`,
  'Checkout TKV Angaben Tierarzt Ja': `[data-cy="tkv-tierarztbesucht-radio-group-0-ja"]`,
  'Checkout TKV Angaben Tierarzt Nein': `[data-cy="tkv-tierarztbesucht-radio-group-0-nein"]`,
  'Checkout TKV Angaben Diagnose Item 0': `[data-cy="tkv-diagnose-angaben-0-0"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Dropdown': `[data-cy="tkv-diagnose-list-dropdown-0-0"]`,
  'Checkout TKV Angaben Diagnose Item 1 Diagnose Dropdown': `[data-cy="tkv-diagnose-list-dropdown-0-1"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Dropdown Element 0': `[data-cy="tkv-diagnose-list-dropdown-0-0-element-0"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Dropdown Element 1': `[data-cy="tkv-diagnose-list-dropdown-0-0-element-1"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Dropdown Beschreibung': `[data-cy="tkv-diagnose-beschreibung-0-0"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Details Dropdown': `[data-cy="tkv-diagnose-details-list-dropdown-0-0"]`,
  'Checkout TKV Angaben Diagnose Item 0 Diagnose Details Dropdown Element 0': `[data-cy="tkv-diagnose-details-list-dropdown-0-0-element-0"]`,
  'Checkout TKV Angaben Diagnose Item 1': `[data-cy="tkv-diagnose-angaben-0-1"]`,
  'Checkout TKV Angaben Diagnose Item 1 Delete': `[data-cy="tkv-diagnose-angaben-delete-0-1"]`,
  'Checkout TKV Angaben Diagnose Item 2': `[data-cy="tkv-diagnose-angaben-0-2"]`,
  'Checkout TKV Angaben Diagnose Item 2 Delete': `[data-cy="tkv-diagnose-angaben-delete-0-2"]`,
  'Checkout TKV Angaben Diagnose Hinzufuegen': `[data-cy="tkv-diagnose-angaben-add-0"]`,
  'Checkout TKV Angaben Hinweis': ` [data-cy="tkv-hinweis-zum-vertrag"]`,

  'Checkout TKV Angaben with Index Tiername': (index) =>
    `[data-cy="checkout-tkv-angaben-name-${index}"]`,
  'Checkout TKV Angaben with Index Tiername Error': (index) =>
    `[data-cy="checkout-tkv-angaben-name-${index}-error"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 0': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-0"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 1': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-1"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 2': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-2"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 3': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-3"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 4': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-4"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 5': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-5"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 6': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-6"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Item 7': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-7"]`,
  'Checkout TKV Angaben with Index Einsatzgebiet Error': (index) =>
    `[data-cy="checkout-tkv-angaben-einsatzgebiet-${index}-error"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-radio"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart Item Keine': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-radio-keine"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart Item Chip': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-radio-chip"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart Item Taetowierung': (
    index
  ) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-radio-taetowierung"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart Item Lebensnummer': (
    index
  ) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-radio-lebensnummer"]`,
  'Checkout TKV Angaben with Index Kennzeichnungsart Error': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-required-error"]`,
  'Checkout TKV Angaben with Index Kennzeichnung': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-input"]`,
  'Checkout TKV Angaben with Index Kennzeichnung Pattern Error': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-input-pattern-error"]`,
  'Checkout TKV Angaben with Index Kennzeichnung Required Error': (index) =>
    `[data-cy="checkout-tkv-angaben-${index}-kennzeichnung-input-required-error"]`,
  'Checkout TKV Angaben with Index Tierarzt': (index) =>
    `[data-cy="tkv-tierarztbesucht-radio-group-${index}"]`,
  'Checkout TKV Angaben with Index Tierarzt Ja': (index) =>
    `[data-cy="tkv-tierarztbesucht-radio-group-${index}-ja"]`,
  'Checkout TKV Angaben with Index Tierarzt Nein': (index) =>
    `[data-cy="tkv-tierarztbesucht-radio-group-${index}-nein"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0': (index) =>
    `[data-cy="tkv-diagnose-angaben-${index}-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Element 0':
    (index) => `[data-cy="tkv-diagnose-list-dropdown-${index}-0-element-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Element 1':
    (index) => `[data-cy="tkv-diagnose-list-dropdown-${index}-0-element-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Error': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-0-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Beschreibung':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Beschreibung Pattern Error':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-0-error-pattern"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Dropdown Beschreibung Required Error':
    (index) =>
      `[data-cy="tkv-diagnose-beschreibung-${index}-0-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Details Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-details-list-dropdown-${index}-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Details Dropdown Error':
    (index) =>
      `[data-cy="tkv-diagnose-details-list-dropdown-${index}-0-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 0 Diagnose Details Dropdown Element 0':
    (index) =>
      `[data-cy="tkv-diagnose-details-list-dropdown-${index}-0-element-0"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1': (index) =>
    `[data-cy="tkv-diagnose-angaben-${index}-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Dropdown Error': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-1-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Dropdown Beschreibung':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Dropdown Beschreibung Pattern Error':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-1-error-pattern"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Dropdown Beschreibung Required Error':
    (index) =>
      `[data-cy="tkv-diagnose-beschreibung-${index}-1-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Details Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-details-list-dropdown-${index}-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Diagnose Details Dropdown Error':
    (index) =>
      `[data-cy="tkv-diagnose-details-list-dropdown-${index}-1-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 1 Delete': (index) =>
    `[data-cy="tkv-diagnose-angaben-delete-${index}-1"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2': (index) =>
    `[data-cy="tkv-diagnose-angaben-${index}-2"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-2"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Dropdown Error': (
    index
  ) => `[data-cy="tkv-diagnose-list-dropdown-${index}-2-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Dropdown Beschreibung':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-2"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Dropdown Beschreibung Pattern Error':
    (index) => `[data-cy="tkv-diagnose-beschreibung-${index}-2-error-pattern"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Dropdown Beschreibung Required Error':
    (index) =>
      `[data-cy="tkv-diagnose-beschreibung-${index}-2-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Details Dropdown': (
    index
  ) => `[data-cy="tkv-diagnose-details-list-dropdown-${index}-2"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Diagnose Details Dropdown Error':
    (index) =>
      `[data-cy="tkv-diagnose-details-list-dropdown-${index}-2-error-required"]`,
  'Checkout TKV Angaben with Index Diagnose Item 2 Delete': (index) =>
    `[data-cy="tkv-diagnose-angaben-delete-${index}-2"]`,
  'Checkout TKV Angaben with Index Diagnose Hinzufuegen': (index) =>
    `[data-cy="tkv-diagnose-angaben-add-${index}"]`,

  'Checkout Vermittler': `[data-cy="checkout-vermittlerdaten"]`,
  'Checkout Vermittler Eigen Radio': `[data-cy="checkout-vermittler-radio-eigen"]`,
  'Checkout Vermittler Fremd Radio': `[data-cy="checkout-vermittler-radio-fremd"]`,
  'Checkout Vermittler Nummer Dropdown': `[data-cy="checkout-vermittler-nummer-dropdown"]`,
  'Checkout Vermittler Bnrb Dropdown': `[data-cy="checkout-vermittler-bnrb-dropdown"]`,
  'Checkout Vermittler Fremd Nummer Input': `[data-cy="checkout-vermittler-fremd-nummer"]`,
  'Checkout Vermittler Fremd Nummer Input Error': `[data-cy="checkout-vermittler-fremd-nummer-error"]`,
  'Checkout Vermittler Fremd Bnrb Input': `[data-cy="checkout-vermittler-fremd-bnrb"]`,
  'Checkout Vermittler Fremd Fremdordnungsmerkmal': `[data-cy="checkout-vermittler-fremd-fom"]`,
  'Checkout Vermittler Fremd Fremdordnungsmerkmal Info': `[data-cy="checkout-vermittler-fom-info"]`,
  'Checkout Vermittler Fremd Fremdordnungsmerkmal Error': `[data-cy="checkout-vermittler-fom-error"]`,

  'Checkout Zahlung': `[data-cy="checkout-zahlung"]`,
  'Checkout Zahlung Kontoinhaber Vorname': `[data-cy="checkout-zahlung-kontoinhaber-vorname"]`,
  'Checkout Zahlung Kontoinhaber Nachname': `[data-cy="checkout-zahlung-kontoinhaber-nachname"]`,
  'Checkout Zahlung Kontoinhaber aendern': `[data-cy="checkout-zahlung-kontoinhaber-aendern"]`,
  'Checkout Zahlung Bankverbindungen Radio': `[data-cy="checkout-zahlung-radio-bankverbindungen"]`,
  'Checkout Zahlung Iban': `[data-cy="checkout-zahlung-iban"]`,
  'Checkout Zahlung Bic': `[data-cy="checkout-zahlung-bic"]`,
  'Checkout Zahlung Bankname': `[data-cy="checkout-zahlung-bankname"]`,
  'Personensuche Modal': `[data-cy="search-dialog-modal"]`,
  'Personensuche Modal Cisl': `[data-cy="search-dialog-modal-cisl"]`,
  'Personensuche Suchfeld': `[data-cy="search-dialog-search-field"]`,
  'Personensuche Suchen': `[data-cy="search-dialog-search-button"]`,
  'Personensuche Auswaehlen': `[data-cy="search-dialog-confirm-button"]`,
  'Personensuche CISL Vorname': `[data-cy="exaktSearchType-vorname"]`,
  'Personensuche CISL Nachname': `[data-cy="exaktSearchType-nachname"]`,
  'Personensuche CISL Radio Freitext': `[data-cy="cislSearchType-freitext"]`,
  'Personensuche CISL Radio exakter Name': `[data-cy="cislSearchType-exakt"]`,
  'Personensuche Tabelle': `[data-cy="search-dialog-table"]`,
  'Personensuche Ergebnisse': `[data-cy="search-dialog-table-body"]`,
  'Checkout Zahlung Unvollstaendige Daten Info': `[data-cy="checkout-zahlung-unvollstaendige-daten-info"]`,
  'Checkout Zahlung Invalid Adresse Info': `[data-cy="checkout-zahlung-invalid-adresse-info"]`,

  'Checkout Zahlung AZAM Modal': `[data-cy="checkout-abweichenderKontoinhaber-azam-modal"]`,
  'Checkout Zahlung AZAM Modal Error': `[data-cy="checkout-abweichenderKontoinhaber-azam-modal-error"]`,
  'Checkout Zahlung AZAM Modal Vorname': `[data-cy="checkout-abweichenderKontoinhaber-azam-vorname-input"]`,
  'Checkout Zahlung AZAM Modal Vorname Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-vorname-error-required"]`,
  'Checkout Zahlung AZAM Modal Vorname Error Pattern': `[data-cy="checkout-abweichenderKontoinhaber-azam-vorname-error-pattern"]`,

  'Checkout Zahlung AZAM Modal Nachname': `[data-cy="checkout-abweichenderKontoinhaber-azam-nachname-input"]`,
  'Checkout Zahlung AZAM Modal Nachname Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-nachname-error-required"]`,
  'Checkout Zahlung AZAM Modal Nachname Error Pattern': `[data-cy="checkout-abweichenderKontoinhaber-azam-nachname-error-pattern"]`,

  'Checkout Zahlung AZAM Modal Geburtsdatum': `[data-cy="checkout-abweichenderKontoinhaber-azam-geburtsdatum-input"]`,
  'Checkout Zahlung AZAM Modal Geburtsdatum Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-geburtsdatum-error-required"]`,
  'Checkout Zahlung AZAM Modal Geburtsdatum Error Not Of Age': `[data-cy="checkout-abweichenderKontoinhaber-azam-geburtsdatum-error-notOfAge"]`,
  'Checkout Zahlung AZAM Modal Geburtsdatum Error Invalid': `[data-cy="checkout-abweichenderKontoinhaber-azam-geburtsdatum-error-invalid"]`,

  'Checkout Zahlung AZAM Modal Staatsbschaft Dropdown': `[data-cy="checkout-abweichenderKontoinhaber-azam-staatsbschaft-dropdown"]`,
  'Checkout Zahlung AZAM Modal Staatsbschaft Dropdown Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-staatsbschaft-error-required"]`,

  'Checkout Zahlung AZAM Modal PLZ': `[data-cy="checkout-abweichenderKontoinhaber-azam-plz-input"]`,
  'Checkout Zahlung AZAM Modal PLZ Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-plz-error-required"]`,
  'Checkout Zahlung AZAM Modal PLZ Error Pattern': `[data-cy="checkout-abweichenderKontoinhaber-azam-plz-error-pattern"]`,

  'Checkout Zahlung AZAM Modal Ort': `[data-cy="checkout-abweichenderKontoinhaber-azam-ort-input"]`,
  'Checkout Zahlung AZAM Modal Orte Dropdown': `[data-cy="checkout-abweichenderKontoinhaber-azam-ort-dropdown"]`,
  'Checkout Zahlung AZAM Modal Orte Dropdown Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-ort-dropdown-error-required"]`,

  'Checkout Zahlung AZAM Modal Strasse Dropdown': `[data-cy="checkout-abweichenderKontoinhaber-azam-strasse-dropdown"]`,
  'Checkout Zahlung AZAM Modal Strasse Dropdown Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-strasse-error-required"]`,

  'Checkout Zahlung AZAM Modal Hausnummer': `[data-cy="checkout-abweichenderKontoinhaber-azam-hausnummer-input"]`,
  'Checkout Zahlung AZAM Modal Hausnummer Error Required': `[data-cy="checkout-abweichenderKontoinhaber-azam-hausnummer-error-required"]`,
  'Checkout Zahlung AZAM Modal Hausnummer Error Pattern': `[data-cy="checkout-abweichenderKontoinhaber-azam-hausnummer-error-pattern"]`,

  'Checkout Abschluss': `[data-cy="checkout-abschluss"]`,
  'Checkout Beratung': `[data-cy="checkout-beratung"]`,
  'Checkout Beratung Name': `[data-cy="checkout-beratung-beratername"]`,
  'Checkout Beratung Datum': `[data-cy="checkout-beratung-beratungsdatum"]`,
  'Checkout Beratung Zielmarkt Radio': `[data-cy="checkout-beratung-zielmarkt-radio"]`,
  'Checkout Beratung Zielmarkt Checkbox': `[data-cy="checkout-beratung-zielmarkt-checkbox"]`,
  'Checkout Beratung Zielmarkt Checkbox Error': `[data-cy="checkout-beratung-zielmarkt-checkbox-error"]`,
  'Checkout Beratung Zielmarkt Begruendung VHV': `[data-cy="checkout-beratung-zielmarkt-begruendung-vhv-angebot"]`,
  'Checkout Beratung Zielmarkt Begruendung TKV': `[data-cy="checkout-beratung-zielmarkt-begruendung-tkv-angebot"]`,
  'Checkout Beratung Zielmarkt Begruendung VWG': `[data-cy="checkout-beratung-zielmarkt-begruendung-vwg-angebot"]`,
  'Checkout Error uebepruefen Link': `[data-cy="errors_ueberpruefen_link"]`,
  'Checkout Beratung Zielmarkt Begruendung with Index': (index) =>
    `[data-cy="checkout-beratung-zielmarkt-begruendung-vwg-angebot${index}"]`,
  'Checkout Beratung Zielmarkt Begruendung TKV with Index': (index) =>
    `[data-cy="checkout-beratung-zielmarkt-begruendung-tkv-angebot${index}"]`,
  'Checkout Beratung Zielmarkt Begruendung THH_HUND': `[data-cy="checkout-beratung-zielmarkt-begruendung-thh-hund-angebot"]`,
  'Checkout Beratung Zielmarkt Begruendung THH_PFERD': `[data-cy="checkout-beratung-zielmarkt-begruendung-thh-pferd-angebot"]`,
  'Checkout Beratung Zielmarkt Begruendung Error': `[data-cy="checkout-beratung-zielmarkt-begruendung-error"]`,
  'Checkout Beratung Zielmarkt Begruendung Pattern': `[data-cy="checkout-beratung-zielmarkt-pattern-error"]`,
  'Checkout Beratung Zielmarkt Error Required': `[data-cy="checkout-beratung-zielmarkt-error-required"]`,
  'Checkout Beratung Besonderheiten Checkbox': `[data-cy="checkout-beratung-checkbox-besonderheiten"]`,
  'Checkout Beratung Besonderheiten Input': `[data-cy="checkout-beratung-input-besonderheiten"]`,
  'Checkout Beratung Besonderheiten Error Required': `[data-cy="checkout-besonderheiten-error-required"]`,
  'Checkout Beratung Besonderheiten Error Pattern': `[data-cy="checkout-besonderheiten-error-pattern"]`,
  'Checkout Beratung Besonderheiten Error Length': `[data-cy="checkout-besonderheiten-error-length"]`,
  'Checkout Beratung Assekuranztarif Checkbox': `[data-cy="checkout-beratung-checkbox-assekuranztarif"]`,
  'Checkout Beratung Assekuranztarif Error': `[data-cy="checkout-beratung-assekuranztarif-error"]`,
  'Checkout Beratung Assekuranztarif Message': `#assekuranztariffhinweis`,
  'Checkout Beratung Extremwetterschutz Section': `[data-cy="checkout-beratung-extremwetterschutz"]`,
  'Checkout VHV Wertsachen Nein Radio': `#wertsachen_nein-label`,

  'Checkout Antrag': `[data-cy="checkout-antrag"]`,
  'Checkout Antrag Antragsnummer': `[data-cy="checkout-antragsnummer"]`,
  'Checkout Antrag Download Pdf PKB': `[data-cy="download-pdf-pkb"]`,
  'Checkout Antrag Download Pdf Icon Success PKB': `[data-cy="pdf-pkb-success-icon"]`,
  'Checkout Antrag Spinner Pdf PKB': `[data-cy="download-spinner-pkb"]`,
  'Checkout Einreichen Waiting Overlay': `[data-cy="einreichen-waiting-overlay"]`,

  'Checkout Error Message': `[data-cy="common-error-message"]`,
  'Checkout Druck Error': `[data-cy="druck-error-message"]`,

  'Checkout Telefonverkauf Datum Input': `[data-cy="checkout-telefonverkauf-datum"]`,
  'Checkout Telefonverkauf Uhrzeit': `[data-cy="checkout-telefonverkauf-timefield-input"]`,
  'Checkout Telefonverkauf Vorname': `[id="vornameGespraechspartner"]`,
  'Checkout Telefonverkauf Nachname': `[id="nachnameGespraechspartner"]`,
  'Checkout Telefonverkauf Versandart Dropdown': `[id="versandArtAVB"]`,
  'Checkout Telefonverkauf Info Box': `[id="telefonverkaufInfoBox"]`,

  'Checkout Vertragsschlussverfahren Dropdown': `[data-cy="checkout-vertragsschlussverfahren-dropdown"]`,
  'Checkout Dankeseite PKB Icon Success': `#pdf-pkb-download-success-icon`,

  'Checkout Einreichen eSign Button': `[data-cy="checkout-einreichen-esign-button"]`,
  'Checkout Einreichen Button ohne eSign': `[data-cy="checkout-einreichen-button-ohne-esign"]`,
  'Checkout ErklaerVideo Checkbox': `[data-cy="checkout-erklaerVideo-checkbox"]`,
  'Checkout ErklaerVideo Info Icon': `[data-cy="erklaerVideoInfo"]`,
  'Checkout Info Icon Modal': `[data-cy="icon-info-modal"]`,
  'Checkout Info Icon Popover text': `[data-cy="info-icon-popover-text"]`,

  'Checkout Maklermandat Radio': `[data-cy="checkout-maklermandat-radio"]`,
  'Checkout Maklermandat Radio Error': `[data-cy="checkout-maklermandat-radio-error"]`,
  'Checkout EMail Radio Angabe': `[data-cy="checkout-radios-email-angabe"]`,
  'Checkout TKV angaben Kennzeichungn Radio': `[data-cy="checkout-tkv-angaben-0-kennzeichnung-radio"]`,
  'Checkout Mobil Radio Angabe': `[data-cy="checkout-radios-mobil-angabe"]`,
  'Checkout Vermittlernummer Input': `[data-cy="checkout-vermittler-nummer-input-azam"]`,
  'Checkout Bnrb Input': `[data-cy="checkout-vermittler-bnrb-azam"]`,

  'Checkout VN Wechsel Grund Versicherungsnehmer': (index) =>
    `[data-cy="checkout-vnWechselGrund-versicherungsnehmer-0-${index}"]`,
  'Checkout VN Wechsel Grund Vorvertrag': (index) =>
    `[data-cy="checkout-vnWechselGrund-vorvertrag-0-${index}"]`,
  'Checkout VN Wechsel Grund Dropdown': (index) =>
    `[data-cy="checkout-vnWechselGrund-dropdown-0-${index}"]`,
  'Checkout VN Wechsel Grund Required Error': (index) =>
    `[data-cy="checkout-vnWechselGrund-required-error-${index}"]`,

  'Checkout Police Versandart': '[data-cy="checkout-police-versandart"]',
  'Checkout Police Versandart Dropdown':
    '[data-cy="police-versandArt-dropdown"]',
  'Checkout Police Versandart Hinweis': '[data-cy="police-versandArt-hinweis"]',
  'Checkout Police Versandart E-Mail Warnung':
    '[data-cy="police-versandArt-email-warning"]',
  'Checkout Police Versandart E-Mail Info':
    '[data-cy="police-versandArt-email-info"]',

  'Checkout VN Email Info Icon':
    '[data-cy="versicherungsnehmer-email-info-icon"]',

  'Checkout JHP Beginn Ablauf': 'div[data-cy="beginn-und-ablauf-kachel-jhp"]',
  'Checkout BA Kachel Beginn JHP': `[data-cy*="beginn-und-ablauf-beginn-jhp"]`,
  'Checkout BA Kachel Ablauf JHP': `[data-cy="beginn-und-ablauf-ablauf-jhp"]`,
  'Checkout JHP Beginn Info-Icon Button': '[data-cy="beginn-ablauf-datum-info-icon-jhp"]',
  'Checkout Beginn Info-Icon Button': '[data-cy="icon-info-popover"]',
  'Checkout close modal Button': '[data-cy= "icon-info-modal"]',
  'Checkout Error stoerer Bestaetigt JHP': '[data-cy*="stoererBestaetigt_jhp_0_Error"]',
  'Checkout stoerer Bestaetigt JHP checkbox': '[data-cy="stoererBestaetigt_jhp_0_checkbox"]',
  'Checkout BA Vorversicherung DropDown Sparte JHP': `[data-cy*="checkout-vorversicherungAngaben-jhp-versicherungDropdown-0"]`,
  'Checkout BA Vorversicherung VersicherungsNr JHP': `[data-cy="checkout-vorversicherungAngaben-jhp-vsnrInput-0"]`,
  'Checkout BA Vorversicherung Sparte JHP': `[data-cy*="checkout-vorversicherung-sparte-jhp-angebot"]`,
  'Checkout JHP Angaben': `[data-cy*="checkout-jagdAngaben"]`,
  'Checkout JHP Jagdbehoerde': `[data-cy*="checkout-jagdbehoerde"]`,
  'Checkout JHP Jagdschein Text': `[data-cy*="checkout-jagdschein-laufzeit-text"]`,
  'Checkout JHP Jagdschein Radio': `[data-cy*="checkout-jagdschein-radio"]`,
  'Checkout JHP Disabled Drei Jahres Jagdschein Radio': `[data-cy*="checkout-drei-jahres-jagdschein-disabled"]`,
  'Checkout JHP Jagdbehoerde Name': `[data-cy*="checkout-nameJagdbehoerde"]`,
  'Checkout JHP Jagdbehoerde Name Required': `[data-cy*="jhp-jagdbehoerde-name-required-error"]`,
  'Checkout JHP Jagdbehoerde PLZ': `[data-cy*="checkout-jagdbehoerdePlz"]`,
  'Checkout JHP Jagdbehoerde PLZ Required': `[data-cy*="jhp-jagdbehoerde-plz-required-error"]`,
  'Checkout JHP Jagdbehoerde Hausnummer Required': `[data-cy*="checkout-jagdbehoerde-hausnummer-required-error"]`,
  'Checkout JHP Jagdbehoerde Ort': `[data-cy*="checkout-jagdbehoerdeOrt"]`,
  'Checkout JHP Jagdbehoerde Strasse Dropdown': `[data-cy*="checkout-jagdbehoerdeStrasse"]`,
  'Checkout JHP Jagdbehoerde Strasse Required': `[data-cy*="checkout-jagdbehoerde-strasse-error"]`,
  'Checkout JHP Jagdbehoerde Hausnummer': `[data-cy*="checkout-jagdbehoerde-hausnummer-input"]`,
  'Checkout BA Kachel Beginn Unfallversicherung': `[data-cy="beginn-und-ablauf-beginn-unf"]`,

  'Checkout GEGE Angebot 1 Gegenstand 1 Modell': `[data-cy="checkout-gege-modell-0-0"]`,
  'Checkout GEGE Angebot 1 Gegenstand 1 Informationen': `[data-cy="checkout-gege-informationen-0-0"]`,
  'Checkout GEGE Angebot 1 Gegenstand 2 Modell': `[data-cy="checkout-gege-modell-0-1"]`,
  'Checkout GEGE Angebot 1 Gegenstand 2 Informationen': `[data-cy="checkout-gege-informationen-0-1"]`,
  'Checkout GEGE Angebot 1 Gegenstand 3 Modell': `[data-cy="checkout-gege-modell-0-2"]`,
  'Checkout GEGE Angebot 1 Gegenstand 3 Informationen': `[data-cy="checkout-gege-informationen-0-2"]`,
  'Checkout GEGE Angebot 1 Gegenstand 4 Modell': `[data-cy="checkout-gege-modell-0-3"]`,
  'Checkout GEGE Angebot 1 Gegenstand 4 Informationen': `[data-cy="checkout-gege-informationen-0-3"]`,
  'Checkout GEGE Angebot 1 Gegenstand 5 Modell': `[data-cy="checkout-gege-modell-0-4"]`,
  'Checkout GEGE Angebot 1 Gegenstand 5 Informationen': `[data-cy="checkout-gege-informationen-0-4"]`,
  'Checkout GEGE Angebot 1 Gegenstand 6 Modell': `[data-cy="checkout-gege-modell-0-5"]`,
  'Checkout GEGE Angebot 1 Gegenstand 6 Informationen': `[data-cy="checkout-gege-informationen-0-5"]`,
  'Checkout GEGE Angebot 1 Gegenstand 7 Modell': `[data-cy="checkout-gege-modell-0-6"]`,
  'Checkout GEGE Angebot 1 Gegenstand 7 Informationen': `[data-cy="checkout-gege-informationen-0-6"]`,
  'Checkout GEGE Angebot 1 Gegenstand 8 Modell': `[data-cy="checkout-gege-modell-0-7"]`,
  'Checkout GEGE Angebot 1 Gegenstand 8 Informationen': `[data-cy="checkout-gege-informationen-0-7"]`,
  'Checkout GEGE Angebot 1 Gegenstand 9 Modell': `[data-cy="checkout-gege-modell-0-8"]`,
  'Checkout GEGE Angebot 1 Gegenstand 9 Informationen': `[data-cy="checkout-gege-informationen-0-8"]`,
  'Checkout GEGE Angebot 1 Gegenstand 10 Modell': `[data-cy="checkout-gege-modell-0-9"]`,
  'Checkout GEGE Angebot 1 Gegenstand 10 Informationen': `[data-cy="checkout-gege-informationen-0-9"]`,

  'Checkout GEGE Checkbox ausschluss': `[data-cy="checkout-gege-angaben-ausschluss-checkbox"]`,
  'Checkout GEGE Modell required error': `[data-cy="checkout-gege-modell-error"]`,
  'Checkout GEGE Informationen required error': `[data-cy="checkout-gege-informationen-error"]`,

  'Checkout Beginn Ablauf Kachel Unfall': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-unf"]',
  'Checkout Beginn Ablauf Beginndatum Unfall': '[data-cy="beginn-und-ablauf-beginn-unf"]',
  'Checkout Beginn Ablauf Laufzeit Unfall': '[data-cy="beginn-und-ablauf-laufzeit-unf"]',

  'Checkout Beginn Ablauf Kachel Unfall Hinweis Close':
    'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-unf"] nx-message button',

  'Checkout Beginn Ablauf Kachel Unfall 0': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-unf0"]',
  'Checkout Beginn Ablauf Unfallprodukt 0': '[id="produktname-unf0"]',
  'Checkout Beginn Ablauf Beginndatum Unfall 0': '[data-cy="beginn-und-ablauf-beginn-unf0"]',
  'Checkout Beginn Ablauf Laufzeit Unfall 0': '[data-cy="beginn-und-ablauf-laufzeit-unf0"]',

  'Checkout Beginn Ablauf Kachel Unfall 1': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-unf1"]',
  'Checkout Beginn Ablauf Unfallprodukt 1': '[id="produktname-unf1"]',
  'Checkout Beginn Ablauf Unfall Beginndatum 1': '[data-cy="beginn-und-ablauf-beginn-unf1"]',
  'Checkout Beginn Ablauf Unfall Laufzeit 1': '[data-cy="beginn-und-ablauf-laufzeit-unf1"]',

  'Checkout Unfall Dynamik RadioGroup 0': '[id="dynamikRadioGroup-0"]',

  'Checkout Unfall Bezugsrecht Dropdown': '[name="bezugsrechtDropdown"]',
  'Checkout Unfall Bezugsrecht Dropdown Item namentlich': 'nx-dropdown-item:contains("namentliches Bezugsrecht")',
  'Checkout Unfall Bezugsrecht Dropdown Item namentliches Bezugsrecht': 'nx-dropdown-item:contains("namentliches Bezugsrecht")',

  'CHeckout Unfall Gesundheitserklaerung': 'checkout-unf-gesundheitserklaerung',
  'Checkout Unfall Einwilligung Checkbox': '[id="gesundheitserklaerungUnfall"]',
  'Checkout Unfall Einwilligung Required': '[data-cy="checkout-unfangaben-gesundheit-error"]',
  'Checkout Unfall Pflegefrage Radiogroup 0': '[id="pflegeFrageRadioGroup-0"]',
  'Checkout Unfall Pflegefrage Radiogroup 1': '[id="pflegeFrageRadioGroup-1"]',

  'Checkout Beginn Ablauf Kachel GeGe': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-gege"]',
  'Checkout Beginn Ablauf Beginndatum GeGe': '[data-cy="beginn-und-ablauf-beginn-gege"]',
  'Checkout Beginn Ablauf Laufzeit GeGe': '[data-cy="beginn-und-ablauf-laufzeit-gege"]',

  'Checkout Beginn Ablauf Kachel GeGe Hinweis Close': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-gege"] nx-message button',

  'Checkout Beginn Ablauf Kachel GeGe 0': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-gege0"]',
  'Checkout Beginn Ablauf GeGe-Produkt 0': '[id="produktname-gege0"]',
  'Checkout Beginn Ablauf GeGe Beginndatum 0': '[data-cy="beginn-und-ablauf-beginn-gege0"]',
  'Checkout Beginn Ablauf GeGe Laufzeit 0': '[data-cy="beginn-und-ablauf-laufzeit-gege0"]',

  'Checkout Beginn Ablauf Kachel GeGe 1': 'ps20-frontend-beginn-ablauf-kachel div[data-cy="beginn-und-ablauf-kachel-gege1"]',
  'Checkout Beginn Ablauf GeGe-Produkt 1': '[id="produktname-gege1"]',
  'Checkout Beginn Ablauf Beginndatum GeGe 1': '[data-cy="beginn-und-ablauf-beginn-gege1"]',
  'Checkout Beginn Ablauf Laufzeit GeGe 1': '[data-cy="beginn-und-ablauf-laufzeit-gege1"]',

  'Checkout Gegenstandsschutz 0 Modell': (index) =>`[data-cy="checkout-gege-modell-0-${index}"]`,
  'Checkout Gegenstandsschutz 0 Informationen': (index) => `[data-cy="checkout-gege-informationen-0-${index}"]`,
};
