export const selectorMapping = {
  'Toolbar Allianz Logo': '.allianz-logo',
  'Toolbar Gesamtbeitrag Button': '[data-cy="toolbar-gesamtbeitrag-button"]',

  'Toolbar Gesamtbeitrag': '[data-cy="shop-toolbar-gesamtbeitrag"]',
  'Toolbar Gesamtbeitrag Loading':
    '[data-cy="shop-toolbar-gesamtbeitrag-loading"]',
  'Toolbar Gesamtpreis Info': '[data-cy="toolbar-gesamtpreisinfo"]',
  'Toolbar Zahlungsweise Dropdown':
    '[data-cy="toolbar-zahlungsweise-dropdown"]',
  'Toolbar Zahlungsart Radio Group':
    '[data-cy="toolbar-zahlungsart-radiogroup"]',
  'Toolbar Preis': '[data-cy="toolbar-gesamtbeitrag-button"]',
  'Toolbar Speichern Button': '[id="speichern"]',
  'Toolbar Speichern Vermerk Input': '[data-cy="vermerk"]',
  'Toolbar Speichern Vermerk Input Error': '[data-cy="vermerk-error"]',
  'Toolbar Speichern Vermerk Speichern Button':
    '[data-cy="speichernButton-toolbar"]',
  'Toolbar Speichern Vermerk Abbrechen Button':
    '[data-cy="abbrechenButton-toolbar"]',
  'Toolbar Vorschlag drucken Button': '#langvorschlagDrucken',
  'Toolbar Progressbar': '[data-cy="progressbar_item_0"]',
  'Toolbar Vereinbarungen': '[data-cy="shop-toolbar-vereinbarungen"]',
  'Toolbar RBD Modal': '[data-cy="shop-toolbar-rbdModal"]',
  'Toolbar RBD Modal Number Stepper': '[data-cy="shop-toolbar-rbd-stepper"]',
  'Toolbar RBD Modal Number Stepper Input':
    '[data-cy="shop-toolbar-rbd-stepper"] input',
  'Toolbar RBD Modal Button': '[data-cy="shop-toolbar-modal-button"]',
  'Toolbar TB Modal Number Stepper':
    '[data-cy="shop-toolbar-treuebonus-stepper"]',
  'Toolbar TB Modal Number Stepper Input':
    '[data-cy="shop-toolbar-treuebonus-stepper"] input',
  'Toolbar TB Modal Number Stepper Plus': '[id="nx-number-stepper-0"]',
  'Toolbar TB Modal Number Stepper Plus-2': '[id="nx-number-stepper-1"]',
  'Toolbar RBD Number Input with Index': (index) =>
    `.angebot-container:nth-of-type(${
      parseInt(index) + 1
    }) [data-cy="shop-toolbar-rbd-stepper"] input`,
  'Toolbar TB Number Input with Index': (index) =>
    `.angebot-container:nth-of-type(${
      parseInt(index) + 1
    }) [data-cy="shop-toolbar-treuebonus-stepper"] input`,
  'Toolbar Modal TabGroup': '[data-cy="shop-toolbar-modal-tab-group"]',
  'Toolbar Treuebonus Hinweis': '[data-cy="hinweis-treuebonus-keine-Angebote"]',
  'Toolbar Kuendigung Checkbox Group':
    '[data-cy="toolbar-kuendigung-checkbox-group"]',
  'Toolbar Kuendigung Checkbox': '[data-cy="toolbar-kuendigung-checkbox"]',

  'Toolbar Gesamtbeitrag Details': 'shop-toolbar-gesamtbeitrag-details',
  'Toolbar Gesamtbeitrag Details Zahlungsweise Dropdown':
    '#zahlungsweiseDropdown',

  Toolbar: '[data-cy="shop-toolbar"]',
  'Toolbar VN Box': '[data-cy="toolbar-vn-box"]',
  'Toolbar VN Assekuranztarif':
    '[data-cy="vn-assekuranztarif"]', // alt
  'Toolbar VN Assekuranztarif Button':
    '[data-cy="vn-assekuranztarif-btn"]',
  'Toolbar VN Assekuranztarif Role':
    '[data-cy="vn-assekuranztarif-role"]',
  'Toolbar VN Assekuranztarif Role Modal':
    '[data-cy="vn-assekuranztarif-modal"]',
  'Toolbar VN Assekuranztarif Role Modal Radio-Group':
    '[data-cy="vn-assekuranztarif-modal-radio"]',
  'Toolbar VN Assekuranztarif Info':
    '[data-cy="vn-assekuranztarif-info"]',
  'Toolbar VN Assekuranztarif Beibehaltung Hinweis':
    '[data-cy="vn-assekuranztarif-beibehaltung-hinweis"]',
  'Toolbar VN Assekuranztarif Juristisch Hinweis':
    '[data-cy="vn-assekuranztarif-juristisch-hinweis"]',
  'Toolbar Risikobonus Modal': '#rbddialog',

  'Toolbar Logout Button': '[data-cy="logout-button"]',
  'Logged Out Page': '[data-cy="loggedout-page"]',
};
