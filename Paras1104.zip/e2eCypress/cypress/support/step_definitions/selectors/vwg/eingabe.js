export const selectorMapping = {
  'VWG Eingabe Page': 'vwg-angebot-eingabe',
  'VWG Eingabe Subtitle Info': '[data-cy="vwg-subtitle-info"]',
  'VWG Eingabe PLZ Input': '[data-cy="vwg-basisangaben-plz-input"]',
  'VWG Eingabe PLZ Vorbelegt': '[data-cy="vwg-basisangaben-plz-vorbelegt"]',
  'VWG Eingabe Ort Input': '[data-cy="vwg-basisangaben-ort-input"]',
  'VWG Eingabe Ort Vorbelegt': '[data-cy="vwg-basisangaben-ort-vorbelegt"]',
  'VWG Eingabe Ort Dropdown': '[data-cy="vwg-basisangaben-ort-dropdown"]',
  'VWG Eingabe Strasse Input': '[data-cy="vwg-basisangaben-strasse"]',
  'VWG Eingabe Strasse Vorbelegt':
    '[data-cy="vwg-basisangaben-strasse-vorbelegt"]',
  'VWG Eingabe Strasse Dropdown':
    '[data-cy="vwg-basisangaben-strasse-dropdown"]',
  'VWG Eingabe Hausnr Input': '[data-cy="vwg-basisangaben-hausnummer-input"]',
  'VWG Eingabe Hausnr Vorbelegt':
    '[data-cy="vwg-basisangaben-hausnummer-vorbelegt"]',
  'VWG Eingabe Wohnflaeche Input':
    '[data-cy="vwg-basisangaben-wohnflaeche-input"]',
  'VWG Eingabe Baujahr Input': '[data-cy="vwg-basisangaben-baujahr-input"]',
  'VWG Eingabe NLF Error': '[data-cy="vwg-basisangaben-nlf-error"]',
  'VWG Eingabe Geburtsdatum Input':
    '[data-cy="vwg-basisangaben-geburtsdatum-input"]',
  'VWG Eingabe Geburtsdatum Vorbelegt':
    '[data-cy="vwg-basisangaben-geburtsdatum-vorbelegt"]',
  'VWG Eingabe Nebengebaeude Radio':
    '[data-cy="vwg-basisangaben-nebengebaeude-radio"]',
  'VWG Eingabe Nebengebaeude Flaeche Input':
    '[data-cy="vwg-basisangaben-nebengebaeude-flaeche-input"]',
  'VWG Eingabe Wohnflaeche im Keller vorhanden Radio':
    '[data-cy="vwg-basisangaben-wohnflaeche-keller-vorhanden-radio"]',
  'VWG Eingabe Gebaeudemerkmale':
    '[data-cy="vwg-basisangaben-gebaeudemerkmale"]',
  'VWG Eingabe Info icon KellerInfo': '[data-cy="kellerInfo"]',
  'VWG Eingabe Info icon DachbelagInfo': '[data-cy="dachbelagInfo"]',
  'VWG Eingabe Info icon FlachdachInfo': '[data-cy="flachdachInfo"]',
  'VWG Eingabe Info icon AussenwaendeInfo': '[data-cy="aussenwaendeInfo"]',
  'VWG Eingabe Info icon SolarthermieInfo': '[data-cy="solarthermieInfo"]',
  'VWG Eingabe Info icon PhotovoltaikInfo': '[data-cy="photovoltaikInfo"]',
  'VWG Eingabe Info icon GeothermieInfo': '[data-cy="geothermieInfo"]',
  'VWG Eingabe Info icon NichtDauerhaftBewohntInfo':
    '[data-cy="nichtDauerhaftBewohntInfo"]',
  'VWG Eingabe Info icon FerienhausInfo': '[data-cy="ferienhausInfo"]',
  'VWG Eingabe Info icon SchwimmbadInfo': '[data-cy="schwimmbadInfo"]',
  'VWG Eingabe Info icon DenkmalschutzInfo': '[data-cy="denkmalschutzInfo"]',
  'VWG Eingabe Info icon FeuerrohbauInfo': '[data-cy="feuerrohbauInfo"]',
  'VWG Eingabe Feuerrohbau Checkbox': '[data-cy="feuerrohbau-checkbox"]',
  'VWG Vorvertrag mit gleicher Adresse vorhanden - Error':
    '[data-cy="errmsg-vwg-angebot-error-VORVERTRAG_WITH_SAME_ADRESS_EXISTS"]',
  'VWG Risikoort bereits versichert - Error':
    '[data-cy="errmsg-vwg-angebot-error-RISIKOORT_BEREITS_VERSICHERT"]',
  'Info icon text': '[data-cy="icon-info-text"]',
  'VWG Eingabe Vorschaeden Radio':
    '[data-cy="vwg-basisangaben-vorschaeden-radio"]',
  'VWG Eingabe Vorschaeden Radio Nein':
    '[data-cy="vwg-basisangaben-vorschaeden-radio-nein"]',
  'VWG Eingabe Vorschaeden Radio Ja':
    '[data-cy="vwg-basisangaben-vorschaeden-radio-ja"]',
  'VWG Eingabe Vorschaeden Details':
    '[data-cy="vwg-basisangaben-vorschaeden-details"]',
  'VWG Eingabe Sigl Radio': '[data-cy="checkout-sg-ja-nein-radiovwg0"]',
  'VWG Eingabe Sigl Radio 1': '[data-cy="checkout-sg-ja-nein-radiovwg1"]',
  'VWG Checkout Sigl': '[data-cy="checkout-sicherungsglaeubiger"]',
  'VWG Eingabe Checkout Sigl Adressart Radio 0':
    '[data-cy="sicherungsglaeubiger-adressart-radio0vwg0"]',
  'VWG Eingabe Checkout Sigl Bankname 0':
    '[data-cy="checkout-sg-name-input0vwg0"]',
  'VWG Eingabe Checkout Sigl Bankname 1vwg0':
    '[data-cy="checkout-sg-name-input1vwg0"]',
  'VWG Eingabe Checkout Sigl Bankname 2vwg0':
    '[data-cy="checkout-sg-name-input2vwg0"]',
  'VWG Eingabe Checkout Sigl Aktenzeichen 0':
    '[data-cy="checkout-sg-aktenzeichen-input0vwg0"]',
  'VWG Eingabe Checkout Sigl Aktenzeichen 1vwg0':
    '[data-cy="checkout-sg-aktenzeichen-input1vwg0"]',
  'VWG Eingabe Checkout Sigl Aktenzeichen 2vwg0':
    '[data-cy="checkout-sg-aktenzeichen-input2vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Strasse 0':
    '[data-cy="bankadresseStrasse0vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Strasse 1vwg0':
    '[data-cy="bankadresseStrasse1vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Strasse 2vwg0':
    '[data-cy="bankadresseStrasse2vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse PLZ 0':
    '[data-cy="checkout-sg-plz-input0vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse PLZ 1vwg0':
    '[data-cy="checkout-sg-plz-input1vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse PLZ 2vwg0':
    '[data-cy="checkout-sg-plz-input2vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Ort 0vwg0':
    '[data-cy="checkout-sg-ort-vorschlag0vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Ort 1vwg0':
    '[data-cy="checkout-sg-ort-vorschlag1vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Ort 2vwg0':
    '[data-cy="checkout-sg-ort-vorschlag2vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Postfach 0':
    '[data-cy="bankadressePostfach0vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Postfach 1':
    '[data-cy="bankadressePostfach1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Postfach 1vwg0':
    '[data-cy="bankadressePostfach1vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Grosskunde 0':
    '[data-cy="bankadresseGrosskunde0vwg0"]',
  'VWG Eingabe Checkout Sigl Adresse Grosskunde 1vwg0':
    '[data-cy="bankadresseGrosskunde1vwg0"]',
  'VWG Eingabe Checkout Sigl loeschen 0vwg0':
    '[data-cy="deleteSicherungsglaeubiger0vwg0"]',
  'VWG Eingabe Checkout Sigl loeschen 1vwg0':
    '[data-cy="deleteSicherungsglaeubiger1vwg0"]',
  'VWG Eingabe Checkout Sigl loeschen 2vwg0':
    '[data-cy="deleteSicherungsglaeubiger2vwg0"]',
  'VWG Eingabe Checkout Sigl loeschen 0vwg1':
    '[data-cy="deleteSicherungsglaeubiger0vwg1"]',
  'VWG Eingabe Checkout Sigl loeschen 1vwg1':
    '[data-cy="deleteSicherungsglaeubiger1vwg1"]',
  'VWG Eingabe Checkout Sigl Link weitere 0':
    '[data-cy="sicherungsglaeubiger-link-weitere0vwg0"]',
  'VWG Eingabe Checkout Sigl Adressart Radio 1':
    '[data-cy="sicherungsglaeubiger-adressart-radio1vwg0"]',
  'VWG Eingabe Checkout Sigl Bankname 0vwg1':
    '[data-cy="checkout-sg-name-input0vwg1"]',
  'VWG Eingabe Checkout Sigl Bankname 1vwg1':
    '[data-cy="checkout-sg-name-input1vwg1"]',
  'VWG Eingabe Checkout Sigl Aktenzeichen 0vwg1':
    '[data-cy="checkout-sg-aktenzeichen-input0vwg1"]',
  'VWG Eingabe Checkout Sigl Aktenzeichen 1vwg1':
    '[data-cy="checkout-sg-aktenzeichen-input1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Strasse 0vwg1':
    '[data-cy="bankadresseStrasse0vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Strasse 1vwg1':
    '[data-cy="bankadresseStrasse1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse PLZ 0vwg1':
    '[data-cy="checkout-sg-plz-input0vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse PLZ 1vwg1':
    '[data-cy="checkout-sg-plz-input1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Ort 0vwg1':
    '[data-cy="checkout-sg-ort-vorschlag0vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Ort 1vwg1':
    '[data-cy="checkout-sg-ort-vorschlag1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Postfach 0vwg1':
    '[data-cy="bankadressePostfach0vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Postfach 1vwg1':
    '[data-cy="bankadressePostfach1vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Grosskunde 0vwg1':
    '[data-cy="bankadresseGrosskunde0vwg1"]',
  'VWG Eingabe Checkout Sigl Adresse Grosskunde 1vwg1':
    '[data-cy="bankadresseGrosskunde1vwg1"]',
  'VWG Eingabe Checkout Sigl Link weitere 1vwg0':
    '[data-cy="sicherungsglaeubiger-link-weitere1vwg0"]',
  'VWG Eingabe Checkout Sigl Link weitere 1vwg1':
    '[data-cy="sicherungsglaeubiger-link-weitere1vwg1"]',
  'VWG Eingabe Vorschaeden Feuer Stepper':
    '[data-cy="vwg-basisangaben-vorschaeden-feuer-stepper"]',
  'VWG Eingabe Vorschaeden Leitungswasser Stepper':
    '[data-cy="vwg-basisangaben-vorschaeden-leitungswasser-stepper"]',
  'VWG Eingabe Vorschaeden SturmHagel Stepper':
    '[data-cy="vwg-basisangaben-vorschaeden-sturmhagel-stepper"]',
  'VWG Eingabe Vorschaeden Elementar Stepper':
    '[data-cy="vwg-basisangaben-vorschaeden-elementar-stepper"]',
  'VWG Eingabe Vorschaeden Feuer Stepper Input':
    '[data-cy="vwg-basisangaben-vorschaeden-feuer-stepper"] input',
  'VWG Eingabe Vorschaeden Leitungswasser Stepper Input':
    '[data-cy="vwg-basisangaben-vorschaeden-leitungswasser-stepper"] input',
  'VWG Eingabe Vorschaeden SturmHagel Stepper Input':
    '[data-cy="vwg-basisangaben-vorschaeden-sturmhagel-stepper"] input',
  'VWG Eingabe Vorschaeden Elementar Stepper Input':
    '[data-cy="vwg-basisangaben-vorschaeden-elementar-stepper"] input',
  'VWG Eingabe Vorschaeden Required Meldung':
    '[data-cy="vwg-basisangaben-vorschaeden-required-error-msg"]',
  'VWG Eingabe Vorschaeden Number Required Meldung':
    '[data-cy="vwg-basisangaben-vorschaeden-number-required-error-msg"]',
  'VWG Eingabe Vorschaeden Number Ueberschritten Meldung':
    '[data-cy="vwg-basisangaben-vorschaeden-uberschritten-error-msg"]',
  'VWG Eingabe Vorschaeden Numberstepper Feuer':
    '[data-cy="vwg-basisangaben-vorschaeden-feuer-stepper"]',
  'VWG Eingabe Vorschaeden Numberstepper Feuer Input':
    '[data-cy="vwg-basisangaben-vorschaeden-feuer-stepper"] input',
  'VWG Eingabe Vorschaeden Numberstepper Leitungswasser':
    '[data-cy="vwg-basisangaben-vorschaeden-leitungswasser-stepper"]',
  'VWG Eingabe Vorschaeden Numberstepper Leitungswasser Input':
    '[data-cy="vwg-basisangaben-vorschaeden-leitungswasser-stepper"] input',
  'VWG Eingabe Vorschaeden Numberstepper Sturm Hagel':
    '[data-cy="vwg-basisangaben-vorschaeden-sturmhagel-stepper"]',
  'VWG Eingabe Vorschaeden Numberstepper Sturm Hagel Input':
    '[data-cy="vwg-basisangaben-vorschaeden-sturmhagel-stepper"] input',
  'VWG Eingabe Vorschaeden Numberstepper Elementar':
    '[data-cy="vwg-basisangaben-vorschaeden-elementar-stepper"]',
  'VWG Eingabe Vorschaeden Numberstepper Elementar Input':
    '[data-cy="vwg-basisangaben-vorschaeden-elementar-stepper"] input',
};
