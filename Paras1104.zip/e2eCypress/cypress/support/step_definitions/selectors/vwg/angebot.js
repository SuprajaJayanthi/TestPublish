export const selectorMapping = {
  'VWG Angebot Page': 'vwg-angebot-angebot',
  'VWG Angebot Selbstbeteiligung Dropdown':
    '[data-cy="global-vertragsoption-selbstbeteiligung"]',
  'VWG Angebot Hinweise Feuerrohbau': '[data-cy="feuerrohbau-hinweis"]',

  'VWG Angebot Tabelle Versicherte Gefahren Komfort Button':
    '[data-cy="vwg-angebot-Komfort-Button-Versicherte Gefahren"]',
  'VWG Angebot Tabelle Versicherte Gefahren Komfort Popover':
    '[data-cy="vwg-angebot-table-komfort-versicherte-gefahren-popover"]',
  'VWG Angebot Tabelle Versicherte Gefahren Komfort':
    '[data-cy="vwg-angebot-Komfort-Versicherte Gefahren"]',

  'VWG Angebot Zusatzoptionen Extremwetterschutz': `[data-cy="vwg-angebot-zusatzoption-weitereNaturgefahren"]`,
  'VWG Angebot Zusatzoptionen Glasschutz Gebaeude': `[data-cy="vwg-angebot-zusatzoption-glasAußen"]`,
  'VWG Angebot Zusatzoptionen Oeltank-Haftpflichtschutz': `[data-cy="vwg-angebot-zusatzoption-oeltank"]`,
  'VWG Angebot Zusatzoptionen Haus-Haftpflichtschutz': `[data-cy="vwg-angebot-zusatzoption-haushaftpflicht"]`,
  'VWG Angebot Zusatzoptionen Notfallservice Zuhause': `[data-cy="vwg-angebot-zusatzoption-hausUndWohnungsschutzbrief"]`,
  'VWG Angebot Zusammenfassung Gesamtbeitrag': `[data-cy="angebotszusammenfassung-gesamtbeitrag"]`,
  'VWG Angebot übernehmen': `[id="weiter-zum-antrag-button"]`,

  'VWG VN Wechsel Grund Dropdown': (index) =>
    `[data-cy="vwg-vnWechselGrund-dropdown-0-${index}"]`,
  'VWG VN Wechsel Grund Required Error': (index) =>
    `[data-cy="vwg-vnWechselGrund-required-error-${index}"]`,
};
