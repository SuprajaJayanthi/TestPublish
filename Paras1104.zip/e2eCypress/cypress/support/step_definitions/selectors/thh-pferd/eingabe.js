const navigationMapping = {
  'THH-Pferd Eingabe Progressbar Item': `[data-cy="progressbar_item_0"]`,
  'THH-Pferd Eingabe Zurück zum Shop': `[data-cy="thh-pferd-navigateToDashboard-link"]`,
  'THH-Pferd Eingabe Page': `thh-pferd-angebot-eingabe`,
  'THH-Pferd Tarif Berechnen Button': `[data-cy="thh-pferd-tarif-berechnen-button"]`,
  'THH-Pferd Angebot Page': `thh-pferd-angebot-angebot`,
};

const eingabeBasisangaben = {
  'THH-Pferd Eingabe PLZ Input': `[data-cy="thh-pferd-basisangaben-plz-input"]`,
  'THH-Pferd Eingabe PLZ Vorbelegt': `[data-cy="thh-pferd-basisangaben-plz-vorbelegt"]`,

  'THH-Pferd Eingabe Ort Input': `[data-cy="thh-pferd-basisangaben-ort-input"]`,
  'THH-Pferd Eingabe Ort Vorbelegt': `[data-cy="thh-pferd-basisangaben-ort-vorbelegt"]`,
  'THH-Pferd Eingabe Ort Dropdown': `[data-cy="thh-pferd-basisangaben-ort-dropdown"]`,

  'THH-Pferd Eingabe Strasse Input': `[data-cy="thh-pferd-basisangaben-strasse"]`,
  'THH-Pferd Eingabe Strasse Vorbelegt': `[data-cy="thh-pferd-basisangaben-strasse-vorbelegt"]`,
  'THH-Pferd Eingabe Strasse Dropdown': `[data-cy="thh-pferd-basisangaben-strasse-dropdown"]`,

  'THH-Pferd Eingabe Hausnr Input': `[data-cy="thh-pferd-basisangaben-hausnummer-input"]`,
  'THH-Pferd Eingabe Hausnr Vorbelegt': `[data-cy="thh-pferd-basisangaben-hausmnummer-vorbelegt"]`,

  'THH-Pferd Eingabe Geburtsdatum Input': `[data-cy="thh-pferd-basisangaben-geburtsdatum-input"]`,
  'THH-Pferd Eingabe Geburtsdatum Vorbelegt': `[data-cy="thh-pferd-basisangaben-geburtsdatum-vorbelegt"]`,

  'THH-Pferd Eingabe NLF Error': `[data-cy="thh-pferd-basisangaben-nlf-error"]`,

  'THH-Pferd Eingabe AnzahlTiere Dropdown': `[data-cy="thh-pferd-basisangaben-anzahlTiere-dropdown"]`,
  'THH-Pferd Eingabe AnzahlTiere Dropdown Item - ein Pferd': `[data-cy="thh-pferd-basisangaben-anzahlTiere-dropdown-item-EIN_TIER"]`,
  'THH-Pferd Eingabe AnzahlTiere Dropdown Item - mehrere Pferde': `[data-cy="thh-pferd-basisangaben-anzahlTiere-dropdown-item-MEHRERE_TIERE"]`,
};

const eingabeStockmassEinPferd = {
  'THH-Pferd Eingabe EinPferd Radio': `[data-cy="thh-pferd-basisangaben-stockmass-radio"]`,
  'THH-Pferd Eingabe EinPferd Radio Kleiner': `[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner"]`,
  'THH-Pferd Eingabe EinPferd Radio Groesser': `[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser"]`,
  'THH-Pferd Eingabe EinPferd Required Error': `[data-cy="thh-pferd-basisangaben-stockmass-required-error-msg"]`,
};

const eingabeStockmassMehrerePferde = {
  'THH Pferd Eingabe MehrerePferdeStockmass Stepper':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-stepper"]',
  'THH Pferd Eingabe MehrerePferdeStockmass Stepper - Input':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-stepper"] input',
  'THH Pferd Eingabe MehrerePferdeStockmass Underwriter Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-underwriter-error"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio with Index': (index) =>
    `[data-cy="thh-pferd-basisangaben-stockmass-radio-${index}"]`,
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 0':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-0"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 1':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-1"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 2':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-2"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 3':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-3"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 4':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-4"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 5':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-5"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 6':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-6"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 7':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-7"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 8':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-8"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 9':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-9"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 10':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-10"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 0 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-0"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 0 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-0"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 1 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-1"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 1 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-1"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 2 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-2"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 2 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-2"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 3 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-3"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 3 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-3"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 4 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-4"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 4 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-4"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 5 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-5"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 5 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-5"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 6 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-6"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 6 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-6"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 7 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-7"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 7 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-7"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 8 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-8"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 8 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-8"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 9 - Kleiner':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-kleiner-9"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 9 - Groesser':
    '[data-cy="thh-pferd-basisangaben-stockmass-radio-groesser-9"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 0 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-0"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 1 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-1"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 2 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-2"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 3 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-3"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 4 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-4"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 5 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-5"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 6 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-6"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 7 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-7"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 8 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-8"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 9 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-9"]',
  'THH-Pferd Eingabe MehrerePferdeStockmass Radio - 10 - Required Error':
    '[data-cy="thh-pferd-pferdestockmass-mehrere-pferde-required-error-10"]',
};

const eingabeVorschaeden = {
  'THH-Pferd Eingabe Vorschäden Radio': `[data-cy="thh-pferd-basisangaben-vorschaeden-radio"]`,
  'THH-Pferd Eingabe Vorschaeden Radio Ja': `[data-cy="thh-pferd-basisangaben-vorschaeden-radio-ja"]`,
  'THH-Pferd Eingabe Vorschaeden Radio Nein': `[data-cy="thh-pferd-basisangaben-vorschaeden-radio-nein"]`,
  'THH-Pferd Eingabe Vorschäden Required Message':
    '[data-cy=thh-pferd-basisangaben-vorschaeden-required-error-msg]',
  'THH-Pferd Eingabe Vorschaeden Stepper':
    '[data-cy="thh-pferd-basisangaben-vorschaeden-thhPferdVorschaeden-stepper"]',
  'THH-Pferd Eingabe Vorschäden Anzahl Required Message':
    '[data-cy=thh-pferd-basisangaben-vorschaeden-number-required-error-msg]',
  'THH-Pferd Eingabe Vorschäden Anzahl Überschritten Message':
    '[data-cy="thh-pferd-basisangaben-vorschaeden-uberschritten-error-msg"]',
};

const eingabeMapping = {
  ...eingabeBasisangaben,
  ...eingabeStockmassEinPferd,
  ...eingabeStockmassMehrerePferde,
  ...eingabeVorschaeden,
};

export const selectorMapping = {
  ...navigationMapping,
  ...eingabeMapping,
};
