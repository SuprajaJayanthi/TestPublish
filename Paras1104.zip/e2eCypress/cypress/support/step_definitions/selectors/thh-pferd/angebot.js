export const selectorMapping = {
  'THH Angebot Page': `thh-angebot-angebot`,

  'THH Angebot Hinweismeldung Liniensteuerung':
    '[data-cy="hinweismeldung-liniensteuerung"]',

  'THH Angebot Selbstbeteiligung Dropdown': `[data-cy="global-vertragsoption-selbstbeteiligung"]`,

  'THH-Pferd Angebot uebernehmen': `[id="weiter-zum-antrag-button"]`,
};
