export const selectorMapping = {
  'RS - Vermietung Angebot Page': 'rs-angebot-angebot',
}

