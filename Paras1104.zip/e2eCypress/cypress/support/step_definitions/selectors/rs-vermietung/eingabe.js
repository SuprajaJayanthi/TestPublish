export const selectorMapping = {
  'RS - Vermietung Eingabe Page': `rs-vermietung-angebot-eingabe`,
  'RS - Vermietung Eingabe Familienstand Dropdown': `[data-cy="rs-vermietung-basisangaben-familienstand-dropdown"]`,
  'RS - Vermietung NFL Label1': '[data-cy="rs-vermietung-basisangaben-nlf1label1"]',
  'RS - Vermietung NFL Label2': '[data-cy="rs-vermietung-basisangaben-nlf1label2"]',
  'RS - Vermietung NFL Label3': '[data-cy="rs-vermietung-basisangaben-nlf1label3"]',
  'RS - Vermietung NFL Label4': '[data-cy="rs-vermietung-basisangaben-nlf1label4"]',
  'RS - Vermietung Adresse': '[data-cy="rs-vermietung-basisangaben-adresse"]',
  'RS - Vermietung Gebrutsdatum': '[data-cy="rs-vermietung-basisangaben-geburtsdatum"]',
  'RS - Vermietung Familienstand': '[data-cy="rs-vermietung-basisangaben-familienstand"]',
  'RS - Vermietung NLF Error': '[data-cy="rs-vermietung-basisangaben-nlf-error"]',
  'RS - Vermietung Tarif Berechnen Required Error': '[data-cy="rs-vermietung-tarif-berechnen-errors-required"]',
  'RS - Vermietung Zurück zum Shop': `[data-cy="rs-vermietung-navigateToDashboard-link"]`
};
