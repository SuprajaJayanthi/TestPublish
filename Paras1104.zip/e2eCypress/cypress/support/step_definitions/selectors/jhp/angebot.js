export const selectorMapping = {
  'JHP Seite Angebot':                            'jhp-angebot-angebot',
  'JHP Vertragsoptionen':                         'jhp-angebot-vertragsoptionen',
  'JHP Dashboard Angebotsuebersicht':             '[data-cy="dashboard-uebersicht-angebote-jhp-angebot"]',
  'JHP SB Satz':                                  'jhp-angebot-vertragsoptionen nx-natural-language-form',
  'JHP SB Info-Icon':                             'info-icon',
  'JHP Info-Icon Versicherungssumme':             'info-icon[id="info-icon-leistung-Versicherungssumme"]',
  'JHP Info-Icon Button':                         'button[aria-label="info icon"]',
  'JHP Button Angebot uebernehmen':               'button[id="weiter-zum-antrag-button"]',
  'Jagdhaft Angebot Selbstbeteiligung Dropdown':  '[data-cy="global-vertragsoption-selbstbeteiligung"]',
};
