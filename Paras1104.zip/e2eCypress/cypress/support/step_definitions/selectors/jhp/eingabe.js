export const selectorMapping = {
  'JHP Seite Eingabe':              'jhp-angebot-eingabe',
  'JHP Eingabe Zurück zum Shop': `[data-cy="jhp-navigateToDashboard"]`,
  'JHP Basisangaben':               'jhp-angebot-basisangaben',
  'JHP Tarif Berechnen Abschnitt':  'jhp-angebot-tarif-berechnen',

  'JHP Button zum Angebot':         'button:contains("Zum Angebot")',
};
