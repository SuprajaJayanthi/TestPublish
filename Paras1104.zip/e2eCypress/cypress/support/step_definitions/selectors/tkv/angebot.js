export const selectorMapping = {
  'TKV Angebot Page': 'tkv-angebot-angebot',

  'TKV Angebot Selbstbeteiligung Dropdown':
    '[data-cy="global-vertragsoption-selbstbeteiligung"]',

  'TKV Angebot Zusatzbausteine': '#zusatzoptionen',
  'TKV Angebot Zusatzbausteine Header':
    '[data-cy="tkv-angebot-zusatzoption-heading"]',
  'TKV Angebot Zusatzbausteine Subheader':
    '[data-cy="tkv-angebot-zusatzoption-subheading"]',

  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz':
    '[data-cy="tkv-angebot-zusatzoption-hb"]',
  'TKV Angebot Zusatzoptionen Heilbehandlungsschutz':
    '[data-cy="tkv-angebot-zusatzoption-hb"]',
  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz Radios':
    '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios"]',
  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz Radios 1':
    '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios-1"] input',
  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz Radios 2':
    '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios-2"] input',
  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz Radios 1 Info-Icon':
    '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios-1"] nxt-info-icon',
  'TKV Angebot Zusatzbaustein Heilbehandlungsschutz Radios 2 Info-Icon':
    '[data-cy="tkv-angebot-zusatzoption-heilbehandlungsschutz-radios-2"] nxt-info-icon',

  'TKV Angebot uebernehmen': `[id="weiter-zum-antrag-button"]`,
};
