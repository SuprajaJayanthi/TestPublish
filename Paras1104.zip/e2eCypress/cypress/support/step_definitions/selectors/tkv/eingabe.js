const navigationMapping = {
  'TKV Eingabe Page': `tkv-angebot-eingabe`,
  'TKV Eingabe Zurück zum Shop': `[data-cy="tkv-navigateToDashboard"]`,
  'TKV Tarif Berechnen Button': `[data-cy="tkv-tarif-berechnen-button"]`,
};

const eingabeBasisangaben = {
  'TKV Basisangaben Tierart Dropdown': `[data-cy="tkv-basisangaben-tierart-dropdown"]`,
  'TKV Basisangaben Tierart Dropdown Hund': `[data-cy="tkv-basisangaben-tierart-dropdown-item-Hund"]`,
  'TKV Basisangaben Tierart Dropdown Katze': `[data-cy="tkv-basisangaben-tierart-dropdown-item-Katze"]`,
  'TKV Basisangaben Tierart Dropdown Pferd': `[data-cy="tkv-basisangaben-tierart-dropdown-item-Pferd"]`,

  'TKV Basisangaben Tiergeschlecht Dropdown': `[data-cy="tkv-basisangaben-geschlecht-dropdown"]`,
  'TKV Basisangaben Tiergeschlecht Dropdown maennlich': `[data-cy="tkv-basisangaben-geschlecht-dropdown-item-MÄNNLICH"]`,
  'TKV Basisangaben Tiergeschlecht Dropdown weiblich': `[data-cy="tkv-basisangaben-geschlecht-dropdown-item-WEIBLICH"]`,

  'TKV Basisangaben Hunderassen Dropdown': `[data-cy="tkv-basisangaben-hunderassen-dropdown"]`,
  'TKV Basisangaben Pferderassen Dropdown': `[data-cy="tkv-basisangaben-pferderassen-dropdown"]`,
  'TKV Basisangaben Katzenrassen Dropdown': `[data-cy="tkv-basisangaben-katzenrassen-dropdown"]`,

  'TKV Eingabe NLF Error': `[data-cy="tkv-basisangaben-nlf-error"]`,

  'TKV Basisangaben Geburtsdatum Vorbelegt': `[data-cy="tkv-basisangaben-geburtsdatum-vorbelegt"]`,
  'TKV Basisangaben Geschlecht Vorbelegt': `[data-cy="tkv-basisangaben-geschlecht-vorbelegt"]`,
  'TKV Basisangaben Tierart Vorbelegt': `[data-cy="tkv-basisangaben-tierart-vorbelegt"]`,
  'TKV Basisangaben Rasse Vorbelegt': `[data-cy="tkv-basisangaben-rasse-vorbelegt"]`,
  'TKV Basisangaben Operationen Checkbox': `[id="mitOperation"]`
};

const eingabeAngabenZumTier = {
  'TKV Geburtsdatum': `[data-cy="tkv-geburtsdatum-input"]`,

  'TKV Kastriert Radio Group': `[data-cy="tkv-kastriert-radio-group"]`,

  'TKV Katzenhaltung Radio Group': `[data-cy="tkv-katzenhaltung-radio-group"]`,

  'TKV Behandlungen Radio Group': `[data-cy="tkv-behandlungen-radio-group"]`,

  'TKV Tierarzt Checkbox Group': `[data-cy="tkv-tierarzt-checkbox-group"]`,
  'TKV Tierarzt Fehlermeldung': `[data-cy="tkv-tierarzt-error"]`,

  'TKV Operationen Number Stepper Input': '#nx-number-stepper-0',
  'TKV Operationen Fehlermeldung': `[data-cy="tkv-operationen-fehlermeldung"]`,

  'TKV Erkrankungen Radio Group': `[data-cy="tkv-erkrankungen-radio-group"]`,
  'TKV Erkrankungen Warnung': `[data-cy="tkv-erkrankungen-warning"]`,

  'TKV Diagnosen': `[data-cy="tkv-diagnosen"]`,
};

const eingabeMapping = {
  ...eingabeBasisangaben,
  ...eingabeAngabenZumTier,
};

export const selectorMapping = {
  ...navigationMapping,
  ...eingabeMapping,
};
