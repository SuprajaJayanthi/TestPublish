export const selectorMapping = {
  'VHV Eingabe Page': `vhv-angebot-eingabe`,

  'VHV Eingabe PLZ Input': `[data-cy="vhv-basisangaben-plz-input"]`,
  'VHV Eingabe PLZ Vorbelegt': `[data-cy="vhv-basisangaben-plz-vorbelegt"]`,

  'VHV Eingabe Ort Input': `[data-cy="vhv-basisangaben-ort-input"]`,
  'VHV Eingabe Ort Vorbelegt': `[data-cy="vhv-basisangaben-ort-vorbelegt"]`,
  'VHV Eingabe Ort Dropdown': `[data-cy="vhv-basisangaben-ort-dropdown"]`,

  'VHV Eingabe Strasse Input': `[data-cy="vhv-basisangaben-strasse"]`,
  'VHV Eingabe Strasse Vorbelegt': `[data-cy="vhv-basisangaben-strasse-vorbelegt"]`,
  'VHV Eingabe Strasse Dropdown': `[data-cy="vhv-basisangaben-strasse-dropdown"]`,

  'VHV Eingabe Hausnr Input': `[data-cy="vhv-basisangaben-hausnummer-input"]`,
  'VHV Eingabe Hausnr Vorbelegt': `[data-cy="vhv-basisangaben-hausnummer-vorbelegt"]`,

  'VHV Eingabe Wohnflaeche Input': `[data-cy="vhv-basisangaben-wohnflaeche-input"]`,

  'VHV Eingabe Geburtsdatum Input': `[data-cy="vhv-basisangaben-geburtsdatum-input"]`,
  'VHV Eingabe Geburtsdatum Vorbelegt': `[data-cy="vhv-basisangaben-geburtsdatum-vorbelegt"]`,

  'VHV Eingabe Bewohnt Dropdown': `[data-cy="vhv-basisangaben-bewohnt-dropdown"]`,

  'VHV Eingabe Familienstand Dropdown': `[data-cy="vhv-basisangaben-familienstand-dropdown"]`,

  'VHV Eingabe NLF Error': `[data-cy="vhv-basisangaben-nlf-error"]`,

  'VHV Eingabe Vorschaeden Radio': `[data-cy="vhv-basisangaben-vorschaeden-radio"]`,
  'VHV Eingabe Vorschaeden Radio Ja':
    '[data-cy="vhv-basisangaben-vorschaeden-radio-ja"]',
  'VHV Eingabe Vorschaeden Radio Nein':
    '[data-cy="vhv-basisangaben-vorschaeden-radio-nein"]',
  'VHV Eingabe Vorschaeden Hausrat Stepper':
    '[data-cy="vhv-basisangaben-vorschaeden-fels-stepper"]',
  'VHV Eingabe Vorschaeden Hausrat Stepper Input':
    '[data-cy="vhv-basisangaben-vorschaeden-fels-stepper"] input',
  'VHV Eingabe Vorschaeden Fahrrad Stepper':
    '[data-cy="vhv-basisangaben-vorschaeden-fahrrad-stepper"]',
  'VHV Eingabe Vorschaeden Fahrrad Stepper Input':
    '[data-cy="vhv-basisangaben-vorschaeden-fahrrad-stepper"] input',
  'VHV Eingabe Vorschaeden Required Meldung': `[data-cy="vhv-basisangaben-vorschaeden-required-error-msg"]`,
  'VHV Eingabe Vorschaeden Number Required Meldung': `[data-cy="vhv-basisangaben-vorschaeden-number-required-error-msg"]`,
  'VHV Eingabe Vorschaeden Number Ueberschritten Meldung': `[data-cy="vhv-basisangaben-vorschaeden-uberschritten-error-msg"]`,

  'VHV Eingabe Hausart Required Meldung': `[data-cy="vhv-basisangaben-hausart-required-error-msg"]`,
  'VHV Eingabe Haushalt Radio': '[data-cy="vhv-basisangaben-haushalt-radio"]',
  'VHV Eingabe Haushalt Radio Einfamilienhaus':
    '[data-cy="vhv-basisangaben-haushalt-radio-einfamilienhaus"]',
  'VHV Eingabe Haushalt Radio Mehrfamilienhaus':
    '[data-cy="vhv-basisangaben-haushalt-radio-mehrfamilienhaus"]',

  'VHV Eingabe Stockwerk': '[data-cy="vhv-basisangaben-stockwerk"]',
  'VHV Eingabe Stockwerk Radio Erdgeschoss':
    '[data-cy="vhv-basisangaben-stockwerk-radio-erdgeschoss"]',
  'VHV Eingabe Stockwerk Radio Obergeschoss':
    '[data-cy="vhv-basisangaben-stockwerk-radio-obergeschoss"]',

  'VHV Eingabe Zurück zum Shop': `[data-cy="vhv-navigateToDashboard-link"]`,

  'VHV Risikoort bereits versichert - Error': `[data-cy="errmsg-vhv-angebot-error-RISIKOORT_BEREITS_VERSICHERT"]`,
  'VHV Vorvertrag mit gleicher Adresse vorhanden - Error': `[data-cy="errmsg-vhv-angebot-error-VORVERTRAG_WITH_SAME_ADRESS_EXISTS"]`,
};
