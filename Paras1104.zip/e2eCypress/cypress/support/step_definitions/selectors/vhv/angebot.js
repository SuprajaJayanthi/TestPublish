export const selectorMapping = {
  'VHV Angebot Page': `vhv-angebot-angebot`,

  'VHV Angebot Versicherungssumme Input': `[data-cy="vhv-angebot-versicherungssumme-input"]`,
  'VHV Angebot Versicherungssumme Dropdown': `[data-cy="vhv-angebot-versicherungssumme-dropdown"]`,
  'VHV Angebot Produkttabelle Versicherungssumme Basis': `[data-cy="vhv-produkttabelle-eigenschaft-render-BASIS-versicherungssumme"]`,
  'VHV Angebot Produkttabelle Versicherungssumme Smart': `[data-cy="vhv-produkttabelle-eigenschaft-render-SMART-versicherungssumme"]`,
  'VHV Angebot Produkttabelle Versicherungssumme Komfort': `[data-cy="vhv-produkttabelle-eigenschaft-render-KOMFORT-versicherungssumme"]`,
  'VHV Angebot Produkttabelle Wertsachensumme Basis': `[data-cy="vhv-produkttabelle-eigenschaft-render-BASIS-wertsachensumme"]`,
  'VHV Angebot Produkttabelle Wertsachensumme Smart': `[data-cy="vhv-produkttabelle-eigenschaft-render-SMART-wertsachensumme"]`,
  'VHV Angebot Produkttabelle Wertsachensumme Komfort': `[data-cy="vhv-produkttabelle-eigenschaft-render-KOMFORT-wertsachensumme"]`,
  'VHV Angebot Produkttabelle Wertsachensumme Editieren Button': `[data-cy="vhv-angebot-wertsachensumme-editieren-button"]`,
  'VHV Angebot Popover Wertsachensumme Input': `[data-cy="vhv-angebot-wertsachensumme-input"]`,
  'VHV Angebot Popover Wertsachensumme Uebernehmen Button': `[data-cy="vhv-angebot-wertsachensumme-uebernehmen-button"]`,
  'VHV Angebot Popover Wertsachensumme Grenzen': `[data-cy="vhv-angebot-wertsachensumme-grenzen"]`,
  'VHV Angebot Unterversichrungsverzicht Hinweis': `[data-cy="vhv-unterversicherungsverzicht-hinweis"]`,
  'VHV Angebot Nicht Staendig Bewohnt Versicherungsumme ueber 50000 Hinweis': `[data-cy="vhv-nichtStaendigBewohnUeber50000-hinweis"]`,
  'VHV Angebot Nicht Staendig Bewohnt Wertsachensumme Nicht Enthalten': `[data-cy="vhv-angebot-wertsachensumme-nicht-enthalten"]`,

  'VHV Angebot Versicherungssumme Max Ueberschritten Hinweis': `[data-cy="vhv-versicherungssumme-hinweis-ueber-max"]`,
  'VHV Angebot Versicherungssumme 200000 Ueberschritten Hinweis': `[data-cy="vhv-versicherungssumme-hinweis-ueber-200000"]`,
  'VHV Angebot Versicherungssumme Vorschaeden Hinweis': `[data-cy="vhv-vorschaedenHinweis"]`,

  'VHV Angebot Zusatzoptionen': `[data-cy="vhv-angebot-zusatzoptionen"]`,

  'VHV Angebot Zusatzoptionen Fahrradschutz': `[data-cy="vhv-angebot-zusatzoption-diebstahlVonFahrradUndFortbewegungsmitteln"]`,
  'VHV Angebot Zusatzoptionen Fahrradschutz Dropdown': `#fahrradDropdown`,
  'VHV Angebot Zusatzoptionen Selected Card': `.nxt-option-card.is-selected`,

  'VHV Angebot Zusatzoptionen Glasschutz Hausrat': `[data-cy="vhv-angebot-zusatzoption-glasInnen"]`,

  'VHV Angebot Zusatzoptionen Glasschutz Gebaeude': `[data-cy="vhv-angebot-zusatzoption-glasAußen"]`,

  'VHV Angebot Zusatzoptionen Extremwetterschutz': `[data-cy="vhv-angebot-zusatzoption-weitereNaturgefahren"]`,

  'VHV Angebot Zusatzoptionen Notfallservice': `[data-cy="vhv-angebot-zusatzoption-hausUndWohnungsschutzbrief"]`,

  'VHV Angebot Zusammenfassung': `[data-cy="vhv-angebot-zusammenfassung"]`,
  'VHV Angebot Zusammenfassung Gesamtbeitrag': `[data-cy="angebotszusammenfassung-gesamtbeitrag"]`,
  'VHV Angebot übernehmen': '[id="weiter-zum-antrag-button"]',

  'VHV Angebot Selbstbeteiligung Dropdown': `[data-cy="vhv-vertragsoption-selbstbeteiligung"]`,
  'VHV Angebot Selbstbeteiligung Plain Text': `[data-cy="vhv-angebot-selbstbeteiligung-plain-text"]`,
  'VHV Wertsachen Popover': `.wertsachensumme-popover`,
};
