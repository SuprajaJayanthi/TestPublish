export const selectorMapping = {
  'RS Eingabe Page': `rs-angebot-eingabe`,

  'RS Eingabe PLZ Input': `[data-cy="rs-basisangaben-plz-input"]`,
  'RS Eingabe PLZ Vorbelegt': `[data-cy="rs-basisangaben-plz-vorbelegt"]`,

  'RS Eingabe Ort Input': `[data-cy="rs-basisangaben-ort-input"]`,
  'RS Eingabe Ort Vorbelegt': `[data-cy="rs-basisangaben-ort-vorbelegt"]`,
  'RS Eingabe Ort Dropdown': `[data-cy="rs-basisangaben-ort-dropdown"]`,

  'RS Eingabe Strasse Input': `[data-cy="rs-basisangaben-strasse"]`,
  'RS Eingabe Strasse Vorbelegt': `[data-cy="rs-basisangaben-strasse-vorbelegt"]`,
  'RS Eingabe Strasse Dropdown': `[data-cy="rs-basisangaben-strasse-dropdown"]`,

  'RS Eingabe Hausnr Input': `[data-cy="rs-basisangaben-hausnummer-input"]`,
  'RS Eingabe Hausnr Vorbelegt': `[data-cy="rs-basisangaben-hausnummer-vorbelegt"]`,

  'RS Eingabe Geburtsdatum Input': `[data-cy="rs-basisangaben-geburtsdatum-input"]`,
  'RS Eingabe Geburtsdatum Vorbelegt': `[data-cy="rs-basisangaben-geburtsdatum-vorbelegt"]`,

  'RS Eingabe Familienstand Dropdown': `[data-cy="rs-basisangaben-familienstand-dropdown"]`,

  'RS Eingabe NLF Error': `[data-cy="rs-basisangaben-nlf-error"]`,

  'RS Eingabe Selbststaendigkeit Checkbox Group': `[data-cy="rs-selbststaendigkeit-checkbox-group"]`,
  'RS Eingabe Selbststaendigkeit Message': `[data-cy="rs-selbststaendigkeit-info-message"]`,
  'RS Eingabe Selbststaendigkeit Partner Oder Kind Message': `[data-cy="rs-selbststaendigkeit-partner-oder-kind-info-message"]`,
  'RS Eingabe Selbststaendigkeit Single Message': `[data-cy="rs-selbststaendigkeit-single-info-message"]`,

  'RS Eingabe Oeffentlicher Dienst Checkbox': `[data-cy="rs-oeffentlicher-dienst-checkbox"]`,
  'RS Eingabe Oeffentlicher Dienst Error Required': `[data-cy="rs-offentlicher-dienst-error-required"]`,

  'RS Eingabe Selbstsaendig Checkbox': `[data-cy="rs-selbststaendig-checkbox"]`,

  'RS Eingabe Geschaeftsfuehrer Vorstand Checkbox': `[id="geschaeftsfuehrer"]`,

  'RS Eingabe Rechtsstreitigkeiten Radio': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-radio"]`,
  'RS Eingabe Rechtsstreitigkeiten Radio Ja': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-radio-ja"]`,
  'RS Eingabe Rechtsstreitigkeiten Radio Nein': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-radio-nein"]`,
  'RS Eingabe Rechtsstreitigkeiten Radio Error Required': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-required-error-msg"]`,

  'RS Eingabe Rechtsstreitigkeiten Stepper': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-anzahl-stepper"]`,
  'RS Eingabe Rechtsstreitigkeiten Stepper Input': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-anzahl-stepper"] input`,
  'RS Eingabe Rechtsstreitigkeiten Stepper Error Required': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-number-required-error-msg"]`,
  'RS Eingabe Rechtsstreitigkeiten Ueberschritten Error Message': `[data-cy="rs-basisangaben-rechtsstreitigkeiten-uberschritten-error-msg"]`,

  'RS Eingabe Zurueck zum Shop': `[data-cy="rs-navigateToDashboard-link"]`,

};
