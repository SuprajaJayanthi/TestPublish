export const selectorMapping = {
  'Dashboard Karte Angebot': '[data-cy="dashboard-produkt-karte-rs-angebot"]',
  'Dashboard Angebotsuebersicht RS':
    '[data-cy="dashboard-uebersicht-angebote-rs-angebot"]',
  'RS Angebot Selbstbeteiligung Dropdown':
    '[data-cy="global-vertragsoption-selbstbeteiligung"]',
  'RS Eingabe Page': 'rs-angebot-eingabe',
  'RS Angebot Page': 'rs-angebot-angebot',
  'RS Angebot Button': '[data-cy="rs-angebot-button"]',
  'RS Kombischutz': '[data-cy="rs-kombischutz"]',
  'RS Verkehrsrechtschutz': '[data-cy="rs-verkehrsrechtschutz"]',
  'RS Kombischutz Angebot Selbstbeteiligung Dropdown':
    '[data-cy="rs-kombi-selbstbeteiligung"]',
  'RS Kombischutz Angebot Selbstbeteiligung Dropdown Item': 'nx-dropdown-item',
  'RS Kombischutz Icon': '[data-cy="rs-kombischutz"]',
  'RS Verkehrsrechtschutz Icon': '[data-cy="rs-verkehrsrechtschutz"]',
  'RS Verkehrsrechtschutz Angebot Selbstbeteiligung Dropdown':
    '[data-cy="rs-fahrzeug-selbstbeteiligung"]',
  'RS Verkehrsrechtschutz Anzahl Fahrzeuge Dropdown':
    '[data-cy="rs-vertragsoption-fahrzeuge"]',
  'RS Verkehrsrechtschutz Fahrzeugart Dropdown':
    '[data-cy="rs-vertragsoption-fahrzeugart"]',

  'RS Angebot Hinweis Rechtsstreitigkeiten':
    '[data-cy="rs-hinweis-rechtstreitigkeiten-zu-hoch"]',

  'RS Kombischutz Komfort Beruf Auswahl Zelle': `[data-cy="rs_Komfort_beruf_auswahl_zelle"]`,
  'RS Kombischutz Komfort Beruf Auswahl Icon': `[data-cy="rs_Komfort_beruf_auswahl_zelle_open_modal_icon"]`,
  'RS Kombischutz Komfort Beruf Inklusive Checkbox': `[data-cy="rs_Komfort_beruf_auswahl_zelle_inclusive_checkbox"]`,
  'RS Kombischutz Komfort Beruf Uebernehmen Button': `[data-cy="rs_Komfort_beruf_auswahl_zelle_uebernehmen_button"]`,
  'RS Kombischutz Komfort Beruf Popover': `[data-cy="rs_Komfort_beruf_auswahl_zelle_popover_content"]`,

  'RS Kombischutz Komfort Verkehr Auswahl Zelle':
    '[data-cy="rs_Komfort_verkehr_auswahl_zelle"]',
  'RS Kombischutz Komfort Verkehr Auswahl Icon':
    '[data-cy="rs_Komfort_verkehr_auswahl_zelle_open_modal_icon"]',
  'RS Kombischutz Komfort Verkehr Inklusive Checkbox':
    '[data-cy="rs_Komfort_verkehr_auswahl_zelle_inclusive_checkbox"]',
  'RS Kombischutz Komfort Verkehr Uebernehmen Button':
    '[data-cy="rs_Komfort_verkehr_auswahl_zelle_uebernehmen_button"]',
  'RS Kombischutz Komfort Verkehr Popover':
    '[data-cy="rs_Komfort_verkehr_auswahl_zelle_popover_content"]',

  'RS Kombischutz Premium Beruf Auswahl Zelle':
    '[data-cy="rs_Premium_beruf_auswahl_zelle"]',
  'RS Kombischutz Premium Beruf Auswahl Icon':
    '[data-cy="rs_Premium_beruf_auswahl_zelle_open_modal_icon"]',
  'RS Kombischutz Premium Beruf Inklusive Checkbox':
    '[data-cy="rs_Premium_beruf_auswahl_zelle_inclusive_checkbox"]',
  'RS Kombischutz Premium Beruf Uebernehmen Button':
    '[data-cy="rs_Premium_beruf_auswahl_zelle_uebernehmen_button"]',
  'RS Kombischutz Premium Beruf Popover':
    '[data-cy="rs_Premium_beruf_auswahl_zelle_popover_content"]',

  'RS Angebot Zusatzoptionen Strafrechtschutz':
    '[data-cy="rs-angebot-zusatzoption-strafrechtschutz"]',
  'RS Angebot Zusatzoptionen Vermieter':
    '[data-cy="rs-angebot-zusatzoption-vermieter"]',
  'RS Auslaendische Adresse Checkbox':
    '[data-cy="rs-auslaendische-adresse"]',
  'RS Unbebaut Radio Button':
    '[data-cy="rs-vermietetes-objekt-bebaut-radio-nein-0"]',
  'RS Vermieter Plz Input':
    '[data-cy="rs-vermieter-plz-input-0"]',
  'Nx-formfield':
    'nx-formfield',
  'RS Zusatzoption VermieteteObjekte Uebernehmen Button':
    '[data-cy="rs-angebot-vermietete-objekte-uebernehmen-button"]',
  'RS Zusatzoption VermieteteObjekte bearbeiten':
    '[data-cy="vermietete-objekte-anpassen-link"]',
  'RS Zusatzoption Vermietetes Objekt hinzufuegen':
    '[data-cy="vermietetes-objekt-hinzufuegen-link"]',
  'RS Zusatzoption Vermietete Objekte Warnung':
    '[data-cy="vermietete-objekte-gehen-verloren-warning"]',
  'RS Frontend Adress Input Component':
    'ps20-frontend-adress-input-component',
  'RS Input Element Flaeche des Grundstuecks' :
    '[title="Fläche des Grundstücks"]',
  'RS Angebot Vermietete Objekte Uebernehmen Button':
    '[data-cy="rs-angebot-vermietete-objekte-uebernehmen-button"]',

  'RS Angebot uebernehmen': '[id="weiter-zum-antrag-button"]',
  ...generateVermietetesObjektSelectoren(0),
  ...generateVermietetesObjektSelectoren(1),
  ...generateVermietetesObjektSelectoren(2),
  ...generateVermietetesObjektSelectoren(3),
  ...generateVermietetesObjektSelectoren(4),
  ...generateVermietetesObjektSelectoren(5),
  ...generateVermietetesObjektSelectoren(6),
  ...generateVermietetesObjektSelectoren(7),
  ...generateVermietetesObjektSelectoren(8),
};

function generateVermietetesObjektSelectoren(index) {
  return {
    [`RS Zusatzoption Vermietetes Objekt PLZ Input ${index}`]: `[data-cy="rs-vermieter-plz-input-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt PLZ Input ${index} Required Error`]: `[data-cy="rs-vermieter-plz-input-${index}-required-error"]`,
    [`RS Zusatzoption Vermietetes Objekt PLZ Input ${index} Pattern Error`]: `[data-cy="rs-vermieter-plz-input-${index}-pattern-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Ort Input ${index}`]: `[data-cy="rs-vermieter-ort-${index}-adress-input"]`,
    [`RS Zusatzoption Vermietetes Objekt Ort Input ${index} Required Error`]: `[data-cy="rs-vermieter-ort-${index}-adress-input-required-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Ort Input ${index} Pattern Error`]: `[data-cy="rs-vermieter-ort-${index}-adress-input-pattern-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Ort DisabledInput ${index}`]: `[data-cy="rs-vermieter-ort-${index}-adress-input-disabled"]`,
    [`RS Zusatzoption Vermietetes Objekt Ort Dropdown ${index}`]: `[data-cy="rs-vermieter-ort-${index}-adress-input-dropdown"]`,
    [`RS Zusatzoption Vermietetes Objekt Ort Dropdown ${index} Required Error`]: `[data-cy="rs-vermieter-ort-${index}-adress-input-dropdown-required-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Strasse Input ${index}`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input"]`,
    [`RS Zusatzoption Vermietetes Objekt Strasse Input ${index} Required Error`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input-required-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Strasse Input ${index} Pattern Error`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input-pattern-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Strasse DisabledInput ${index}`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input-disabled"]`,
    [`RS Zusatzoption Vermietetes Objekt Strasse Dropdown ${index}`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input-dropdown"]`,
    [`RS Zusatzoption Vermietetes Objekt Strasse Dropdown ${index} Required Error`]: `[data-cy="rs-vermieter-strasse-${index}-adress-input-dropdown-required-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Hausnummer Input ${index}`]: `[data-cy="rs-vermieter-hausnummer-input-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Hausnummer Input ${index} Required Error`]: `[data-cy="rs-vermieter-hausnummer-input-${index}-required-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Hausnummer Input ${index} Pattern Error`]: `[data-cy="rs-vermieter-hausnummer-input-${index}-pattern-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Bebaut Radio Ja ${index}`]: `[data-cy="rs-vermietetes-objekt-bebaut-radio-ja-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Bebaut Radio Nein ${index}`]: `[data-cy="rs-vermietetes-objekt-bebaut-radio-nein-${index}"]`,

    [`RS Zusatzoption Vermietetes Objekt Wohneinheiten Stepper ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-wohneinheiten-stepper-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Wohneinheiten Stepper ${index} Input`]: `[data-cy="rs-vermietetes-objekt-anzahl-wohneinheiten-stepper-${index}"] input`,
    [`RS Zusatzoption Vermietetes Objekt Wohneinheiten Input ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-wohneinheiten-textfield-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Wohneinheiten Input Required Error ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-wohneinheiten-textfield-${index}-required-error"]`,
    [`RS Zusatzoption Vermietetes Objekt Wohneinheiten Input Pattern Error ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-wohneinheiten-textfield-${index}-pattern-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Gewerbeeinheiten Stepper ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-gewerbeeinheiten-stepper-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Gewerbeeinheiten Stepper ${index} Input`]: `[data-cy="rs-vermietetes-objekt-anzahl-gewerbeeinheiten-stepper-${index}"] input`,
    [`RS Zusatzoption Vermietetes Objekt Gewerbeeinheiten Input ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-gewerbeeinheiten-textfield-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Gewerbeeinheiten Input Required Error ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-gewerbeeinheiten-textfield-${index}-required-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Stellplaetze Stepper ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-stellplaetze-stepper-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Stellplaetze Stepper ${index} Input`]: `[data-cy="rs-vermietetes-objekt-anzahl-stellplaetze-stepper-${index}"] input`,
    [`RS Zusatzoption Vermietetes Objekt Stellplaetze Input ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-stellplaetze-textfield-${index}"]`,
    [`RS Zusatzoption Vermietetes Objekt Stellplaetze Input Required Error ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-stellplaetze-textfield-${index}-required-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Anzahl Error ${index}`]: `[data-cy="rs-vermietetes-objekt-anzahl-${index}-required-error"]`,

    [`RS Zusatzoption Vermietetes Objekt Grundstueckflaeche Input ${index}`]: `[data-cy=rs-vermieter-grundstueckflaeche-input-${index}]`,
    [`RS Zusatzoption Vermietetes Objekt Grundstueckflaeche Input Pattern Error ${index}`]: `[data-cy=rs-vermieter-grundstueckflaeche-input-${index}-pattern-error]`,
    [`RS Zusatzoption Vermietetes Objekt Grundstueckflaeche Input Required Error ${index}`]: `[data-cy=rs-vermieter-grundstueckflaeche-input-${index}-required-error]`,
    [`RS Zusatzoption Vermietetes Objekt Löschen ${index}`]: `[data-cy=rs-delete-vermietetes-objekt-${index}]`,

    [`RS Zusatzoption Vermietetes Objekt Flurstücknummer Input ${index}`]: `[data-cy=rs-vermieter-flurstuecknummer-input-${index}]`,
    [`RS Zusatzoption Vermietetes Objekt Flurstücknummer Required Error ${index}`]: `[data-cy=rs-vermieter-flurstuecknummer-input-${index}-required-error]`,
    [`RS Zusatzoption Vermietetes Objekt Flurstücknummer Pattern Error ${index}`]: `[data-cy=rs-vermieter-flurstuecknummer-input-${index}-pattern-error]`,
  };
}
