export const selectorMapping = {
  'Gegenstandsschutz Angebot zurueck zum Shop':           '[data-cy="gege-navigateToDashboard-link"]',
  'Gegenstandsschutz Angebot Angebot':                    'gege-angebot-angebot',
  'Gegenstandsschutz Angebot Vertragsoptionen':            'gege-angebot-vertragsoptionen',
  'Gegenstandsschutz Angebot Uebernehmen Button':         '[id="weiter-zum-antrag-button"]',
  'Gegenstandsschutz Angebot Zusammenfassung Section':    '[id="zusammenfassung"]',
  'Gegenstandsschutz Angebot Weiter zum Antrag Button':   '#weiter-zum-antrag-button',
  'Gegenstandsschutz Angebot Selbstbeteiligung Dropdown': '[data-cy="global-vertragsoption-selbstbeteiligung"]',

  'Gegenstandsschutz Kategorie of Gegenstand': (index) => `[data-cy="gegenstand-category-${index}"] span`,
  'Gegenstandsschutz Kaufpreis of Gegenstand': (index) => `[data-cy="gegenstand-versicherungssumme-${index}"]`,
  'Gegenstandsschutz Kaufdatum of Gegenstand': (index) => `[data-cy="gegenstand-kaufdatum-${index}"]`,
};
