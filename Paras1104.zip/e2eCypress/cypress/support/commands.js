import { addMatchImageSnapshotCommand } from 'cypress-image-snapshot/command';
import { format } from 'date-fns';

let vorgangsId;
let currentTestcase;
let currentEnv = 'local';
let latestBffVersionFromJwtResponse;

const disableableElements = [
  'input',
  'button',
  'select',
  'textarea',
  'button',
  'object',
];

addMatchImageSnapshotCommand({
  customSnapshotsDir: 'cypress/visual-regression-screenshots',
  failureThreshold: 0.00001,
  failureThresholdType: 'percent',
  customDiffConfig: {
    threshold: 0.01,
  },
  capture: 'viewport',
  disableTimersAndAnimations: true,
  scale: true,
  clip: {
    x: 0,
    y: 0,
    width: 730,
    height: 3000,
  },
  blackout: [
    '[data-cy="versicherungsbeginn"] input',
    '[data-cy="label_antragsnummer"]',
    '[data-cy="textfield_vbeginn"]',
    '[data-cy="datefield_ablaufdatum"]',
    '[data-cy="datefield_antragsstellungsDatum"]',
    '[data-cy="datefield_beratungsdatum"]',
  ],
});

const mockedEinstiegBodyForJuristischePerson = {
  "versicherungsnehmer": {
    "anrede": "FIRMA",
    "firmenname": "Unternehmensschutz AG",
    "businessForm": {
      "wert": "01F",
      "text": "AG"
    },
    "juristisch": true,
    "geburtsdatum": "1900-01-01",
    "kundenverwaltungID": "F512B7D9750411EBA72600A0C6000025",
    "kommunikationsdaten": [{
      "wert": "lala@allianz.de",
      "kommunikationsArt": "EMAIL",
    }],
    "bankverbindungen": [],
    "adresse": {
      "plz": "85774",
      "ort": "Unterföhring",
      "strasse": "Dieselstr.",
      "hausnummer": "6",
      "land": {
        "wert": "DE",
        "text": "Deutschland"
      },
      "ortsteil": "",
      "hausnrzus": "",
      "validierungsStatus": "OK",
      "adresszusatz": "",
    },
  },
  "vertreter": {
    "vorname": "ABS",
    "nachname": "AMIS",
    "personId": "117FEE54C20A11E1BD87112000D9231E",
    "vermittlernummern": [{
      "vertreternummer": "1606",
      "geschaeftsstelle": "150",
      "zweigniederlassung": "10",
      "vermittlerFom": "NONE"
    }],
    "defaultVermittlernummer": {
      "vertreternummer": "1606",
      "geschaeftsstelle": "150",
      "zweigniederlassung": "10",
      "vermittlerFom": "NONE"
    },
    "bnrbs": ["", "1111"],
    "role": "VERTRETER"
  }
};

function isFocusable($element) {
  const nodeName = $element.prop('nodeName').toLowerCase();
  return (
    (nodeName === 'a' ||
      Boolean($element.attr('tabindex')) ||
      (disableableElements.includes(nodeName) && $element.is(':enabled'))) &&
    $element.is(':visible')
  );
}

function isTabbable($element) {
  const tabIndex = $element.attr('tabindex');
  return (!tabIndex || parseInt(tabIndex, 10) >= 0) && isFocusable($element);
}

function nextTabbable($referenceElement, direction = 'forward') {
  if (!(direction === 'forward' || direction === 'backward')) {
    throw new Error('Expected direction to be forward or backward');
  }

  const stack = [];
  let element;

  // Queue up all siblings and our ancestor's siblings.
  const siblingProp =
    direction === 'forward' ? 'nextElementSibling' : 'previousElementSibling';
  element = $referenceElement.get(0);
  while (element) {
    let sibling = element[siblingProp];
    while (sibling) {
      stack.unshift(sibling);
      sibling = sibling[siblingProp];
    }
    element = element.parentElement;
  }

  // Find a tabbable element among our siblings using depth first search.
  while (stack.length > 0) {
    element = stack.pop();

    const $candidateElement = $referenceElement.constructor(element);
    if (isTabbable($candidateElement)) {
      return $candidateElement;
    }

    let children = Array.from(element.children);
    if (direction === 'forward') {
      children = children.reverse();
    }
    children.forEach((child) => {
      stack.push(child);
    });
  }

  return $referenceElement.constructor();
}

Cypress.on('window:before:load', (window) => {
  const original = window.addEventListener;
  window.addEventListener = (...args) => {
    if (args && args[0] === 'beforeunload') {
      return null;
    }
    return original.apply(this, args);
  };
});

Cypress.Commands.add(
  'tab',
  {
    prevSubject: 'optional',
  },
  ($subject, direction = 'forward', options = {}) => {
    const thenable = $subject
      ? cy.wrap($subject, {
        log: false,
      })
      : cy.focused({
        log: options.log !== false,
      });
    thenable
      .then(($el) => nextTabbable($el, direction))
      .then(($el) => {
        if (options.log !== false) {
          Cypress.log({
            $el,
            name: 'tab',
            message: direction,
          });
        }
      })
      .focus({
        log: false,
      });
  }
);

Cypress.Commands.add(
  'typeWithTabSupport',
  {
    prevSubject: true,
  },
  (subject, text) => {
    const textBetweenTab = text.split(/({tab})/);

    for (const textToType of textBetweenTab) {
      if (textToType && textToType !== '{tab}') {
        cy.wrap(subject).type(textToType);
      } else if (textToType && textToType === '{tab}') {
        cy.tab();
      }
    }
  }
);

Cypress.Commands.overwrite('contains', (...args) => {
  const [originalFn, subject, filter, text, options] = args;

  // if we get less then 5 arguments passed, that means we don't get a child selector. Without a child selector we can't check the value of the child element.
  // if we get more than 5 arguments passed, we get an unexpected input. In that case just call the original function without doing any custom logic.
  if (args.length === 5) {
    let target_element = null;
    if (subject) {
      target_element = subject.find(filter);
    } else {
      target_element = Cypress.$(filter);
    }

    const testValue = () => {
      if (
        typeof target_element.val === 'function' &&
        typeof target_element.val() === 'string' &&
        target_element.val().match(text)
      ) {
        return target_element;
      }
      return Cypress.$(null);
    };

    const retryFunction = () =>
      cy.verifyUpcomingAssertions(testValue(), options, {
        onRetry: retryFunction,
        onFail: (err) => {
          err.displayMessage = `To find text '${text}' inside of ${filter}`;
        },
      });

    // if the element is an input or textarea element, use our custom check for input values, otherwise call the original function
    if (target_element.is('input:text') || target_element.is('textarea')) {
      return retryFunction();
    }

    return originalFn(...args.slice(1));
  }

  // remove first argument which is the original function itself and pass everything to the original function
  return originalFn(...args.slice(1));
});

const capitalize = (str) => {
  if (typeof str !== 'string') {
    return '';
  }
  const s = str.toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export const startServer = () => {
  cy.intercept('POST', '/privatschutz/api/sofortschutzAvailable').as('sofortschutzAvailable');
  cy.intercept('POST', '/privatschutz/api/zaehlstuecke').as('zaehlstuecke');
  cy.intercept('GET', '/privatschutz/api/authenticate').as('authenticate');
  cy.intercept('POST', 'privatschutz/api/esign/upload/async').as('esignUpload');
  cy.intercept('POST', 'privatschutz/api/taas/vwg').as('vwgTaasCall');
  cy.intercept('POST', 'privatschutz/api/taas/ph').as('phTaasCall');
  cy.intercept('POST', 'privatschutz/api/bankService').as('bankservice');
  cy.intercept('POST', 'privatschutz/api/amiscrmsucheImmobilien').as('amiscrmsucheImmobilien');

  cy.intercept('privatschutz/api/einreichen/async',
    (req) => {
      // Save Antragsnummer
      cy.now('readFile', 'cypress/results/antragsnummern.json').then((json) => {
        if (!json) {
          json = {};
        }
        const currentTime = format(new Date(), 'yyyy-MM-dd_hh-mm-ss');
        json[currentTime] = [];
        req.body.sparten.forEach((sparte) => {
          json[currentTime].push({
            testcase: currentTestcase,
            sparte: sparte.spartenType,
            antragsnummer: sparte.antragsId,
          });
          console.log(
            `Antragsnummer ${sparte.spartenType}: ${sparte.antragsId}`
          );
        });
        cy.now('writeFile', 'cypress/results/antragsnummern.json', json);
      });
    }).as('einreichen');

  cy.intercept('privatschutz/api/dokumentenerstellung',
    (req) => {
      const myReader = new FileReader();
      const dokument = req.body.dokumentDruckdaten.dokument;
      const vertragsschlussverfahren = capitalize(
        req.body.vertragsschlussverfahren
      );

      myReader.onloadend = () => {
        const fileName = `${format(
          new Date(),
          'yyyy-MM-dd_HH-mm-ss'
        )}_${currentTestcase}_${dokument}_${vertragsschlussverfahren}.pdf`;
        const filePath = `cypress/results/${format(
          new Date(),
          'yyyy-MM-dd'
        )}/${currentTestcase}/`;

        cy.now('writeFile', filePath + fileName, myReader.result, 'binary');
      };
      req.continue((res) => {
        const blob = new Blob([res.body], { type: 'binary' });
        myReader.readAsBinaryString(blob)
      });
    }).as('dokumentenerstellung');

  cy.intercept('/privatschutz/api/domaenenService', {
    method: 'POST',
    body: {}
  }).as('domaenenService');
};

export const createAmisId = () => {
  let dt = new Date().getTime();
  return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/x/g, (c) => {
    const r = (dt + Math.random() * 16) % 16 | 0;
    dt = Math.floor(dt / 16);
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
};

export const startAppAsJuristischePerson = () => {
  cy.request('GET', '/privatschutz/api/authenticate', {
    role: 'vertreter',
    anonym: true,
  }).then((response) => {
      cy.fixture('sonstiges/assekuranztarif/amiscrm').then(() => {
        cy.intercept('privatschutz/api/einstieg', {
          method: 'POST',
          headers: {
            'x-ps20-bff-version': response.headers['x-ps20-bff-version'],
          },
          body: mockedEinstiegBodyForJuristischePerson,
        }).as('amiscrm');
      });
    }
  );

  cy.viewport(1400, 1600).then(() => {
    startApp();
  });

  return null;
}


export const startApp = (aid = null, pid = null, crypdId = null, url = null, role = 'vertreter') => {
  let crypdIdString = '';
  startServer();

  const vid = createAmisId();
  vorgangsId = vid;

  if (url) {
    cy.visit(url);
    cy.get('[id="ps20-shop-dashboard-gui-app-root"]', {
      timeout: 60000,
    }).should('exist');
    return cy.wait('@amiscrm');
  }

  if (!aid) {
    aid =
      'eyJhbGciOiAiSFMyNTYifQ.eyJhbXNsX2lkIjogInBVeTlVVlJzaHU3bkJGV1gwdkdpVjQ4OEducEdSVE9GZ2ludEFTQlZ0MU09Ii' +
      'wiYW1zbF9pZF9rZXlpZCI6ICJkZXYiLCJhbXNsX2lkX2l2IjogImY1Sm9YYlNSUTFDRFJTclFUZWZyckE9PSIsImV4cGlyZXNfaW4iO' +
      'iAtMSwidG9rZW5fdHlwZSI6ICJhY2Nlc3NfdG9rZW4iLCJhY2Nlc3NfdG9rZW4iOiAiMzM1NjZDRkM3NTBGMTFFQkE3MjYwMEEw' +
      'QzYwMDAwMjUiLCJjbGllbnRfaWQiOiAiU1BSUFMyIn0.CwE6AiLOHp49PZWRJDpydqxQifZbD3fHJNSAj-NFPzY';

  }

  if (!pid) {
    pid = 'D5387D41BD9B11E9A6AB00A0C6000024';
  }

  if (crypdId) {
    crypdIdString = `&cryptid=${crypdId}`;
  }

  let visitUrl = `/?role=${role}&aid=${aid}&pid=${pid}&vorid=${vid}${crypdIdString ? crypdIdString : ''}`;

  if (role !== 'vertreter') {
    visitUrl += `&vtnr=${getVtnr(role)}`;
  }

  if (currentEnv !== 'local') {
    visitUrl = `https://privatschutz-${currentEnv}.allianz.de${visitUrl}`;
  }

  cy.visit(visitUrl);

  if (role === 'vertreter') {
    cy.wait('@authenticate', { timeout: 40000 }).then((xhr) => {
      latestBffVersionFromJwtResponse = xhr.response.headers['x-ps20-bff-version'];
    });
  }

  return null;
};

export const setFeatureToggles = (featureToggle, role = 'vertreter') => {
  cy.request('GET', 'privatschutz/api/authenticate', {
    role: role,
    anonym: true,
  }).then((response) => {
    latestBffVersionFromJwtResponse = response.headers['x-ps20-bff-version'];
    cy.intercept('privatschutz/api/featuretoggles', {
      method: 'GET',
      headers: { 'x-ps20-bff-version': latestBffVersionFromJwtResponse },
      body: featureToggle,
    });
  });
};

export function getVtnr(role) {
  switch (role) {
    case 'geno':
      return '70/464/6810';
    case 'leitender_kundenbetreuer':
    case 'nebenberufsvertreter':
      return '10/076/1000';
    case 'olb':
      return '30/003/6312';
    case 'vtkus':
      return '10/022/1023';
    case 'vttel':
      return '40/562/1415';
    default:
      return '10/220/5002';
  }
}

export function getLatestBffVersionForHeader() {
  return latestBffVersionFromJwtResponse;
}