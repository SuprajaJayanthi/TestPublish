import { defineConfig } from 'cypress';
import createBundler from '@bahmutov/cypress-esbuild-preprocessor';
import { addCucumberPreprocessorPlugin } from '@badeball/cypress-cucumber-preprocessor';
import createEsbuildPlugin from '@badeball/cypress-cucumber-preprocessor/esbuild';

export default defineConfig({
  e2e: {
    specPattern: '**/**/*.feature',
    baseUrl: 'http://localhost:9000',
    chromeWebSecurity: false,
    supportFile: false,
    numTestsKeptInMemory: 0,
    excludeSpecPattern: ['*.json', '*master*'],
    retries: {
      runMode: 4, // Configure retry attempts for `cypress run`
      openMode: 4, // Configure retry attempts for `cypress open`
    },
    async setupNodeEvents(
      on: Cypress.PluginEvents,
      config: Cypress.PluginConfigOptions
    ): Promise<Cypress.PluginConfigOptions> {
      // This is required for the preprocessor to be able to generate JSON reports after each run
      await addCucumberPreprocessorPlugin(on, config);
      on(
        'file:preprocessor',
        createBundler({
          plugins: [createEsbuildPlugin(config)],
        })
      );
      // Make sure to return the config object as it might have been modified by the plugin
      return config;
    },
  },
});
