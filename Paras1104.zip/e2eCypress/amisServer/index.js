const express = require('express');
const fs = require('fs');
const http = require('http');

const PORT = 3000;
const app = express();
const { execSync } = require('child_process');

function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

getRndInteger(100000000000000000000, 999999999999999999999);

app.post('/getUrl/:env/pid/:pidId', (req, res) => {
  pid = req.params.pidId;
  env = req.params.env;
  pid = pid.toUpperCase();
  let pidArr = pid.split('-');
  pid = pidArr.join('');
  http.get(
    'http://localhost:8928/open?client=PS2&a=887FEE54C20A11E1BD87001999C8120D&w=cex83sb&p=' +
      pid +
      '&hamx=132872',
    function (response) {
      // Continuously update stream with data
      let body = '';
      response.on('data', function (d) {
        body += d;
      });
      response.on('end', function () {
        let dynamicAid = '&aid=' + body;
        dynamicAid += '&amisupd=191008';
        dynamicAid += '&pid=' + pid;
        dynamicAid +=
          '&vorid=E2ETESTPS20' +
          getRndInteger(100000000000000000000, 999999999999999999999);

        let loginUrl = 'https://test-ltp.allianz.de/ui/de/nova/login?';
        loginUrl += 'target=8d85b218&autologin=true';
        loginUrl += dynamicAid;

        let testUrl =
          'https://privatschutz-' + env + '.allianz.de/?role=vertreter';
        testUrl += dynamicAid;
        console.log(loginUrl);
        console.log(testUrl);

        // Data reception is done, do whatever with it!
        res.setHeader('Content-Type', 'application/json');
        return res.send(
          JSON.stringify({
            url: testUrl,
          })
        );
      });
    }
  );
});

app.get('/aid', (req, res) => {
  let http = require('http');
  // Kreiere AID auf Person: Dontchangedontdelete Tokengiver - DF354132DEB911E9A7A39CB654A50610
  http.get(
    'http://localhost:8928/open?client=PS2&a=887FEE54C20A11E1BD87001999C8120D&w=cex83sb&p=DF354132DEB911E9A7A39CB654A50610&hamx=132872',
    function (response) {
      // Continuously update stream with data
      let body = '';
      response.on('data', function (d) {
        body += d;
      });
      response.on('end', function () {
        // Data reception is done, do whatever with it!
        let parsed = body;
        res.setHeader('Content-Type', 'application/json');
        return res.send(
          JSON.stringify({
            aid: parsed,
          })
        );
      });
    }
  );
});

app.listen(PORT, () => console.log(`Example app listening on port ${PORT}!`));
