import sqlite3

class PrivacyLevel:
    PUBLIC = 'public'
    PRIVATE = 'private'
    FRIENDS_ONLY = 'friends_only'

def setup_database():
    conn = sqlite3.connect('image_db.sqlite')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS images (
            id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL,
            image_url TEXT NOT NULL,
            privacy TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def set_privacy(image_id, privacy_level):
    conn = sqlite3.connect('image_db.sqlite')
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE images
        SET privacy = ?
        WHERE id = ?
    ''', (privacy_level, image_id))
    conn.commit()
    conn.close()

def get_image_privacy(image_id):
    conn = sqlite3.connect('image_db.sqlite')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT privacy FROM images WHERE id = ?
    ''', (image_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

def can_view_image(user_id, image_id):
    conn = sqlite3.connect('image_db.sqlite')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT privacy, user_id FROM images WHERE id = ?
    ''', (image_id,))
    result = cursor.fetchone()
    conn.close()
    if result:
        privacy, owner_id = result
        if privacy == PrivacyLevel.PUBLIC:
            return True
        elif privacy == PrivacyLevel.PRIVATE and user_id == owner_id:
            return True
        elif privacy == PrivacyLevel.FRIENDS_ONLY:
            return check_friendship(user_id, owner_id)
    return False

def check_friendship(user_id, owner_id):
    return True

setup_database()
set_privacy(1, PrivacyLevel.PUBLIC)
print(get_image_privacy(1))
print(can_view_image(2, 1))
