import os
from PIL import Image

# Function to compress image while maintaining aspect ratio
def compress_image(input_file_path, output_file_path, target_size_kb):
    try:
        # Open the image
        with Image.open(input_file_path) as image:
            # Calculate the scale factor to reduce the file size
            scale_factor = 1.0
            while True:
                # Calculate the quality based on scale factor
                quality = max(15, int((1-scale_factor)*100))
                # Save the image to output path with given quality
                image.save(output_file_path, quality=quality, optimize=True)
                # Check the file size
                file_size_kb = os.path.getsize(output_file_path) / 1024
                if file_size_kb <= target_size_kb:
                    break
                scale_factor *= 0.9

        print(f"Image compressed and saved at: {output_file_path}")
    except Exception as e:
        print(f"Failed to compress image: {e}")

# Example usage: Compress an image during upload
def upload_and_compress_image(input_file_path, output_directory, target_size_kb=100):
    output_file_path = os.path.join(output_directory, os.path.basename(input_file_path))
    compress_image(input_file_path, output_file_path, target_size_kb)

# Example call
input_file = 'uploads/sample_image.jpg'
output_dir = 'compressed_images/'
os.makedirs(output_dir, exist_ok=True)
upload_and_compress_image(input_file, output_dir)