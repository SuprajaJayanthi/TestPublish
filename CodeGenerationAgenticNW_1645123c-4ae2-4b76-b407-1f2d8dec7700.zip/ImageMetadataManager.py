class ImageMetadataManager:
    def __init__(self):
        # Initialize a dictionary to store images and their metadata
        self.image_metadata = {}

    def upload_image(self, image_id, title, description, tags):
        """
        Upload an image along with its metadata.
        
        :param image_id: Unique identifier for the image
        :param title: Title of the image
        :param description: Description of the image
        :param tags: List of tags associated with the image
        """
        self.image_metadata[image_id] = {
            'title': title,
            'description': description,
            'tags': tags
        }
        print(f"Image {image_id} uploaded with metadata.")

    def edit_metadata(self, image_id, title=None, description=None, tags=None):
        """
        Edit the metadata of an existing image.
        
        :param image_id: Unique identifier for the image
        :param title: (Optional) New title for the image
        :param description: (Optional) New description for the image
        :param tags: (Optional) New list of tags for the image
        """
        if image_id in self.image_metadata:
            if title:
                self.image_metadata[image_id]['title'] = title
            if description:
                self.image_metadata[image_id]['description'] = description
            if tags:
                self.image_metadata[image_id]['tags'] = tags
            print(f"Metadata for image {image_id} updated.")
        else:
            print(f"Image {image_id} not found.")

    def search_images(self, keyword):
        """
        Search for images based on a keyword in the metadata.
        
        :param keyword: The keyword to search for in titles, descriptions, or tags
        :return: List of image IDs that match the keyword
        """
        results = []
        for image_id, metadata in self.image_metadata.items():
            if keyword.lower() in metadata['title'].lower() or \
               keyword.lower() in metadata['description'].lower() or \
               any(keyword.lower() in tag.lower() for tag in metadata['tags']):
                results.append(image_id)
        return results

# Usage example
manager = ImageMetadataManager()
manager.upload_image('img001', 'Sunset', 'A beautiful sunset over the mountains', ['sunset', 'nature'])
manager.edit_metadata('img001', tags=['sunset', 'mountains'])
search_results = manager.search_images('sunset')
print(f"Images matching 'sunset': {search_results}")