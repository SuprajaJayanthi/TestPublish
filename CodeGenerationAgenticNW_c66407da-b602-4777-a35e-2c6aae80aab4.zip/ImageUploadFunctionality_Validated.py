from flask import Flask, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.errorhandler(500)
def internal_error(error):
    return "500 error: Something went wrong", 500

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    try:
        if request.method == 'POST':
            if 'file' not in request.files:
                return 'No file part', 400

            file = request.files['file']

            if file.filename == '':
                return 'No selected file', 400

            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                if not os.path.exists(app.config['UPLOAD_FOLDER']):
                    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                
                file.save(filepath)
                return redirect(url_for('uploaded_file', filename=filename))

        return render_template('upload.html')

    except Exception as e:
        # logging can be added here for exception details
        return f'An error occurred: {str(e)}', 500

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return f'File uploaded successfully: {filename}'

if __name__ == '__main__':
    # Running in production would require more settings for optimization and security
    app.run(debug=True)
