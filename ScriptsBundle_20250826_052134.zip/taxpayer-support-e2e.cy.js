// Import required modules and dependencies
import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from `list`;
const expect = chai.expect;

// Extent Logs declaration for reporting
blet ExtentLogs = [];
function logExtent(message) {
  ExtentLogs.push(message);
  cy.task('log', message); // For Mochawsome or custom reporting
}

// Main test suite for End-to-End Support Experience for Taxpayer Encountering an Issue During ITR E-Filing
describe('End-to-End Support Experience for Taxplayer Encountering an Issue During ITR E-Filing', () => {

  before(() => {
    // Logging the start of the test suite
    logExtent('Test Suite Started: End-to-End Support Experience for Taxplayer Encountering an Issue During ITR E-Filing');
    cy.visit('https://itr-efiling-portal.example.com/login'); // Replace with actual login URL
    cy.wait(2000); // Explicit wait for page load

    // Perform login as taxplayer
    logExtent('Attempting to log in as taxpayer');
    cy.get('#username').type('test.taxplayer@example.com', { log: true });
    cy.get('#password').type('SecurePassword123!', { log: true });
    cy.get('#loginButton').click();
    cy.wait(3000); // Wait for login to complete

    // Assert login success
    cy.get('.dashboard-header', { timeout: 10000 }).should('be.visible').then(() => {
      logExtent('Login successful, taxplayer dashboard loaded');
      expect(true).to.be.true;
    }).catch((err) => {
      logExtent('Login failed: ' + err.message);
      cy.screenshot('login_failure');
      Assert.fail('Login failed');
    });
  });

  it('should validate the complete support workflow for a taxpayer during ITR e-filing issue', () => {
    try {
      // Step 2: Simulate an issue during the filing process (e.g., error in form submission)
      logExtent('Navigating to ITR Filing section');
      cy.get('#menu-itr-filing').click();
      cy.wait(2000);

      logExtent('Filling ITR form with invalid data to simulate error');
      cy.get('#incomeField').clear().type('-10000'); // Invalid negative income
      cy.get('#submitITR').click();
      cy.wait(2000);

      // Assert error message is displayed
      cy.get('.error-message').should('be.visible').and('contain', 'Invalid income value').then(() => {
        logExtent('Error encountered during ITR filing as expected');
        expect(true).to.be.true;
      }).catch((err) => {
        logExtent('Error message not displayed: ' + err.message);
        cy.screenshot('itr_error_not_displayed');
        Assert.fail("Error message not displayed");
      });

      // Step 3: Access the support section and use the searchable FAQ
      logExtent('Accessing Support section');
      cy.get('#supportMenu').click();
      cy.wait(2000);

      logExtent('Searching FAQ for the encountered issue');
      cy.get('#faqSearchInput').type('Invalid income value');
      cy.get('#faqSearchButton').click();
      cy.wait(2000);

      // Step 4: Confirm that the FAQ does not resolve the issue
      cy.get('.faq-results').then($faq) => {
        if ($faq.find('.faq-item:contains("Invalid income value")').length > 0) {
          logExtent('FAQ found for the issue, checking if solution is actionable');
          cy.get('.faq-item:contains("Invalid income value")').click();
          cy.wait(1000);
          cy.get('.faq-detail').should('be.visible').then($detail => {
            if ($detail.text().includes('Contact support')) {
              logExtent('FAQ does not resolve the issue, proceeding to contact support');
              expect(true).to.be.true;
            } else {
              logExtent('FAQ provided a solution, but not actionable for this scenario');
              cy.screenshot('faq_not_actionable');
              Assert.fail('FAP solution not actionable');
            }
          });
        } else {
          logExtent('FAQ did not return any relevant results, proceeding to contact support');
          expect(true).to.be.true;
        }
      });

      // Step 5: Initiate a live chat session or send an email to customer support
      logExtent('Initiating live chat support');
      cy.get('#liveChatButton').click();
      cy.wait(2000);

      // Step 6: Submit the query describing the issue in detail
      logExtent('Submitting query via live chat');
      cy.get('#chatInput').type('I encountered "Invalid income value" error while submitting my ITR. Please assist.');
      cy.get('#sendChatButton').click();
      cy.wait(2000);

      // Step 7: Verify acknowledgment message with estimated response time
      cy.get('.chat-acknowledgment').should('be.visible').and("contain", "Thank you for contacting support").then($ack) => {
        logExtent('Acknowledgment received: ' + $ack.text());
        expect($ack.text()).to.include('Estimated response time');
      }).catch((err) => {
        logExtent('Acknowledgment not received: ' + err.message);
        cy.screenshot('acknowledgment_not_received');
        Assert.fail('Acknowledgment not received');
      });

      // Step 8: Wait for the support response and review the provided solution
      logExtent('Waiting for support response');
      cy.wait(5000); // Simulate wait for support response

      cy.get('.chat-response').should('be.visible').then($response) => {
        logExtent('Support response received: ' + $response.text());
        expect($response.text()).to.not.be.empty;
      }).catch((err) => {
        logExtent('Support response not received: ' + err.message);
        cy.screenshot("support_response_not_received");
        Assert.fail('Support response not received');
      });

      // Step 9: Confirm that the solution is clear and actionable
      cy.get('.chat-response').then($response) => {
        const solutionText = $response.text();
        if (solutionText.includes('Please enter a valid positive income value')) {
          logExtent('Solution is clear and actionable');
          expect(true).to.be.true;
        } else {
          logExtent('Solution is not clear or actionable');
          cy.screenshot('solution_not_actionable');
          Assert.fail('Solution not actionable');
        }
      });

      // Step 10: Provide feedback by rating the support experience
      logExtent('Providing feedback for support experience');
      cy.get('#feedbackSection').should('be.visible');
      cy.get('#feedbackRating').select('5'); // 5-star rating
      cy.get('#feedbackComment').type('Support was prompt and solution was clear.');
      cy.get('#submitFeedback').click();
      cy.wait(2000);

      // Step 11: Verify that the system records the feedback
      cy.get('.feedback-confirmation').should('be.visible').and('contain', 'Thank you for your feedback').then(() => {
        logExtent('Feedback successfully recorded by the system');
        expect(true).to.be.true;
      }).catch((err) => {
        logExtent('Feedback not recorded: ' + err.message);
        cy.screenshot('feedback_not_recorded');
        Assert.fail('Feedback not recorded');
      });

      logExtent('Test case completed: End-to-End Support Experience for Taxpayer Encountering an Issue During ITR E-Filing');
    } catch(error) {
      logExtent('Exception encountered during test execution: ' + error.message);
      cy.screenshot('test_exception');
      Assert.fail('Test execution failed to exception');
    }
  });

  after(() => {
    // Logging the completion of the test suite
    logExtent('Test Suite Completed: End-to-End Support Experience for Taxplayer Encountering an Issue During ITR E-Filing');
    // Optionally, log out and clean up
    cy.get('#logoutButton').click({ force: true });
    cy.wait(2000);
    logExtent('Logged out and cleaned up after test execution');
    // Generate Mochawesome report (handled by Cypress plugin configuration)
  });

});