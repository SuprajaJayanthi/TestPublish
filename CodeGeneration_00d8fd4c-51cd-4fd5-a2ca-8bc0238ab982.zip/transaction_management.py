class Transaction:
    def __init__(self, account, amount, type):
        self.account = account
        self.amount = amount
        self.type = type

    def process(self):
        if self.type == 'deposit':
            self.account.deposit(self.amount)
        elif self.type == 'withdraw':
            return self.account.withdraw(self.amount)
        else:
            return 'Invalid transaction type'