import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact component={() => <div>Home</div>} />
          <Route path="/login" component={() => <div>Login</div>} />
          <Route path="/register" component={() => <div>Register</div>} />
          <Route path="/transactions" component={() => <div>Transactions</div>} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
