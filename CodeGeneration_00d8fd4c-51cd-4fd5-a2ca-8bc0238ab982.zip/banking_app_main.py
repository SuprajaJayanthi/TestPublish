def main():
    print('Welcome to the Banking Application')

if __name__ == '__main__':
    main()