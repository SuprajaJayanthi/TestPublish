// Cypress Test Suite for Sample Application

describe('Sample Application Test Suite', () => {

    // Setup before each test case
    beforeEach(() => {
        // Visit the base URL of the application
        cy.visit('https://example.com');
    });

    // Teardown after each test case
    afterEach(() => {
        // Custom teardown steps if needed
    });

    // Test Case: Verify Home Page Load
    it('should load the home page successfully', () => {
        // Assertion: Check if the home page contains the expected title
        cy.title().should('include', 'Home - Sample Application');
    });

    // Test Case: User Login
    it('should allow users to login', () => {
        // Enter username and password
        cy.get('#username').type('user1');
        cy.get('#password').type('password123');

        // Submit the login form
        cy.get('form').submit();

        // Assertion: Verify successful login
        cy.url().should('include', '/dashboard');
        cy.get('.welcome-message').should('contain', 'Welcome, user1');
    });

    // Test Case: Form Submission with Error Handling
    it('should handle errors during form submission', () => {
        // Enter invalid email in form
        cy.get('#email').type('invalid-email');

        // Submit the form
        cy.get('#form-submit').click();

        // Assertion: Ensure error message is displayed
        cy.get('.error-message').should('contain', 'Please enter a valid email address');
    });

    // Performance Test: Ensure Quick Load Time
    it('should load the dashboard quickly', () => {
        const loadThreshold = 2000; // Expected load time in milliseconds

        // Measure page load time
        cy.intercept('GET', '**/dashboard')
            .as('dashboardLoad');

        cy.visit('/dashboard');
        cy.wait('@dashboardLoad').its('response').then((response) => {
            assert.isBelow(response.duration, loadThreshold, 'Dashboard load time is acceptable');
        });
    });
});