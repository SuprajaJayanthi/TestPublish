-- Database Schema for Customer Dashboard

-- Table for storing customer information
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    CreatedDate DATETIME
);

-- Table for storing transaction information
CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY,
    CustomerID INT,
    TransactionDate DATETIME,
    Amount DECIMAL(10, 2),
    Description VARCHAR(255),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Sample indexes for quick data retrieval
CREATE INDEX idx_customer_transactions ON Transactions(CustomerID, TransactionDate);
