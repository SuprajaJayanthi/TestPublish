# Customer Dashboard

## Overview
This project provides a dashboard for customers to view recent transactions and easily track their spending habits.

## Directory Structure
- **backend/**: Contains backend files including the database schema.
- **frontend/**: Contains frontend files for the user interface.

## Database Schema
- Defined in `backend/database_schema.sql` with tables for `Customers` and `Transactions`.
- Indexes are created for efficient data retrieval related to customer transactions.

## Getting Started
1. Set up the database using the provided schema.
2. Implement the backend services to manage transaction data.
3. Develop the frontend interface to display transaction details on a dashboard.

## Note
Ensure all necessary dependencies are installed and configured for both frontend and backend services.