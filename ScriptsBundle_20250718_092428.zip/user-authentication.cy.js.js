import { cy, before, after } from 'cypress';
import { assert } from 'chai';
import _ from 'lodash';
import { List } from 'cypress';

describe('User Authentication Tests', () => {
  let validUsername = 'validUser';
  let validPassword = 'validPass';
  let invalidUsername = 'invalidUser';
  let invalidPassword = 'invalidPass';

  before(() => {
    cy.log('Starting User Authentication Test Suite');
    // Initialize Extent Logs
  });

  after(() => {
    cy.log('Completed User Authentication Test Suite');
    // Finalize Extent Logs
  });

  it('Validates login with correct credentials', () => {
    cy.log('Test Case: Validate login with correct credentials');
    cy.visit('https://onlinebanking.com/login');
    cy.get('#username').type(validUsername);
    cy.get('#password').type(validPassword);
    cy.get('#loginButton').click();
    cy.wait(1000);
    cy.url().should('include', '/dashboard');
    cy.log('Successfully logged in with valid credentials');
    cy.get('#logoutButton').click();
    cy.log('Logged out successfully');
  });

  it('Validates login with incorrect credentials', () => {
    cy.log('Test Case: Validate login with incorrect credentials');
    cy.visit('https://onlinebanking.com/login');
    cy.get('#username').type(invalidUsername);
    cy.get('#password').type(invalidPassword);
    cy.get('#loginButton').click();
    cy.wait(1000);
    cy.get('.error-message').should('be.visible');
    cy.log('Error message displayed for invalid credentials');
  });

  it('Validates account lockout after multiple failed attempts', () => {
    cy.log('Test Case: Validate account lockout after multiple failed attempts');
    cy.visit('https://onlinebanking.com/login');
    for (let i = 0; i < 5; i++) {
      cy.get('#username').type(invalidUsername);
      cy.get('#password').type(invalidPassword);
      cy.get('#loginButton').click();
      cy.wait(1000);
      cy.get('.error-message').should('be.visible');
      cy.log(`Attempt ${i}: Failed login with invalid credentials`);
    }
    // Assert that account is locked after multiple failed login attempts
  });
});
