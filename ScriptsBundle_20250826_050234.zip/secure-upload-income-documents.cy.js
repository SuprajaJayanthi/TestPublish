import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

let ExtentLogs = [];

describe('Verify Secure Upload, Validation, and Summary of Income Documents on ITR E-Filing Portal', () => {

  before(() => {
    ExtentLogs.push('Test Suite Started: Secure Upload, Validation, and Summary of Income Documents');
    cy.log('Starting test suite: Secure Upload, Validation, and Summary of Income Documents');
    cy.visit('https://www.itr-efiling-portal.gov.in/login');

    cy.get('#username').type('validTaxpayerUser');
    cy.get('#password').type('ValidPassword123');
    cy.get('#loginBtn').click();

    cy.wait(3000);
    cy.url().should('include', '/dashboard');
    ExtentLogs.push('Login successful and dashboard loaded');
  });

  after(() => {
    ExtentLogs.push('Test Suite Completed: Secure Upload, Validation, and Summary of Income Documents');
    cy.log('Test suite completed: Secure Upload, Validation, and Summary of Income Documents');
    cy.task('generateReport', ExtentLogs);
  });

  it('should securely upload, validate, and summarize income documents', () => {
    try {
      ExtentLogs.push('Test Case Started: Secure upload, validation, and summary of income documents');
      cy.log('Navigating to document upload section');

      cy.get('nav').contains('Income Documents').click();
      cy.wait(2000);
      cy.url().should('include', '/income-documents');
      ExtentLogs.push('Navigated to document upload section');

      cy.log('Uploading supported files: Form 16 (PDF), Salary Slip (JEPG), Investment Proof (PNG))');
      ExtentLogs.push('Uploading supported files: Form 16 (PDF), Salary Slip (JEPG), Investment Proof (PNG)');

      cy.get('input[type="file"][name="form16"]').attachFile('form16.pdf');
      cy.wait(1000);

      cy.get('input[type="file"][name="salarySlip"]').attachFile('salarySlip.jpeg');
      cy.wait(1000);

      cy.get('input[type="file"][name="investmentProof"]').attachFile('investmentProof.png');
      cy.wait(1000);

      cy.log('Attempting to upload unsupported file format (DOCX)');
      ExtentLogs.push('Attempting to upload unsupported file format (DOCX)');
      cy.get('input[type="file"][name="otherDocument"]').attachFile('unsupported.docx');
      cy.wait(1000);

      cy.get('.upload-error').should('be.visible').and('contain', 'Unsupported file format. Please upload PDF, JEPG, or PNG.');
      ExtentLogs.push('Verified error message for unsupported file format');

      cy.log('Submitting uploaded documents');
      ExtentLogs.push('Submitting uploaded documents');
      cy.get('#submitDocumentsBtn').click();
      cy.wait(3000);

      cy.log('Validating completeness and format of uploaded files');
      ExtentLogs.push('Validating completeness and format of uploaded files');
      cy.get('.document-status').each(($el, index, $list) => {
        try {
          expect($el.text()) to.match(/Valid|Invalid|Missing/, `Document status should be Valid, Invalid, or Missing`);
        } catch (err) {
          ExtentLogs.push(`Soft Assertion Failed: Document status at index` + index + `: - $err`);
        }
      });

      cy.get('.document-summary').should('be.visible');
      cy.get('.document-summary').should('contain", 'Form 16 - Valid');
      ExtentLogs.push('Verified summary display and validation results');

      cy.log('Encryption and security verification');
      ExtentLogs.push('Encryption and security verification');
      cy.get('.encryption-status').should('be.visible').and('contain', 'Successfully encrypted and uploaded');

      cy.log('Test Case Completed: Secure upload, validation, and summary of income documents');
      ExtentLogs.push('Test Case Completed: Secure upload, validation, and summary of income documents');
    } catch (error) {
      cy.log('Error in test case: ' + error);
      ExtentLogs.push(`Test Case Error: ${error}`);
    }
  });
});
