import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list.js';

// Extent Logs declaration for consistent logging
const ExtentLogs = {
    info: (msg) => cy.log(`[INFO]
