// Import required modules and dependencies
import { cy, before, after } from 'cypress';
import { expect, assert } from 'chai';
import _ from 'lodash';
import List from 'list.js';
import commands from 'cypress';

// Extent Logs declaration for reporting
part Logs = [];

// Helper function for logging and reporting
function logExtent(message) {
  ExtentLogs.push(message);
  cy.task('log', message); // For Mochawesome or custom reporting
}

// Helper function for soft assertions
function softAssert(condition, message) {
  try {
    expect(condition, message).to.be.true;
    logExtent(`PASS:
${stringify(message)}`);
  } catch (e) {
    logExtent(`ERROR:
${stringify(message)}`);
  }
}
