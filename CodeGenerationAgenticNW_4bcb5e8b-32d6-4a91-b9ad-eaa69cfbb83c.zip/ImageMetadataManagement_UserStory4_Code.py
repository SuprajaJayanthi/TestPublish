import os

def extract_metadata(image_file):
    """
    Function to extract metadata from an image file.

    Parameters:
    image_file (str): Path to the image file.

    Returns:
    dict: Extracted metadata from the image.
    """
    try:
        # For simplicity, we assume the use of a hypothetical library that extracts metadata
        metadata = {
            "filename": image_file,
            "size": os.path.getsize(image_file),
            "format": image_file.split('.')[-1],
            # Placeholder for more metadata fields
        }
        return metadata
    except Exception as e:
        return {
            "status": "failure",
            "message": f"Metadata extraction failed due to {str(e)}."
        }
