def upload_image(image_file):
    """
    Function to upload an image file.

    Parameters:
    image_file (File): The image file to be uploaded.

    Returns:
    dict: Status and message of the upload process.
    """
    try:
        # Assuming the presence of a save_to_storage function that handles the actual storage
        saved_location = save_to_storage(image_file)
        
        return {
            "status": "success",
            "message": f"Image uploaded successfully to {saved_location}."
        }
    except Exception as e:
        return {
            "status": "failure",
            "message": f"Image upload failed due to {str(e)}."
        }

def save_to_storage(file):
    # This function saves the image to a specified location.
    # Placeholder implementation
    # Proper implementation should handle file storage with security and efficiency
    return "/path/to/saved/image"
