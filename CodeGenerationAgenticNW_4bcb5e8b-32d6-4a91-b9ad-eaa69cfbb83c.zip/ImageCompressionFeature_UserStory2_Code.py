from PIL import Image
import os

def compress_image(input_path, output_path, quality=85):
    """
    Function to compress an image and save it to a new location.

    Parameters:
    input_path (str): Path to the input image file.
    output_path (str): Path to save the compressed image.
    quality (int): Quality setting for compression (1 to 100, where 100 is the best quality).
    
    Returns:
    dict: Status and message of the compression process.
    """
    try:
        # Open an image file
        with Image.open(input_path) as img:
            # Compress and save the image
            img.save(output_path, optimize=True, quality=quality)
        
        return {
            "status": "success",
            "message": f"Image compressed and saved to {output_path}.",
            "original_size": os.path.getsize(input_path),
            "compressed_size": os.path.getsize(output_path)
        }
    except Exception as e:
        return {
            "status": "failure",
            "message": f"Image compression failed due to {str(e)}."
        }
