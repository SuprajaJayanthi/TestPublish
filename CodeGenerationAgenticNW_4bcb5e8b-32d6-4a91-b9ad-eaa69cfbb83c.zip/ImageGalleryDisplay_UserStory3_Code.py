def display_image_gallery(images):
    """
    Function to display a gallery of images.

    Parameters:
    images (list of dict): List containing image info with 'url' and 'title'.

    Returns:
    str: HTML content to display the gallery.
    """
    html_content = '<div class="image-gallery">'
    try:
        for image in images:
            html_content += f'<div class="image-item">'
            html_content += f'<img src="{image["url"]}" alt="{image["title"]}" title="{image["title"]}"/>'
            html_content += f'</div>'
        html_content += '</div>'
        return html_content
    except Exception as e:
        return f"<p>Error displaying gallery: {str(e)}</p>"
