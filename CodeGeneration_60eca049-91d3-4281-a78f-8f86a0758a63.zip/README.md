# Banking Application

## Overview
The Banking Application is a simple project that demonstrates the implementation of basic banking functionalities, including user registration and login, using a tech stack that includes Java Spring Boot for the backend, React.js for the frontend, and PostgreSQL as the database.

## Tech Stack
- **Backend**: Java (Spring Boot)
- **Frontend**: React.js
- **Database**: PostgreSQL

## Setup Instructions

### Backend
1. Navigate to the backend directory.
2. Run `./mvnw spring-boot:run` to start the backend server.
3. Ensure PostgreSQL is running and the database is set up using `banking_schema.sql`.

### Frontend
1. Navigate to the frontend directory.
2. Run `npm install` to install necessary dependencies.
3. Run `npm start` to launch the frontend application.

## Endpoints
- POST `/api/register` for user registration.
- POST `/api/login` for user login.

## Notes:
- Ensure to configure the `application.properties` with your PostgreSQL credentials.
- Default credentials: username - `postgres`, password - `your_password`.

## Testing
- Unit tests and integration tests can be executed using `mvn test`.
- Frontend tests can be run using `npm test`.

