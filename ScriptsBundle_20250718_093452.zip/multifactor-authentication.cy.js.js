import { cy, before, after } from 'cypress';
import commands from 'cypress';
import chai from 'chai';
import lodash from 'lodash';
import Assert from 'assert';
import List from 'list';

describe('Multifactor Authentication Process During User Login', () => {
  before(() => {
    cy.log('Starting Multifactor Authentication Test Suite');
    // Initialize Attent Logs
  });

  after(() => {
    cy.log('Completed Multifactor Authentication Test Suite');
    // Finalize Attent Logs
  });

  it('Verify Biometric Recognition Authentication', () => {
    cy.log('Test Case: Verify Biometric Recognition Authentication');
    cy.visit('https://example.com/login'); // Navigate to the login page
    cy.get('#username').type('validUsername'); // Enter valid username
    cy.get('#password').type('validPassword'); // Enter valid password
    cy.get('#loginButton').click(); // Submit the login form

    cy.log('Step: Observe the prompt for multifactor authentication');
    cy.get('#mfaPrompt').should('be.visible'); // Verify MFA prompt is visible

    cy.log('Step: Choose biometric recognition as the authentication method');
    cy.get('#biometricOption').click(); // Select biometric recognition

    cy.log('Step: Provide biometric data for verification');
    cy.get('#biometricInput').type('biometricData'); // Provide biometric data

    cy.log('Step: Verify that the system successfully recognizes the biometric data');
    cy.get('#biometricSuccessMessage').should('contain', 'Biometric recognized'); // Assert biometric recognition

    cy.log('Step: Log out');
    cy.get('logoutButton').click(); // Log out
  });

  it('Verify One-Time Passcode Authentication', () => {
    cy.log('Test Case: Verify One-Time Passcode Authentication');
    cy.visit('https://example.com/login'); // Navigate to the login page
    cy.get('#username').type('validUsername'); // Enter valid username
    cy.get('#password').type('validPassword'); // Enter valid password
    cy.get('#loginButton').click(); // Submit the login form

    cy.log('Step: Observe the prompt for multifactor authentication');
    cy.get('#mfaPrompt').should('be.visible'); // Verify MFA prompt is visible

    cy.log('Step: Choose one-time passcode as the authentication method');
    cy.get('#otpOption').click(); // Select OTP method

    cy.log('Step: Check the registered mobile device or email for the passcode');
    cy.wait(5000); // Explicit wait for passcode delivery

    cy.log('Step: Enter the received passcode into the application');
    cy.get('#otpInput').type('receivedPasscode'); // Enter OTP

    cy.log('Step: Verify that the system accepts the passcode and grants access to the account');
    cy.get('#otpSuccessMessage').should('contain', 'Access granted'); // Assert OTP acceptance

    cy.log('Step: Log out');
    cy.get('logoutButton').click(); // Log out
  });

  // Exception handling and screenshot capture on failure
  Cypress.on('fail', (error, runnable) => {
    cy.screenshot('failure-screenshot');
    throw error; // Rethrow the error to fail the test
  });
});