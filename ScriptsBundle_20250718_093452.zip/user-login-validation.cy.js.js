import { cy, before, after } from 'cypress';
import 'chai';
import 'lodash';
import 'Assert';
import 'List';

// Describe block for User Login Validation
describe("User Login Validation", () => {
  // Logging the start of the test suite
  console.log('Starting User Login Validation Test Suite');

  // Before hook to set up preconditions
  before(() => {
    console.log('Setting up preconditions for the test suite');
    // Navigate to the online banking login page
    cy.visit('https://example.com/login');
  });

  // After hook to clean up after tests
  after(() => {
    console.log('Cleaning up after the test suite');
    // Additional cleanup actions if necessary
  });

  // Test case for valid credentials
  it('should log in with valid credentials', () => {
    console.log('Starting test case: Valid Credentials Login');

    // Enter valid username and password
    cy.get('#username').type('validUser');
    cy.get('#password').type('validPassword');

    // Click the 'Login' button
    cy.get('#loginButton').click();

    // Observe the system's response
    cy.url().should('include', '/dashboard');
    cy.contains('Welcome, validUser').should('be.visible');

    // Log out if login is successful
    cy.get('#logoutButton').click();
    cy.url().should('include', '/login');

    console.log('Completed test case: Valid Credentials Login');
  });

  // Test case for invalid credentials
  it('should not log in with invalid credentials', () => {
    console.log('Starting test case: Invalid Credentials Login');

    // Enter invalid username and/or password
    cy.get('#username').type('invalidUser');
    cy.get('#password').type('invalidPassword');

    // Click the 'Login' button
    cy.get('#loginButton').click();

    // Observe the system's response
    cy.contains('Invalid username or password').should('be.visible');

    console.log('Completed test case: Invalid Credentials Login');
  });

  // Exception handling and screenshot capture
  CUpress.on('fail', (error, runnable) => {
    cy.screenshot();
    throw error;
  });

  // Generate detailed reports using Mochawesome
  // Ensure logging messages are captured in Extent reports
  console.log('Generating test execution reports');
});