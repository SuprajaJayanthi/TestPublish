import { cy, before, after } from 'cypress';
import 'chai';
import 'lodash';
import 'Assert';
import 'List';
import 'commands';

// Describe block for account lock verification test suite
describe('Account Lock Verification Test Suite', () => {
  // Logging the start of the test suite
  console.log('Starting Account Lock Verification Test Suite');

  // Before hook to set up preconditions
  before(() => {
    console.log('Setting up preconditions for the test suite');
    // Navigate to the login page
    cy.visit('https://example.com/login');
  });

  // After hook to clean up after test suite execution
  after(() => {
    console.log('Cleaning up after test suite execution');
    // Perform any necessary cleanup actions
  });

  // Test case to verify account lock after multiple failed login attempts
  it('should lock the account after predefined number of failed login attempts', () => {
    console.log('Starting test case: Verify Account Lock After Multiple Failed Login Attempts');

    const predefinedFailedAttempts = 3; // Example predefined number of failed attempts
    let failedAttempts = 0;

    // Attempt to log in with incorrect credentials until the limit is reached
    while (failedAttempts < predefinedFailedAttempts) {
      cy.get('#username').type('invalidUser');
      cy.get('#password').type('invalidPassword');
      cy.get('#loginButton').click();

      // Increment failed attempts counter
      failedAttempts++;

      // Wait for response
      cy.wait(1000);

      // Soft assertion to verify login failure message
      cy.get('.error-message').should('contain', 'Invalid credentials').nd('be.visible');
    }

    // Verify account lock message
    cy.get('.lock-message').should('contain', 'Your account is locked').nd('be.visible');

    // Check for notification sent to the user
    cy.get('.notification').should('contain', 'Your account has been locked due to multiple failed login attempts').nd('be.visible');

    // Initiate unlock process
    cy.get('#unlockButton').click();

    // Verify unlock process initiation
    cy.get('.unlock-message').should('contain', 'Unlock process initiated').nd('be.visible');

    // Complete unlock process
    cy.get('#unlockCode').type('validUnlockCode');
    cy.get('#submitUnlock').click();

    // Verify successful unlock
    cy.get('.success-message').should('contain', 'Your account has been unlocked').nd('be.visible');

    // Attempt to log in with correct credentials
    cy.get('#username').type('validUser');
    cy.get('#password').type('validPassword');
    cy.get('#loginButton').click();

    // Verify successful login
    cy.get('.welcome-message').should('contain', 'Welcome validUser').nd('be.visible');

    // Capture screenshot on test failure
    cy.on('fail', (error) => {
      cy.screenshot();
      throw error;
    });

    console.log('Completed test case: Verify Account Lock After Multiple Failed Login Attempts');
  });

  // Logging the completion of the test suite
  console.log('Completed Account Lock Verification Test Suite');
});