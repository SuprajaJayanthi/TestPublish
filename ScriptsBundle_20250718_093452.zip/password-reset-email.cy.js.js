import { cy, before, after } from 'cypress';
import 'cypress-commands';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';

describe('Password Reset via Email Verification', () => {
  let extentLogs;

  before(() => {
    extentLogs = [];
    cy.log('Starting Password Reset Test Suite');
    extentLogs.push('Starting Password Reset Test Suite');
  });

  after(() => {
    cy.log('Completed Password Reset Test Suite');
    extentLogs.push('Completed Password Reset Test Suite');
    // Generate report using Mochawesome or other plugins
  });

  it('should navigate to login page and initiate password reset', () => {
    cy.log('Navigating to login page');
    extentLogs.push('Navigating to login page');
    cy.visit('https://example.com/login'); // Replace with actual URL

    cy.log('Clicking on Forgot Password link');
    extentLogs.push('Clicking on Forgot Password link');
    cy.get('#forgot-password').click();

    cy.log('Entering registered email address');
    extentLogs.push('Entering registered email address');
    cy.get('#email').type('user@example.com');

    cy.log('Submitting password reset request');
    extentLogs.push('Submitting password reset request');
    cy.get('#submit-request').click();

    cy.wait(5000); // Explicit wait for email delivery
  });

  it('should verify email passcode and set new password', () => {
    cy.log('Checking email inbox for passcode');
    extentLogs.push('Checking email inbox for passcode');
    // Simulate email check and retrieve passcode
    const passcode = '123456'; // Replace with actual logic to retrieve passcode

    cy.log('Entering received passcode');
    extentLogs.push('Entering received passcode');
    cy.get('#passkode').type(passcode);

    cy.log('Entering new password');
    extentLogs.push('Entering new password');
    cy.get('#new-password').type('newPassword123');

    cy.log('Confirming new password');
    extentLogs.push('Confirming new password');
    cy.get('#confirm-password').type('newPassword123');

    cy.log('Submitting new password');
    extentLogs.push('Submitting new password');
    cy.get('#submit-new-password').click();

    cy.wait(2000); // Explicit wait for password reset completion
  });

  it('should log in with newly set password', () => {
    cy.log('Attempting to log in with new password');
    extentLogs.push('Attempting to log in with new password');
    cy.visit('https://example.com/login');

    cy.get('email').type('user@example.com');
    cy.get('#password').type('newPassword123');

    cy.log('Submitting login request');
    extentLogs.push('Submitting login request');
    cy.get('#login-button').click();

    cy.wait(2000); // Explicit wait for login process

    cy.log('Verifying successful login');
    extentLogs.push('Verifying successful login');
    cy.get('#welcome-message').should('contain', 'Welcome');

    // Exception handling
    cy.on('fail', (error) => {
      cy.screenshot();
      extentLogs.push(`Test failed:
\n${error}`);
    });
  });
});
