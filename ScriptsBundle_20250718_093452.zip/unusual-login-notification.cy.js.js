import { cy, before, after } from 'cypress';
import { assert } from 'chai';
import _ from 'lodash';
import 'cypress-commands';
import 'cypress-mochawesome-reporter/register';

describe('Verify Notification of Unusual Login Attempts', () => {
  let userEmail = 'user@example.com';
  let userPassword = 'correctPassword';
  let incorrectPassword = 'wrongPassword';

  before(() => {
    cy.log('Starting test suite: Verify Notification of Unusual Login Attempts');
    cy.visit('https://example.com/login');
  });

  after(() => {
    cy.log('Test suite completed: Verify Notification of Unusual Login Attempts');
  });

  it('should log in with valid credentials', () => {
    cy.log('Test case: Log in with valid credentials');
    cy.get('email').type(userEmail);
    cy.get('#password').type(userPassword);
    cy.get('loginButton').click();
    cy.url().should('include', '/dashboard');
    cy.log('Successfully logged in with valid credentials');
  });

  it('should simulate multiple failed login attempts', () => {
    cy.log('Test case: Simulate multiple failed login attempts');
    for(let i = 0; i < 3; i++) {
      cy.visit('https://example.com/login');
      cy.get('email').type(userEmail);
      cy.get('#password').type(incorrectPassword);
      cy.get('loginButton').click();
      cy.get('.error-message').should('contain', 'Invalid credentials');
    }
    cy.log('Multiple failed login attempts simulated');
  });

  it('should simulate login from an unfamiliar location', () => {
    cy.log('Test case: Simulate login from an unfamiliar location');
    cy.visit('https://example.com/login');
    cy.get('email').type(userEmail);
    cy.get('#password').type(userPassword);
    cy.get('loginButton').click();
    cy.url().should('include', '/dashboard');
    cy.log('Login from an unfamiliar location simulated');
  });

  it('should check for alerts regarding suspicious login activities', () => {
    cy.log('Test case: Check for alerts regarding suspicious login activities');
    cy.wait(5000); // Wait for alerts to be sent
    cy.task('checkEmail', userEmail).then( (emails) => {
      const alertEmail = _.find(emails, (email) => email.subject.includes('Unusual Login Attempt'));
      assert.isNotNull(alertEmail, 'Alert email should be received');
      cy.log('Alert email received');
    });
    cy.task('checkSMS', userEmail).then( (sms) => {
      const alertSMS = _.find(sms, (message) => message.includes('Unusual Login Attempt'));
      assert.isNotNull(alertSMS, 'Alert SMS should be received');
      cy.log('Alert SMS received');
    });
});

  it('should review details of suspicious activity and secure the account', () => {
    cy.log('Test case: Review details of suspicious activity and secure the account');
    cy.visit('https://example.com/account-security');
    cy.get('#changePassword').click();
    cy.get('#newPassword').type('newSecurePassword');
    cy.get('#confirmPassword').type('newSecurePassword');
    cy.get('#saveButton').click();
    cy.get('.success-message').should('contain', 'Password changed successfully');
    cy.log('Account secured by changing password');
  });

  Cypress.on('fail', (error, runnable) => {
    cy.screenshot();
    throw error;
  });
});