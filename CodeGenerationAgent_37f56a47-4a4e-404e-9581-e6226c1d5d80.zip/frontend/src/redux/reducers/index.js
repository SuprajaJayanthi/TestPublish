import { combineReducers } from 'redux';

const rootReducer = combineReducers({
  // Add your reducers here
});

export default rootReducer;