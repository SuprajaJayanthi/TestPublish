// Import required modules and dependencies
import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

// Extent Logs declaration for reporting
let ExtentLogs = {
    info: (msg) => cy.log(`[INFO]`
    };
