import React, { useState, useEffect } from 'react';

const MainComponent = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        // Replace with API call
        setData([{
            id: 1,
            name: 'Example'
        }]);
    }, []);

    return (
        <div>
            <h1>Data List</h1>
            <ul>
                {data.map(item => (
                    <li key={item.id}>{item.name}</li>
                ))}
            </ul>
        </div>
    );
};

export default MainComponent;