const express = require('express');
const router = express.Router();

// Mock database
let users = [];

// Create
router.post('/', (req, res) => {
    const user = req.body;
    users.push(user);
    res.status(201).send(user);
});

// Read
router.get('/', (req, res) => {
    res.send(users);
});

// Update
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex !== -1) {
        users[userIndex] = req.body;
        res.send(users[userIndex]);
    } else {
        res.status(404).send('User not found');
    }
});

// Delete
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex !== -1) {
        users.splice(userIndex, 1);
        res.status(204).send();
    } else {
        res.status(404).send('User not found');
    }
});

module.exports = router;