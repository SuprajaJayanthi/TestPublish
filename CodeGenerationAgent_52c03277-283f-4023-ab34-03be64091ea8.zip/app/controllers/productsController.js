const express = require('express');
const router = express.Router();

// Mock database
let products = [];

// Create
router.post('/', (req, res) => {
    const product = req.body;
    products.push(product);
    res.status(201).send(product);
});

// Read
router.get('/', (req, res) => {
    res.send(products);
});

// Update
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id === id);
    if (productIndex !== -1) {
        products[productIndex] = req.body;
        res.send(products[productIndex]);
    } else {
        res.status(404).send('Product not found');
    }
});

// Delete
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id === id);
    if (productIndex !== -1) {
        products.splice(productIndex, 1);
        res.status(204).send();
    } else {
        res.status(404).send('Product not found');
    }
});

module.exports = router;