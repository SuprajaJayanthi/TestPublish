# Import necessary libraries
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import requests
import os

class ImageUploader:
    def __init__(self, master):
        self.master = master
        self.master.title('Image Upload Functionality')
        
        # Create GUI components
        self.label = tk.Label(master, text='Select an image to upload:')
        self.label.pack(pady=10)
        self.upload_button = tk.Button(master, text='Browse', command=self.select_file)
        self.upload_button.pack(pady=5)
        self.status_label = tk.Label(master, text='')
        self.status_label.pack(pady=10)

    def select_file(self):
        # Open file dialog
        file_path = filedialog.askopenfilename(filetypes=[('Image files', '*.jpeg;*.jpg;*.png')])
        if file_path:
            self.upload_image(file_path)

    def upload_image(self, file_path):
        # Simulate image upload process
        try:
            # Open the selected image
            with open(file_path, 'rb') as image_file:
                # Assume a placeholder URL for image upload
                url = 'http://example.com/upload'
                files = {'file': image_file}
                # Post request to upload image
                response = requests.post(url, files=files)
                
                if response.status_code == 200:
                    self.status_label.config(text='Upload successful!')
                else:
                    self.status_label.config(text='Upload failed!')
        except Exception as e:
            self.status_label.config(text=f'Error: {e}')
        
        # Display the uploaded image maintaining quality and aspect ratio
        self.display_image(file_path)

    def display_image(self, file_path):
        image = Image.open(file_path)
        # Maintain aspect ratio
        aspect_ratio = min(self.master.winfo_width()/image.width, self.master.winfo_height()/image.height)
        image = image.resize((int(image.width*aspect_ratio), int(image.height*aspect_ratio)), Image.ANTIALIAS)
        img = ImageTk.PhotoImage(image)
        panel = tk.Label(self.master, image=img)
        panel.image = img  # Keep reference so it's not garbage collected
        panel.pack()

if __name__ == '__main__':
    root = tk.Tk()
    app = ImageUploader(root)
    root.mainloop()