import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 3: Uploading and Managing Income and Deduction Details for Tax Return Filing', () => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 3: Uploading and Managing Income and Deduction Details');
    cy.log('Starting Test Case 3: Uploading and Managing Income and Deduction Details');
    cy.visit('https://incometaxefiling.gov.in/login');
    cy.get('#username').type('ABCDE1234F');
    cy.get('#password').type('Test@1234');
    cy.get('#loginBtn').click();
    cy.wait(2000);
    cy.get('.dashboard').should('be.visible');
  });

  after(() => {
    extentLogs.push('Completed Test Case 3: Uploading and Managing Income and Deduction Details');
    cy.log('Completed Test Case 3: Uploading and Managing Income and Deduction Details');
    cy.writeFile('cypress/logs/TC3-IncomeDeduction-ExtentLogs.txt', extentLogs.join('\n'));
  });

  it('should allow user to enter/upload, save, resume, validate, review, and edit income/deduction details', () => {
    try {
      extentLogs.push('Step 1: Access income tax return filing section');
      cy.get('#menu-tax-filing').click();
      cy.url().should('include', '/tax-filing');
      cy.log('Accessed tax filing section');

      extentLogs.push('Step 2: Enter valid income and deduction details');
      cy.get('#income-salary').type('1200000');
      cy.get('income-other').type('50000');
      cy.get('#deduction-80C').type('150000');
      cy.get('#deduction-80D.').type('25000');
      cy.get('#upload-supporting').attachFile('supporting-doc.pdf');
      cy.log('Entered/uploaded income and deduction details');

      extentLogs.push('Step 3: Save progress and log out');
      cy.get('#saveBtn').click();
      cy.get('.notification').should('contain', 'Progress saved');
      cy.get('#logoutBtn').click();
      cy.get('#loginBtn').click();
      cy.wait(2000);
      cy.get('.dashboard').should('visible');
      cy.get('#menu-tax-filing').click();
      cy.get('income-salary').should('have.value', '1200000');
      cy.get('income-other').should('value', '50000');
      cy.get('#deduction-80c').should('value', '150000');
      cy.log('Resumed and verified saved data');

      extentLogs.push('Step 5: Submit details for validation');
      cy.get('#validateBtn').click();
      cy.wait(1000);
      cy.get('.validation-success').should('contain', 'Validation successful');
      cy.log('Validation successful');

      extentLogs.push('Step 6: Enter incomplete data and check error messages');
      cy.get('#income-salary').clear();
      cy.get('#validateBtn').click();
      cy.get('.error').should('contain', 'Income salary is required');
      cy.get('income-salary').type('1200000');
      cy.log('Error message displayed and corrected');

      extentLogs.push('Step 7: Review and edit before final submission');
      cy.get('income-other').remove().type('30000');
      cy.get('#reviewBtn').click();
      cy.get('.review-summary').should('contain', '30000');
      cy.log('Reviewed and edited entries before submission');

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC3-IncomeDeduction-Failure');
      Assert.fail(err.message);
    }
  });
});