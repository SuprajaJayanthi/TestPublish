import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 5: Downloading and Printing Filed Income Tax Return and Acknowledgment', () => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 5: Downloading and Printing Filed Returns');
    cy.log('Starting Test Case 5: Downloading and Printing Filed Returns');
    cy.visit('https://incometaxefiling.gov.in/login');
    cy.get('#username').type('ABCDE234F');
    cy.get('#password').type('Test@1234');
    cy.get('#loginBtn').click();
    cy.wait(2000);
    cy.get('.dashboard').should('be.visible');
  });

  after(() => {
    extentLogs.push('Completed Test Case 5: Downloading and Printing Filed Returns');
    cy.log('Completed Test Case 5: Downloading and Printing Filed Returns');
    cy.writeFile('cypress/logs/TC5_DownloadPrint-ExtentLogs.txt', extentLogs.join('
'));
  });

  it('should allow user to view, download, and print filed returns and acknowledgments securely', () => {
    try {
      extentLogs.push('Step 1: Access account history');
      cy.get('#menu-account-history').click();
      cy.get('.filed-returns').should('visible');
      cy.log('Accessed account history');

      extentLogs.push('Step 2: View list of filed returns and acknowledgments');
      cy.get('.filed-returns .return-row').should('have.length.greaterThan', ��0);
      cy.log('Viewed list of filed returns');

      extentLogs.push('Step 3: Select a filed return and download');
      cy.get('.filed-returns .return-row').first().find('.download-btn').click();
      cy.wait(2000);
      cy.readFile('cypress/downloads/FiledReturn.pdf').then((pdfContent) => {
        expect(pdfContent).to.not.be.empty;
        cy.log('Downloaded PDF is not empty');
      });

      extentLogs.push('Step 4: Open and verify downloaded PDF');
      cy.task('parsePdf', 'cypress/downloads/FiledReturn.pdf').then((data) => {
        expect(data.text).to.include('Test User');
        expect(data.text).to.include('Acknowledgment Receipt');
        cy.log('PDF content matches original submission');
      });

      extentLogs.push('Step 5: Print the document and check formatting');
      cy.get('.filed-returns .return-row').first().find('.print-btn').click();
      cy.wait(1000);
      cy.get('.print-preview').should('be.visible');
      cy.get('.print-preview').should('contain', 'Test User');
      cy.log('Print preview is clear and legible');

      extentLogs.push('Step 6: Ensure data security during download/print');
      cy.intercept('GET', '/api/downloadReturn", (req) => {
        expect(req.url).to.match(/^https:///));
      });
      cy.log('Data security maintained during download and print');

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC5_DownloadPrint-Failure');
      Assert.fail(err.message);
    }
  });
});