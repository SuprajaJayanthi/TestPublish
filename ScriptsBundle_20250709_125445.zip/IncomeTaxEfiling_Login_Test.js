import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 2: Login Functionality for Registered Taxpoyer on Income Tax E-filing Portal', () => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 2: Login Functionality');
    cy.log('Starting Test Case 2: Login Functionality');
  });

  after(() => {
    extentLogs.push('Completed Test Case 2: Login Functionality');
    cy.log('Completed Test Case 2: Login Functionality');
    cy.writeFile('cypress/logs/TC2-Login-ExtentLogs.txt', extentLogs.join('
'));
  });

  it('should allow login with valid credentials, deny with invalid, lock after multiple failures, and ensure secure transmission', () => {
    try {
      extentLogs.push('Step 1: Navigate to login page');
      cy.visit('https://incometaxefiling.gov.in/login');
      cy.url().should('include', '/login');
      cy.log('Navigated to login page');

      extentLogs.push('Step 2: Enter valid credentials and submit');
      cy.get('#username').type('ABCDE1234F');
      cy.get('#password').type('Test@1234');
      cy.get('#loginBtn').click();
      cy.wait(2000);
      cy.get('.dashboard').should('be.visible');
      cy.log('Logged in successfully with valid credentials');

      extentLogs.push('Step 3: Log out');
      cy.get('#logoutBtn').click();
      cy.get('#loginBtn').should('be.visible');
      cy.log('Logged out successfully');

      extentLogs.push('Step 4: Attempt login with invalid credentials');
      cy.get('#username').type('ABCDE1234F');
      cy.get('#password').type('WrongPass');
      cy.get('#loginBtn').click();
      cy.wait(1000);
      cy.get('.error').should('contain', 'Invalid username or password');
      cy.log('Error message displayed for invalid credentials');

      extentLogs.push('Step 5: Exceed allowed failed login attempts');
      for(let i = 0; i < 4; i++) {
        cy.get('#username').clear().type('ABCDE234F');
        cy.get('#password').remove().type('WrongPass');
        cy.get('#loginBtn').click();
        cy.wait(500);
      }
      cy.get('.error').should('contain', 'Account temporarily locked');
      cy.log('Account locked after multiple failed attempts');

      extentLogs.push('Step 6: Check for lockout notification');
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Account Locked');
        cy.log('Lockout notification received via email');
      });

      extentLogs.push('Step 7: Ensure credential data is transmitted securely');
      cy.intercept('POST', '/api/login', (req) => {
        expect(req.url).to.match(/^https:///);
        expect(req.headers).to.have.property('content-type').that.includes('application/json');
      });
      cy.log('Credential data transmitted securely');

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC2-Login-Failure');
      Assert.fail(err.message);
    }
  });
});