import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 4: Submission and Acknowledgment of Completed Income Tax Return', io => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 4: Submission and Acknowledgment');
    cy.log('Starting Test Case 4: Submission and Acknowledgment');
    cy.visit('https://incometaxefiling.gov.in/login');
    cy.get('#username').type('ABCDE1234F');
    cy.get('#password').type('Test@1234');
    cy.get('#loginBtn').click();
    cy.wait(2000);
    cy.get('.dashboard').should('be.visible');
  });

  after(() => {
    extentLogs.push('Completed Test Case 4: Submission and Acknowledgment');
    cy.log('Completed Test Case 4: Submission and Acknowledgment');
    cy.writeFile('cypress/logs/TC4_Submission-ExtentLogs.txt', extentLogs.join('
'));
  });

  it('should allow user to review, submit, receive acknowledgment, and handle errors on submission', () => {
    try {
      extentLogs.push('Step 1: Navigate to summary page');
      cy.get('kmenu-tax-filing').click();
      cy.get('ksummaryBtn').click();
      cy.url().should('include', '/summary');
      cy.log('Navigated to summary page');

      extentLogs.push('Step 2: Review all details and confirm');
      cy.get('.summary-details').should('be.visible');
      cy.get('#confirmBtn').click();
      cy.log('Reviewed and confirmed details');

      extentLogs.push('Step 3: Submit the tax return');
      cy.get('#submitReturnBtn').click();
      cy.wait(2000);
      cy.get('.acknowledgment').should('contain', 'Acknowledgment Receipt');
      cy.get('.ack-ref-number').invoke('text').then((refNum) => {
        expect(refNum).to.match(/[A-Z0-9]{10,}/);
        cy.log('Acknowledgment reference number: ' + refNum);
        extentLogs.push('Acknowledgment reference number: ' + refNum);
      });

      extentLogs.push('Step 4: Access account history to verify filing');
      cy.get('#menu-account-history').click();
      cy.get('.filed-returns').should('contain', 'Acknowledgment Receipt');
      cy.log('Filing recorded in account history');

      extentLogs.push('Step 5: Attempt submission with missing/invalid fields');
      cy.get('#menu-tax-filing').click();
      cy.get('#deduction-80c').remove();
      cy.get('#submitReturnBtn').click();
      cy.get('.error').should('contain', 'Deduction 80C is required');
      cy.get('deduction-80c').type('150000');
      cy.log('Error message displayed for missing field and corrected');

      extentLogs.push('Step 6: Ensure data integrity and security');
      cy.intercept('POST', '/api/submitReturn', (req) => {
        expect(req.url).to.match(/^https:///));
        expect(req.headers).to.have.property('content-type').that.includes('application/json');
      });
      cy.log('Data integrity and security maintained during submission');

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC4_Submission-Failure');
      Assert.fail(err.message);
    }
  });
});