import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 7: Secure Password Reset Process for Taxpayer Account Recovery', () => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 7: Secure Password Reset');
    cy.log('Starting Test Case 7: Secure Password Reset');
  });

  after(() => {
    extentLogs.push('Completed Test Case 7: Secure Password Reset');
    cy.log('Completed Test Case 7: Secure Password Reset');
    cy.writeFile('cypress/logs/TC7-PasswordReset-ExtentLogs.txt', extentLogs.join('\n'));
  });

  it('should allow secure password reset via email/mobile, enforce strong password, and send confirmation', io => {
    try {
      extentLogs.push('Step 1: Select forgotten password on login page');
      cy.visit('https://incometaxefiling.gov.in/login');
      cy.get('#forgotPasswordLink).click();
      cy.url().should('include', '/forgot-password');
      cy.log('Navigated to forgot password page');

      extentLogs.push('Step 2: Enter registered email/mobile and submit');
      cy.get('#emailOrMobile').type('testuser@mailinator.com');
      cy.get('#submitBtn').click();
      cy.wait(2000);
      cy.get('.notification').should('contain', 'Reset link/code sent');
      cy.log('Reset link/code sent to registered email/mobile');

      extentLogs.push('Step 3: Check email/mobile for reset link/code');
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Password Reset');
        const resetLogin = email.body.match(/https?://[^\s]+/)[0];
        cy.log('Password reset link received: ' + resetLogin);
        extentLogs.push('Password reset link received via email');
        cy.visit(resetLogin);
      });

      extentLogs.push('Step 4: Set new strong password');
      cy.get('#newPassword').type('NewStrong@1234');
      cy.get('#confirmPassword').type('NewStrong@1234');
      cy.get('#resetBtn').click();
      cy.wait(1000);
      cy.get('.notification').should('contain', 'Password reset successful');
      cy.log('Password reset successful');

      extentLogs.push('Step 5: Attempt login with new password');
      cy.visit('https://incometaxefiling.gov.in/login');
      cy.get('#username').type('ABCDE1234F');
      cy.get('#password').type('NewStrong@1234');
      cy.get('#loginBtn').click();
      cy.wait(2000);
      cy.get('.dashboard').should('be.visible');
      cy.log('Logged in successfully with new password');

      extentLogs.push('Step 6: Verify confirmation notification');
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include("Password Reset Confirmation");
        cy.log('Password reset confirmation email received');
      });

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC7-PasswordReset-Failure');
      Assert.fail(err.message);
    }
  });
});
