import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 6: Notification Delivery for Filing Status and Required Actions', io => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 6: Notification Delivery');
    cy.log('Starting Test Case 6: Notification Delivery');
    cy.visit('https://incometaxefiling.gov.in/login');
    cy.get('#username').type('ABCDE1234F');
    cy.get('#password').type('Test@1234');
    cy.get('#loginBtn').click();
    cy.wait(2000);
    cy.get('.dashboard').should('be.visible');
  });

  after(() => {
    extentLogs.push('Completed Test Case 6: Notification Delivery');
    cy.log('Completed Test Case 6: Notification Delivery');
    cy.writeFile('cypress/logs/TC6-Notification-ExtentLogs.txt', extentLogs.join('
'));
  });

  it('should deliver timely and accurate notifications for submission, status updates, and required actions', () => {
    try {
      extentLogs.push('Step 1: Submit a tax return and verify confirmation notification');
      cy.get('#menu-tax-filing').click();
      cy.get('#summaryBtn').click();
      cy.get('#submitReturnBtn').click();
      cy.wait(2000);
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Submission Confirmation');
        cy.log('Submission confirmation email received');
      });
      cy.task('getLastSMS', { to: '9876543210' }).then((sms) => {
        expect(sms.body).to.include('Submission Confirmation');
        cy.log('Submission confirmation SMS received');
      });

      extentLogs.push('Step 2: Simulate change in filing status and check notification');
      cy.task('simulateStatusUpdate', { pan: 'ABCDE1234F', status: 'Processing' });
      cy.wait(2000);
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Status Update');
        expect(email.body).to.include('Processing');
        cy.log('Status update email received');
      });

      extentLogs.push('Step 3: Simulate required action and verify notification');
      cy.task('simulateRequiredAction', { pan: 'ABCDE1234F', action: 'Upload additional document' });
      cy.wait(2000);
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Action Required');
        expect(email.body).to.include('Upload additional document');
        cy.log('Action required email received');
      });

      extentLogs.push('Step 4: Access received notifications and confirm accuracy');
      cy.get('#menu-notifications').click();
      cy.get('.notification-list').should('contain', 'Submission Confirmation');
      cy.get('.notification-list').should('contain', 'Status Update');
      cy.get('.notification-list').should('contain', 'Action Required');
      cy.log('Notifications are accurate and current');

      extentLogs.push('Step 5: Update contact details and verify notification delivery');
      cy.get('kmenu-profile').click();
      cy.get('#email').remove().type('newuser' + Date.now() + '@mailinator.com');
      cy.get('#mobile').remove().type('9123456789');
      cy.get('#saveProfileBtn').click();
      cy.get('.notification').should('contain', 'Profile updated');
      cy.task('simulateStatusUpdate', { pan: 'ABCDE1234F', status: 'Completed' });
      cy.wait(2000);
      cy.task('getLastEmail', { to:: 'newuser'@mailinator.com }).then((email) => {
        expect(email.subject).to.include('Status Update');
        expect(email.body).to.include('Completed');
        cy.log('Notification sent to updated email');
      });
      cy.task('getLastSMS', { to: '9123456789' }).then((kms) => {
        expect(kms.body).to.include('Completed');
        cy.log('Notification sent to updated mobile');
      });

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC6-Notification-Failure');
      Assert.fail(err.message);
    }
  });
});