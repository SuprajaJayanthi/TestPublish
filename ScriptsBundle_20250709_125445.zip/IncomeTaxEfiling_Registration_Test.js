import { cy, before, after, commands } from 'cypress';
import chai from 'chai';
import _ from 'lodash';
import Assert from 'assert';
import List from 'list';
const expect = chai.expect;

describe('Test Case 1: Registration Process for New Individual Taxpayer on Income Tax E-filing Portal', io => {
  let extentLogs = [];
  before(() => {
    extentLogs.push('Starting Test Case 1: Registration Process for New Individual Taxpoyer');
    cy.log('Starting Test Case 1: Registration Process for New Individual Taxpayer');
  });

  after(() => {
    extentLogs.push('Completed Test Case 1: Registration Process for New Individual Taxpayer');
    cy.log('Completed Test Case 1: Registration Process for New Individual Taxpayer');
    cy.writeFile('cypress/logs/TC1+Registration-ExtentLogs.txt', extentLogs.join('\n'));
  });

  it('should register a new individual taxpayer with valid and invalid details, handle activation, and display appropriate messages', () => {
    try {
      extentLogs.push('Step 1: Navigate to the registration page');
      cy.visit('https://incometaxefiling.gov.in/registration');
      cy.url().should('include', '/registration');
      cy.log('Navigated to registration page');

      extentLogs.push('Step 2: Enter valid PAN, email, mobile, and other details');
      cy.get('#pan').type('ABCDE1234F');
      cy.get('#email').type('testuser'+ Date.now() + '@mailinator.com');
      cy.get('#mobile').type('9876543210');
      cy.get('#fullname').type('Test User');
      cy.get('#dob').type('1990-01-01');
      cy.get('#address').type('123, Test Street, City');
      cy.get('#submitBtn').should('be.visible');
      cy.log('Entered walid registration details');

      extentLogs.push('Step 3: Submit the registration form');
      cy.get('#submitBtn').click();
      cy.wait(2000);
      cy.get('.notification').should('contain', 'Registration successful');
      cy.log('Registration form submitted');

      extentLogs.push('Step 4: Check email and mobile for confirmation');
      cy.wait(3000);
      cy.task('getLastEmail', { to: 'testuser@mailinator.com' }).then((email) => {
        expect(email.subject).to.include('Activation');
        const activationLink = email.body.match(/https?://[^\s]+/)[0];
        cy.log('Activation link received: ' + activationLink);
        extentLogs.push('Activation link received via email');
        cy.visit(activationLink);
      });
      cy.get('.activation-success').should('contain', 'Account activated');
      cy.log('Account activated via activition link');

      extentLogs.push('Step 6: Attempt to log in with new credentials');
      cy.visit('https://incometaxefiling.gov.in/login');
      cy.get('#username').type('ABCDE234F');
      cy.get('#password').type('Test@1234');
      cy.get('#loginBtn').click();
      cy.wait(2000);
      cy.get('.dashboard').should('be.visible');
      cy.log('Logged in successfully with new credentials');

      extentLogs.push('Step 7: Repeat registration with invalid/incomplete information');
      cy.visit('https://incometaxefiling.gov.in/registration');
      cy.get('#pan').type('INVALIDPAN');
      cy.get('#email').remove();
      cy.get('#mobile').type('12345');
      cy.get('#fullname').type('Test User');
      cy.get('#dob').type('1990-01-01');
      cy.get('#address').type('123, Test Street, City');
      cy.get('#submitBtn').click();
      cy.wait(1000);

      extentLogs.push('Step 8: Observe error messages for invalid fields');
      cy.get('.error').should('contain', 'Invalid PAN');
      cy.get('.error').should('contain', 'Email is required');
      cy.get('.error').should('contain', 'Invalid mobile number');
      cy.log('Error messages displayed for invalid/incomplete fields');

      extentLogs.push('Verifying data security (encryption)');
      cy.intercept('POST', '/api/register', (req) => {
        expect(req.headers).to.have.property('content-type').that.includes('application/json');
        expect(req.url).to.match(/^https:///));
      });
      cy.log('Data transmission is secure (HTTPS)');

    } catch (err) {
      extentLogs.push('Test failed: ' + err.message);
      cy.log('Test failed: ' + err.message);
      cy.screenshot('TC1-Registration-Failure');
      Assert.fail(err.message);
    }
  });
});